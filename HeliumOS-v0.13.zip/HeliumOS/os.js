(() => {
'use strict';

/* ---------- utilitare ---------- */
const $ = (s, r = document) => r.querySelector(s);
function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null) e.append(c);
  return e;
}
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const base = p => p.split('/').filter(Boolean).pop() || '/';
const ext = p => ((p.match(/\.([^./]+)$/) || [])[1] || '').toLowerCase();
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function toast(msg) { notify({ body: msg, store: false, timeout: 2600, icon: '✔️' }); }
function btn(text, title, fn, cls = '') { return el('button', { class: 'btn ' + cls, title, text, onclick: fn }); }

/* ---------- stocare (IndexedDB) ---------- */
const DB = 'heliumos', STORE = 'kv';
let dbp;
const idb = () => dbp || (dbp = new Promise((res, rej) => {
  const r = indexedDB.open(DB, 1);
  r.onupgradeneeded = () => r.result.createObjectStore(STORE);
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
}));
async function dbGet(k) {
  const db = await idb();
  return new Promise((res, rej) => { const q = db.transaction(STORE).objectStore(STORE).get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
}
async function dbSet(k, v) {
  const db = await idb();
  return new Promise((res, rej) => { const t = db.transaction(STORE, 'readwrite'); t.objectStore(STORE).put(v, k); t.oncomplete = res; t.onerror = () => rej(t.error); });
}

/* ---------- tipuri de fișiere ---------- */
const MAX_BYTES = 20 * 1024 * 1024;
const TEXT_EXT = /\.(txt|md|json|js|mjs|ts|css|html?|csv|xml|svg|py|ya?ml|log|ini|sh|toml)$/i;
const CODE_EXT = /\.(js|mjs|ts|json|css|html?|xml|py|ya?ml|sh|toml|ini)$/i;
const MIME_EXT = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp', avif: 'image/avif', svg: 'image/svg+xml',
  mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', m4a: 'audio/mp4', flac: 'audio/flac', opus: 'audio/ogg', aac: 'audio/aac',
  mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime' };
function kindOf(n, p) {
  const e = ext(p), m = n.mime || MIME_EXT[e] || '';
  if (e === 'lnk' && !n.bin) return 'link';
  if (e === 'svg' || m.startsWith('image/')) return 'image';
  if (m.startsWith('audio/')) return 'audio';
  if (m.startsWith('video/')) return 'video';
  if (n.bin) return 'bin';
  return CODE_EXT.test(p) ? 'code' : 'text';
}
const FILE_ICON = { image: '🖼️', audio: '🎵', video: '🎞️', code: '📜', text: '📄', bin: '📦', link: '🔗' };
function fmtSize(b) { return b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(1) + ' KB' : (b / 1048576).toFixed(1) + ' MB'; }
function sizeOf(n) { if (n.lazy) return n.size || 0; return n.bin ? Math.max(0, Math.round((n.content.length - n.content.indexOf(',') - 1) * 3 / 4)) : n.content.length; }
function dataToBlob(d, forceMime) {
  const i = d.indexOf(',');
  const mime = d.slice(5, i).split(';')[0] || 'application/octet-stream';
  const bin = atob(d.slice(i + 1)), u8 = new Uint8Array(bin.length);
  for (let k = 0; k < bin.length; k++) u8[k] = bin.charCodeAt(k);
  return new Blob([u8], { type: forceMime || mime });
}
function fileURL(n, p) {
  if (n.bin) return URL.createObjectURL(dataToBlob(n.content, n.mime || MIME_EXT[ext(p)]));
  const e = ext(p);
  const type = e === 'svg' ? 'image/svg+xml' : /^html?$/.test(e) ? 'text/html' : 'text/plain';
  return URL.createObjectURL(new Blob([n.content], { type }));
}
function download(p) {
  const n = node(p); if (!n || n.type !== 'file') return;
  const url = fileURL(n, p), a = el('a', { href: url, download: base(p) });
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
}
function pickFiles(accept, cb) {
  const i = el('input', { type: 'file', multiple: '', accept, style: 'display:none' });
  i.addEventListener('change', () => { const f = [...i.files]; i.remove(); if (f.length) cb(f); });
  i.addEventListener('cancel', () => i.remove());
  document.body.append(i); i.click();
}
const readDataURL = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(f); });

/* ---------- sistem de fișiere ---------- */
let root, settings;
const mkFile = c => ({ type: 'file', content: c, mtime: Date.now() });
const mkDir = (ch = {}) => ({ type: 'dir', children: ch, mtime: Date.now() });
const seed = () => mkDir({
  Documents: mkDir({
    'Bun venit.txt': mkFile('Bun venit în HeliumOS!\n\n- Dublu-click pe o pictogramă ca să deschizi o aplicație.\n- Trage fișiere din calculator pe desktop sau în fereastra Fișiere ca să le imporți.\n- Imaginile se deschid în Imagini, muzica în Muzică, codul în Cod.\n- În Terminal scrie "help" ca să vezi comenzile.\n- Fișierele rămân salvate în browser.\n- Alt+R deschide „Rulează”, iar Alt+` (ținut apăsat) comută între ferestre.\n- Click dreapta pe o aplicație sau un fișier → „Creează scurtătură”.\n'),
    'salut.js': mkFile('// Deschide în „Cod” și apasă Rulează\nconst nume = "HeliumOS";\nconsole.log(`Salut din ${nume}!`);\nconsole.log([1, 2, 3].map(x => x * x));\n')
  }),
  Desktop: mkDir(),
  Pictures: mkDir(),
  Music: mkDir()
});
const split = p => p.split('/').filter(Boolean);
function norm(path, cwd = '/') {
  const parts = path.startsWith('/') ? [] : split(cwd);
  for (const s of split(path)) { if (s === '.') continue; if (s === '..') parts.pop(); else parts.push(s); }
  return '/' + parts.join('/');
}
function node(path) {
  let n = root;
  for (const s of split(path)) { if (n.type !== 'dir' || !n.children[s]) return null; n = n.children[s]; }
  return n;
}
function parentOf(path) { const p = split(path); const name = p.pop(); return { dir: node('/' + p.join('/')), name }; }
const persist = debounce(() => dbSet('fs', fsForSave()), 250);
const changed = () => { persist(); window.dispatchEvent(new Event('fs-change')); };
const fs = {
  read(p) { const n = node(p); return n && n.type === 'file' && !n.bin ? n.content : null; },
  put(p, n) {
    const { dir, name } = parentOf(p);
    if (!dir || dir.type !== 'dir' || !name) return 'Cale invalidă (folderul nu există).';
    if (dir.children[name] && dir.children[name].type === 'dir') return 'Există deja un folder cu acest nume.';
    dir.children[name] = n; return null;
  },
  write(p, content) { const e = fs.put(p, mkFile(content)); if (!e) changed(); return e; },
  mkdir(p) {
    const { dir, name } = parentOf(p);
    if (!dir || dir.type !== 'dir' || !name) return 'Cale invalidă.';
    if (dir.children[name]) return 'Există deja.';
    dir.children[name] = mkDir(); changed(); return null;
  },
  rm(p, recursive) {
    const n = node(p); if (!n) return 'Nu există.';
    if (p === '/') return 'Nu poți șterge rădăcina.';
    if (n.type === 'dir' && Object.keys(n.children).length && !recursive) return 'Folderul nu e gol (folosește -r).';
    const { dir, name } = parentOf(p); delete dir.children[name]; changed(); return null;
  },
  mv(a, b) {
    const src = node(a); if (!src) return 'Sursa nu există.';
    const dst = node(b); if (dst && dst.type === 'dir') b = norm(base(a), b);
    if (b === a) return null;
    if (b.startsWith(a + '/')) return 'Nu poți muta un folder în el însuși.';
    const { dir, name } = parentOf(b);
    if (!dir || dir.type !== 'dir' || !name) return 'Destinație invalidă.';
    if (dir.children[name]) return 'Destinația există deja.';
    const o = parentOf(a); delete o.dir.children[o.name];
    dir.children[name] = src; changed(); return null;
  },
  cp(a, b) {
    const src = node(a); if (!src) return 'Sursa nu există.';
    const dst = node(b); if (dst && dst.type === 'dir') b = norm(base(a), b);
    if (b === a || b.startsWith(a + '/')) return 'Destinație invalidă.';
    const { dir, name } = parentOf(b);
    if (!dir || dir.type !== 'dir' || !name) return 'Destinație invalidă.';
    dir.children[name] = structuredClone(src); changed(); return null;
  },
  mkdirp(p) { let cur = ''; for (const seg of split(p)) { cur += '/' + seg; if (!node(cur)) { const e = fs.mkdir(cur); if (e) return e; } } return null; },
  trash(p) {
    const n = node(p); if (!n) return 'Nu există.';
    if (p === '/' || p === '/.Trash' || p.startsWith('/.Trash/')) return 'Nu poate fi mutat în coș.';
    if (!node('/.Trash')) root.children['.Trash'] = mkDir();
    const b = base(p), x = (b.match(/\.[^.]*$/) || [''])[0];
    const name = uniqueName('/.Trash', b.slice(0, b.length - x.length), x);
    n.trash = { from: p, at: Date.now() };
    const e = fs.mv(p, '/.Trash/' + name);
    if (e) delete n.trash; else fs.lastTrash = name;
    return e;
  },
  restore(name) {
    const t = '/.Trash/' + name, n = node(t); if (!n) return 'Nu există.';
    const from = (n.trash && n.trash.from) || '/Desktop/' + name, dir = norm('..', from);
    const e1 = fs.mkdirp(dir); if (e1) return e1;
    let dest = from;
    if (node(dest)) { const b = base(from), x = (b.match(/\.[^.]*$/) || [''])[0]; dest = norm(uniqueName(dir, b.slice(0, b.length - x.length), x), dir); }
    const info = n.trash; delete n.trash;
    const e = fs.mv(t, dest);
    if (e) n.trash = info;
    return e;
  },
  ls(p) {
    const n = node(p); if (!n || n.type !== 'dir') return [];
    return Object.entries(n.children).sort(([a, x], [b, y]) => x.type === y.type ? a.localeCompare(b) : x.type === 'dir' ? -1 : 1);
  }
};
function ensureDir(p) { if (!node(p)) fs.mkdir(p); }

async function importFiles(files, destDir) {
  ensureDir(destDir);
  const paths = [], skipped = [];
  for (const f of files) {
    if (f.size > MAX_BYTES) { skipped.push(f.name + ' (peste 20 MB)'); continue; }
    try {
      const mime = f.type || MIME_EXT[ext(f.name)] || '';
      const asText = !mime.startsWith('image/') && !mime.startsWith('audio/') && !mime.startsWith('video/') && (mime.startsWith('text/') || TEXT_EXT.test(f.name));
      const n = asText ? mkFile(await f.text()) : { ...mkFile(await readDataURL(f)), bin: true, mime };
      const p = norm(f.name.replace(/[\/\\]/g, '_'), destDir);
      const e = fs.put(p, n); if (e) skipped.push(f.name + ' (' + e + ')'); else paths.push(p);
    } catch { skipped.push(f.name); }
  }
  if (paths.length) {
    const made = paths.map(p => [p, node(p)]);
    pushUndo({ label: `Import (${plural(paths.length, 'fișier', 'fișiere')})`, undo: () => { for (const [p] of [...made].reverse()) { const e = fs.rm(p, true); if (e) return e; } return null; }, redo: () => { for (const [p, n] of made) { const e = fs.put(p, n); if (e) return e; } changed(); return null; } });
  }
  if (paths.length) { changed(); notify({ title: 'Import terminat', body: `${paths.length} ${paths.length === 1 ? 'fișier' : 'fișiere'} în ${destDir}`, icon: '📥', click: { type: 'path', path: destDir } }); }
  if (skipped.length) alert('Nu s-au putut importa:\n' + skipped.join('\n'));
  return paths;
}
function openPath(p) {
  const n0 = node(p);
  if (n0 && n0.lazy) return loadThen(p, () => openPath(p));
  const n = n0; if (!n) return;
  if (n.type === 'dir') return files(p);
  const k = kindOf(n, p);
  if (k === 'image') imageViewer(p);
  else if (k === 'audio' || k === 'video') player(p);
  else if (k === 'code') codeEditor(p);
  else if (k === 'text') notepad(p);
  else if (k === 'link') runShortcut(n, p);
  else if (confirm(`„${base(p)}” nu poate fi deschis aici. Îl descarci?`)) download(p);
}

/* ---------- manager de ferestre și bara de activități ---------- */
const desktop = $('#desktop'), tasks = $('#tasks'), snapEl = $('#snap');
let zTop = 10, cascade = 0, hiddenByDesk = [];
const allWins = new Set();
const vd = { cur: 0, seq: 0 };
const winsByApp = new Map();

function iconEl(src) {
  return src && src.startsWith('data:')
    ? el('img', { class: 'ico', src, alt: '', draggable: 'false' })
    : el('span', { class: 'ico', text: src || '▫️' });
}
const iconOf = k => (settings && settings.icons && settings.icons[k]) || (apps[k] && apps[k].icon) || '▫️';

function snapRect(z) {
  const W = desktop.clientWidth, H = desktop.clientHeight;
  return z === 'max' ? [0, 0, W, H] : z === 'left' ? [0, 0, W / 2, H] : [W / 2, 0, W / 2, H];
}
const zoneOf = ev => ev.clientY <= 6 ? 'max' : ev.clientX <= 6 ? 'left' : ev.clientX >= innerWidth - 6 ? 'right' : null;
function showSnap(z) {
  if (!z) { snapEl.style.display = 'none'; return; }
  const [l, t, w, h] = snapRect(z);
  Object.assign(snapEl.style, { display: 'block', left: l + 'px', top: t + 'px', width: w + 'px', height: h + 'px' });
}

function openWindow({ title, app = 'misc', w = 560, h = 380 }) {
  const titleEl = el('span', { class: 'win-title', text: title });
  const bMin = el('button', { class: 'wb', title: 'Minimizează', 'aria-label': 'Minimizează', text: '–' });
  const bMax = el('button', { class: 'wb', title: 'Maximizează', 'aria-label': 'Maximizează', text: '□' });
  const bClose = el('button', { class: 'wb close', title: 'Închide', 'aria-label': 'Închide', text: '✕' });
  const bar = el('header', { class: 'win-bar' }, iconEl(iconOf(app)), titleEl, el('span', { class: 'wb-group' }, bMin, bMax, bClose));
  const body = el('div', { class: 'win-body' });
  const grip = el('div', { class: 'grip' });
  const win = el('section', { class: 'win', role: 'dialog', 'aria-label': title }, bar, body, grip);

  const maxW = desktop.clientWidth, maxH = desktop.clientHeight;
  const ww = Math.min(w, maxW - 16), hh = Math.min(h, maxH - 16), off = (cascade++ % 8) * 28;
  win.style.cssText = `width:${ww}px;height:${hh}px;left:${Math.max(0, Math.min(110 + off, maxW - ww))}px;top:${Math.max(0, Math.min(30 + off, maxH - hh))}px`;
  desktop.append(win);

  const api = {
    body, app, title, win, onClose: null, id: ++vd.seq, desk: vd.cur,
    setTitle(t) { api.title = t; titleEl.textContent = t; renderTasks(); },
    isActive: () => win.classList.contains('active') && !win.classList.contains('min'),
    minimized: () => win.classList.contains('min') || win.classList.contains('minimizing'),
    focus, close, minimize, toggle: () => api.isActive() ? minimize() : focus()
  };
  allWins.add(api);
  if (!winsByApp.has(app)) winsByApp.set(app, []);
  winsByApp.get(app).push(api);

  function focus() {
    if (api.desk !== vd.cur) { vd.cur = api.desk; applyDeskVisibility(); }
    win.classList.remove('min', 'minimizing');
    win.style.zIndex = ++zTop;
    allWins.forEach(x => x.win.classList.remove('active'));
    win.classList.add('active');
    renderTasks();
  }
  function minimize() {
    if (api.minimized()) return;
    win.classList.add('minimizing'); win.classList.remove('active');
    renderTasks();
    setTimeout(() => { if (win.classList.contains('minimizing')) { win.classList.remove('minimizing'); win.classList.add('min'); } }, 170);
  }
  function close() {
    if (!allWins.has(api)) return;
    if (api.onClose && api.onClose() === false) return;
    allWins.delete(api);
    const a = winsByApp.get(app); a.splice(a.indexOf(api), 1); if (!a.length) winsByApp.delete(app);
    win.classList.add('closing'); setTimeout(() => win.remove(), 130);
    const top = [...allWins].filter(x => x.desk === vd.cur && !x.minimized()).sort((x, y) => +y.win.style.zIndex - +x.win.style.zIndex)[0];
    if (top) top.focus(); else renderTasks();
    hidePeek();
  }
  const toggleMax = () => win.classList.toggle('max');
  bMin.onclick = minimize; bMax.onclick = toggleMax; bClose.onclick = close;
  bar.addEventListener('dblclick', e => { if (!e.target.closest('.wb')) toggleMax(); });
  bar.addEventListener('contextmenu', e => {
    if (e.target.closest('.wb')) return;
    e.preventDefault();
    ctxMenu(e.clientX, e.clientY, [{ label: 'Minimizează', icon: '–', fn: minimize }, { label: win.classList.contains('max') ? 'Restaurează' : 'Maximizează', icon: '□', fn: toggleMax }, '-', ...deskMoveItems(api), '-', { label: 'Închide', icon: '✕', fn: close }]);
  });
  win.addEventListener('pointerdown', () => { if (!win.classList.contains('active')) focus(); }, true);

  // mutare + Aero Snap (margine stânga/dreapta = jumătate, sus = maximizat)
  bar.addEventListener('pointerdown', e => {
    if (e.target.closest('.wb')) return;
    const sx = e.clientX, sy = e.clientY;
    let ox = win.offsetLeft, oy = win.offsetTop, moved = false;
    bar.setPointerCapture(e.pointerId);
    const mv = ev => {
      if (!moved) {
        if (Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) < 4) return;
        moved = true;
        if (win.classList.contains('max')) {
          win.classList.remove('max');
          ox = Math.round(sx - (sx / desktop.clientWidth) * win.offsetWidth); oy = 0;
        } else if (win._snap) {
          const r = win._rect, ratio = (sx - win.offsetLeft) / win.offsetWidth;
          win.style.width = r.w + 'px'; win.style.height = r.h + 'px';
          ox = Math.round(sx - ratio * r.w); oy = win.offsetTop; win._snap = null;
        }
      }
      win.style.left = ox + ev.clientX - sx + 'px'; win.style.top = Math.max(0, oy + ev.clientY - sy) + 'px';
      showSnap(zoneOf(ev));
    };
    const up = ev => {
      bar.removeEventListener('pointermove', mv); bar.removeEventListener('pointerup', up);
      showSnap(null);
      const z = moved ? zoneOf(ev) : null;
      if (!z) return;
      if (z === 'max') { win.classList.add('max'); return; }
      win._rect = { w: win.offsetWidth, h: win.offsetHeight };
      const [l, t, sw, sh] = snapRect(z);
      Object.assign(win.style, { left: l + 'px', top: t + 'px', width: sw + 'px', height: sh + 'px' });
      win._snap = z;
    };
    bar.addEventListener('pointermove', mv); bar.addEventListener('pointerup', up);
  });
  grip.addEventListener('pointerdown', e => {
    const sx = e.clientX, sy = e.clientY, ow = win.offsetWidth, oh = win.offsetHeight;
    grip.setPointerCapture(e.pointerId); e.preventDefault(); win._snap = null;
    const mv = ev => { win.style.width = Math.max(280, ow + ev.clientX - sx) + 'px'; win.style.height = Math.max(180, oh + ev.clientY - sy) + 'px'; };
    const up = () => { grip.removeEventListener('pointermove', mv); grip.removeEventListener('pointerup', up); };
    grip.addEventListener('pointermove', mv); grip.addEventListener('pointerup', up);
  });

  focus();
  return api;
}

/* --- bara de activități: butoane grupate pe aplicație, cu fixare --- */
let peekEl = null, peekTimer = 0;
function hidePeek() { clearTimeout(peekTimer); if (peekEl) { peekEl.remove(); peekEl = null; } }
function schedulePeekHide() { clearTimeout(peekTimer); peekTimer = setTimeout(hidePeek, 220); }
function showPeek(anchor, ws) {
  clearTimeout(peekTimer);
  if (!ws.length) return hidePeek();
  hidePeek();
  peekEl = el('div', { id: 'peek' });
  peekEl.addEventListener('mouseenter', () => clearTimeout(peekTimer));
  peekEl.addEventListener('mouseleave', schedulePeekHide);
  for (const x of ws) {
    peekEl.append(el('div', { class: 'pk' + (x.isActive() ? ' on' : ''), onclick: () => { hidePeek(); x.focus(); } },
      el('div', { class: 'pk-h' }, iconEl(iconOf(x.app)), el('span', { class: 'pk-t', text: x.title }),
        el('button', { class: 'pk-x', title: 'Închide', text: '✕', onclick: e => { e.stopPropagation(); x.close(); } })),
      el('div', { class: 'pk-b' }, iconEl(iconOf(x.app)))));
  }
  document.body.append(peekEl);
  const r = anchor.getBoundingClientRect();
  peekEl.style.bottom = (innerHeight - r.top + 6) + 'px';
  peekEl.style.left = Math.max(4, Math.min(r.left + r.width / 2 - peekEl.offsetWidth / 2, innerWidth - peekEl.offsetWidth - 4)) + 'px';
}
function togglePin(k) {
  const i = settings.pinned.indexOf(k);
  if (i >= 0) settings.pinned.splice(i, 1); else settings.pinned.push(k);
  saveSettings(); renderTasks();
}
function renderTasks() {
  hidePeek();
  tasks.textContent = '';
  const keys = settings.pinned.filter(k => apps[k]);
  for (const [k, arr] of winsByApp) if (arr.some(x => x.desk === vd.cur) && !keys.includes(k)) keys.push(k);
  for (const k of keys) {
    const ws = (winsByApp.get(k) || []).filter(x => x.desk === vd.cur), a = apps[k] || { name: 'Fereastră', open() {} };
    const pinned = settings.pinned.includes(k);
    const b = el('button', {
      class: 'task' + (ws.length ? ' running' : '') + (ws.some(x => x.isActive()) ? ' active' : '') + (ws.length > 1 ? ' multi' : ''),
      'aria-label': a.name,
      onclick: () => {
        if (!ws.length) return a.open();
        if (ws.length === 1) return ws[0].toggle();
        const i = ws.findIndex(x => x.isActive()); ws[(i + 1) % ws.length].focus();
      },
      oncontextmenu: e => {
        e.preventDefault();
        ctxMenu(e.clientX, e.clientY, [
          { label: 'Deschide ' + a.name, icon: '▸', fn: () => a.open() },
          { label: pinned ? 'Elimină din bara de activități' : 'Fixează în bara de activități', icon: '📌', fn: () => togglePin(k) },
          ...(apps[k] ? [{ label: 'Schimbă pictograma…', icon: '🖼️', fn: () => changeIcon(k) }, { label: 'Creează scurtătură pe desktop', icon: '🔗', fn: () => makeLink('/Desktop', apps[k].name, k) }] : []),
          ...(apps[k] && apps[k].user ? userAppMenuItems(k) : []),
          ...(ws.length ? ['-', { label: ws.length > 1 ? 'Închide toate ferestrele' : 'Închide fereastra', icon: '✕', fn: () => [...ws].forEach(x => x.close()) }] : [])
        ]);
      }
    }, iconEl(iconOf(k)), el('span', { class: 'task-t', text: ws.length === 1 ? ws[0].title : a.name }));
    b.title = a.name;
    b.addEventListener('mouseenter', () => { if (ws.length) showPeek(b, ws); });
    b.addEventListener('mouseleave', schedulePeekHide);
    tasks.append(b);
  }
}
function showDesktop() {
  const vis = [...allWins].filter(x => x.desk === vd.cur && !x.minimized());
  if (vis.length) { hiddenByDesk = vis; vis.forEach(x => x.minimize()); }
  else { hiddenByDesk.forEach(x => allWins.has(x) && x.focus()); hiddenByDesk = []; }
}

/* ---------- desktopuri virtuale ---------- */
const deskName = i => settings.vdesks[i] || ('Desktop ' + (i + 1));
function updateTvBadge() {
  const b = $('#tvbadge'), t = $('#taskview'); if (!b || !t) return;
  b.textContent = String(vd.cur + 1); b.hidden = settings.vdesks.length < 2;
  t.title = `Vizualizare activități · ${deskName(vd.cur)}`;
}
function applyDeskVisibility() {
  allWins.forEach(x => x.win.classList.toggle('vhid', x.desk !== vd.cur));
  updateTvBadge(); applyWall(true);
}
const topOnDesk = () => [...allWins].filter(x => x.desk === vd.cur && !x.minimized()).sort((a, b) => +b.win.style.zIndex - +a.win.style.zIndex)[0];
function refocusDesk() {
  const top = topOnDesk();
  allWins.forEach(x => x.win.classList.remove('active'));
  if (top) top.focus(); else renderTasks();
}
function switchDesk(i, announce = true) {
  if (i < 0 || i >= settings.vdesks.length || i === vd.cur) return;
  vd.cur = i; applyDeskVisibility(); refocusDesk();
  if (announce) notify({ body: deskName(i), icon: '🖥️', store: false, timeout: 900 });
  if ($('#tv')) renderTaskView();
}
function addDesk(go = true) {
  if (settings.vdesks.length >= 6) { toast('Maximum 6 desktopuri.'); return; }
  let n = 1; while (settings.vdesks.includes('Desktop ' + n)) n++;
  settings.vdesks.push('Desktop ' + n); settings.vdWalls.push(null); saveSettings();
  if (go) switchDesk(settings.vdesks.length - 1); else updateTvBadge();
  if ($('#tv')) renderTaskView();
}
function removeDesk(i) {
  if (settings.vdesks.length < 2 || i < 0 || i >= settings.vdesks.length) return;
  const t = i > 0 ? i - 1 : 1;
  allWins.forEach(x => { if (x.desk === i) x.desk = t; });
  settings.vdesks.splice(i, 1); settings.vdWalls.splice(i, 1);
  allWins.forEach(x => { if (x.desk > i) x.desk--; });
  const tt = t > i ? t - 1 : t;
  vd.cur = vd.cur === i ? tt : (vd.cur > i ? vd.cur - 1 : vd.cur);
  saveSettings(); applyDeskVisibility(); refocusDesk();
  if ($('#tv')) renderTaskView();
}
function renameDesk(i) {
  const n = prompt('Nume desktop:', deskName(i));
  if (n && n.trim()) { settings.vdesks[i] = n.trim().slice(0, 24); saveSettings(); updateTvBadge(); if ($('#tv')) renderTaskView(); }
}
function moveToDesk(x, i) {
  if (!allWins.has(x) || i < 0 || i >= settings.vdesks.length || x.desk === i) return;
  x.desk = i; applyDeskVisibility(); refocusDesk();
  notify({ body: `„${x.title}” → ${deskName(i)}`, icon: '🖥️', store: false, timeout: 1400 });
  if ($('#tv')) renderTaskView();
}
function deskMoveItems(x) {
  const items = [];
  settings.vdesks.forEach((n, i) => { if (i !== x.desk) items.push({ label: 'Mută pe ' + n, icon: '➜', fn: () => moveToDesk(x, i) }); });
  if (settings.vdesks.length < 6) items.push({ label: 'Mută pe un desktop nou', icon: '＋', fn: () => { addDesk(false); moveToDesk(x, settings.vdesks.length - 1); } });
  return items;
}

/* --- Vizualizare activități --- */
const WIN_MIME = 'application/x-helium-win';
function closeTaskView() { const t = $('#tv'); if (t) t.remove(); }
function toggleTaskView() {
  if ($('#tv')) return closeTaskView();
  const tv = el('div', { id: 'tv', role: 'dialog', 'aria-label': 'Vizualizare activități' });
  tv.addEventListener('click', e => { if (e.target === tv || e.target.classList.contains('tv-grid')) closeTaskView(); });
  document.body.append(tv); renderTaskView();
}
function winGeom(x) {
  const W = desktop.clientWidth, H = desktop.clientHeight;
  if (x.win.classList.contains('max')) return [0, 0, W, H];
  return [parseFloat(x.win.style.left) || 0, parseFloat(x.win.style.top) || 0, parseFloat(x.win.style.width) || 300, parseFloat(x.win.style.height) || 200];
}
function renderTaskView() {
  const tv = $('#tv'); if (!tv) return;
  tv.textContent = '';
  const W = desktop.clientWidth || 1, H = desktop.clientHeight || 1;
  const strip = el('div', { class: 'tv-strip' });
  settings.vdesks.forEach((name, i) => {
    const mini = el('div', { class: 'tv-mini', style: 'background:' + wallCSS(i) });
    allWins.forEach(x => {
      if (x.desk !== i || x.win.classList.contains('min')) return;
      const [l, t, w, h] = winGeom(x);
      mini.append(el('div', { class: 'tv-r', style: `left:${l / W * 100}%;top:${t / H * 100}%;width:${w / W * 100}%;height:${h / H * 100}%` }));
    });
    const tile = el('div', { class: 'tv-desk' + (i === vd.cur ? ' on' : ''), tabindex: '0', onclick: () => { closeTaskView(); switchDesk(i); },
      oncontextmenu: e => { e.preventDefault(); ctxMenu(e.clientX, e.clientY, [
        { label: 'Schimbă fundalul…', icon: '🖼️', fn: () => { closeTaskView(); switchDesk(i, false); settingsApp('personal', i); } },
        { label: 'Redenumește', icon: '✎', fn: () => renameDesk(i) },
        ...(settings.vdesks.length > 1 ? [{ label: 'Elimină desktopul', icon: '✕', fn: () => removeDesk(i) }] : [])]); } },
      mini,
      el('div', { class: 'tv-name' },
        el('span', { text: name, title: 'Dublu-click pentru redenumire', ondblclick: e => { e.stopPropagation(); renameDesk(i); } }),
        ...(settings.vdesks.length > 1 ? [el('button', { class: 'tv-x', title: 'Elimină desktopul', 'aria-label': 'Elimină desktopul', text: '✕', onclick: e => { e.stopPropagation(); removeDesk(i); } })] : [])));
    tile.addEventListener('dragover', e => { if ([...(e.dataTransfer?.types || [])].includes(WIN_MIME)) { e.preventDefault(); tile.classList.add('drop'); } });
    tile.addEventListener('dragleave', () => tile.classList.remove('drop'));
    tile.addEventListener('drop', e => {
      e.preventDefault(); tile.classList.remove('drop');
      const id = +e.dataTransfer.getData(WIN_MIME), x = [...allWins].find(w => w.id === id);
      if (x) moveToDesk(x, i);
    });
    strip.append(tile);
  });
  if (settings.vdesks.length < 6) strip.append(el('button', { class: 'tv-add', onclick: () => addDesk(true) }, el('span', { class: 'tv-plus', text: '+' }), el('span', { text: 'Desktop nou' })));

  const wins = [...allWins].filter(x => x.desk === vd.cur).sort((a, b) => a.id - b.id);
  const grid = el('div', { class: 'tv-grid' });
  if (!wins.length) grid.append(el('p', { class: 'tv-empty', text: 'Nicio fereastră pe acest desktop.' }));
  for (const x of wins) {
    grid.append(el('div', { class: 'tv-card' + (x.isActive() ? ' on' : ''), tabindex: '0', draggable: 'true',
      onclick: () => { closeTaskView(); x.focus(); },
      ondragstart: e => { e.dataTransfer.setData(WIN_MIME, String(x.id)); e.dataTransfer.effectAllowed = 'move'; },
      oncontextmenu: e => { e.preventDefault(); ctxMenu(e.clientX, e.clientY, deskMoveItems(x)); },
      onkeydown: e => { if (e.key === 'Enter') { closeTaskView(); x.focus(); } }
    },
      el('div', { class: 'tv-ch' }, iconEl(iconOf(x.app)), el('span', { class: 'tv-ct', text: x.title }),
        el('button', { class: 'tv-x', title: 'Închide fereastra', 'aria-label': 'Închide fereastra', text: '✕', onclick: e => { e.stopPropagation(); x.close(); setTimeout(renderTaskView, 220); } })),
      el('div', { class: 'tv-cb' }, iconEl(iconOf(x.app)), el('span', { text: x.minimized() ? 'Minimizată' : '' }))));
  }
  tv.append(strip, grid, el('p', { class: 'tv-hint', text: 'Trage o fereastră peste un desktop ca să o muți. Click dreapta pe o fereastră pentru mai multe opțiuni. Taste: 1–6 schimbă desktopul, Alt+Shift+←/→ trece între desktopuri, iar Alt+` (ținut apăsat) comută între ferestre.' }));
}

/* ---------- Notepad ---------- */
function notepad(path) {
  const w = openWindow({ title: 'Notepad', app: 'notepad', w: 520, h: 380 });
  let cur = path || null, dirty = false;
  const ta = el('textarea', { class: 'np', spellcheck: 'false', 'aria-label': 'Text' });
  if (cur) ta.value = fs.read(cur) ?? '';
  const status = el('span', { class: 'np-status' });
  const refresh = () => { w.setTitle((cur ? base(cur) : 'Fără titlu') + (dirty ? ' •' : '')); status.textContent = cur || 'Nesalvat'; };
  function save() {
    let target = cur;
    if (!target) { const p = prompt('Salvează ca (cale):', '/Documents/fara-titlu.txt'); if (!p) return; target = norm(p); }
    const err = fs.write(target, ta.value);
    if (err) { alert(err); return; }
    cur = target; dirty = false; refresh();
  }
  ta.addEventListener('input', () => { if (!dirty) { dirty = true; refresh(); } });
  ta.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); } });
  w.onClose = () => dirty ? confirm('Ai modificări nesalvate. Închizi oricum?') : true;
  w.body.append(el('div', { class: 'tool' }, btn('Salvează', 'Ctrl+S', save, 'primary'), status), ta);
  refresh(); ta.focus();
}

/* ---------- Editor de cod ---------- */
const KW_JS = 'const|let|var|function|return|if|else|for|while|do|class|extends|new|import|export|from|default|async|await|try|catch|finally|throw|switch|case|break|continue|true|false|null|undefined|this|typeof|instanceof|of|in|void|yield';
const KW_PY = 'def|class|return|if|elif|else|for|while|import|from|as|in|not|and|or|is|True|False|None|try|except|finally|with|lambda|pass|break|continue|yield|raise|global';
const LANGS = {
  js: { cls: ['c', 's', 'n', 'k'], re: new RegExp(
    /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)/.source + '|' +
    /("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`)/.source + '|' +
    /\b(\d+(?:\.\d+)?)\b/.source + '|\\b(' + KW_JS + ')\\b', 'g') },
  css: { cls: ['c', 's', 'k', 'n', 't'], re: new RegExp(
    /(\/\*[\s\S]*?\*\/)/.source + '|' +
    /("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')/.source + '|' +
    /(@[\w-]+)/.source + '|' +
    /(#[0-9a-fA-F]{3,8}\b|\b\d*\.?\d+(?:px|em|rem|%|vh|vw|s|ms|deg)?\b)/.source + '|' +
    /([\w-]+)(?=\s*:)/.source, 'g') },
  html: { cls: ['c', 's', 't'], re: new RegExp(
    /(<!--[\s\S]*?-->)/.source + '|' +
    /("[^"\n]*"|'[^'\n]*')/.source + '|' +
    /(<\/?[\w-]+|\/?>)/.source, 'g') },
  py: { cls: ['c', 's', 'n', 'k'], re: new RegExp(
    /(#[^\n]*)/.source + '|' +
    /("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')/.source + '|' +
    /\b(\d+(?:\.\d+)?)\b/.source + '|\\b(' + KW_PY + ')\\b', 'g') }
};
const LANG_OF = { js: 'js', mjs: 'js', ts: 'js', json: 'js', css: 'css', html: 'html', htm: 'html', xml: 'html', svg: 'html', py: 'py' };
function highlight(code, lang) {
  const L = LANGS[lang];
  if (!L || code.length > 150000) return esc(code) + '\n';
  L.re.lastIndex = 0;
  let out = '', last = 0, m;
  while ((m = L.re.exec(code))) {
    if (!m[0].length) { L.re.lastIndex++; continue; }
    const gi = m.findIndex((x, i) => i > 0 && x !== undefined);
    out += esc(code.slice(last, m.index)) + `<span class="t-${L.cls[gi - 1]}">${esc(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  return out + esc(code.slice(last)) + '\n';
}
function codeEditor(path) {
  const w = openWindow({ title: 'Cod', app: 'code', w: 720, h: 480 });
  let cur = path || null, dirty = false, stopMsg = null, forceLang = null;
  const ta = el('textarea', { class: 'ce-ta', spellcheck: 'false', wrap: 'off', 'aria-label': 'Cod' });
  const hl = el('pre', { class: 'ce-hl', 'aria-hidden': 'true' });
  const gut = el('div', { class: 'ce-gut', 'aria-hidden': 'true' });
  ta.value = cur ? (fs.read(cur) ?? '') : '// Scrie cod aici și apasă „Rulează”\nconsole.log("Salut, HeliumOS!");\n';
  const lang = () => forceLang || LANG_OF[ext(cur || 'x.js')] || 'none';
  const render = () => {
    hl.innerHTML = highlight(ta.value, lang());
    gut.textContent = Array.from({ length: ta.value.split('\n').length }, (_, i) => i + 1).join('\n');
    sync();
  };
  const sync = () => { hl.scrollTop = ta.scrollTop; hl.scrollLeft = ta.scrollLeft; gut.scrollTop = ta.scrollTop; };
  const status = el('span', { class: 'np-status' });
  const refresh = () => { w.setTitle((cur ? base(cur) : 'Fără titlu') + (dirty ? ' •' : '')); status.textContent = cur || 'Nesalvat'; };
  function save() {
    let target = cur;
    if (!target) { const p = prompt('Salvează ca (cale):', '/Documents/script.js'); if (!p) return; target = norm(p); }
    const err = fs.write(target, ta.value);
    if (err) { alert(err); return; }
    cur = target; dirty = false; forceLang = null; refresh(); render();
  }
  const out = el('div', { class: 'ce-out' });
  function closeOut() { if (stopMsg) stopMsg(); stopMsg = null; out.classList.remove('open'); out.textContent = ''; }
  function run() {
    const L = lang();
    if (L !== 'html' && L !== 'js') return alert('„Rulează” funcționează pentru fișiere .html și .js.');
    closeOut(); out.classList.add('open');
    out.append(el('div', { class: 'ce-out-h' }, el('span', { text: L === 'html' ? 'Previzualizare' : 'Consolă' }), el('span', { class: 'spacer' }), el('button', { class: 'wb', title: 'Închide', text: '✕', onclick: closeOut })));
    const f = el('iframe', { class: 'frame', src: 'sandbox.html', title: 'Rezultat' });
    if (L === 'html') {
      const dev = { id: 'dev', name: cur ? stripExt(base(cur)) : 'Previzualizare', perms: { notify: true, files: true, fsAll: false, net: true }, temp: true };
      const br = attachAppBridge(f, dev, 'code', null);
      stopMsg = () => br.dispose();
      f.onload = () => f.contentWindow.postMessage({ type: 'app', code: inlineAssets(ta.value, cur ? norm('..', cur) : '/Documents'), meta: { id: 'dev', name: dev.name } }, '*');
      out.append(f);
    } else {
      const log = el('div', { class: 'ce-log' });
      f.style.display = 'none';
      f.onload = () => f.contentWindow.postMessage({ type: 'js', code: ta.value }, '*');
      const h = e => {
        if (e.source !== f.contentWindow) return;
        if (e.data.type === 'notify') { try { const d = JSON.parse(e.data.text); notify({ title: d.title, body: d.body, icon: 'app:code', click: { type: 'app', app: 'code' } }); } catch {} return; }
        if (e.data.type === 'done') { if (!log.childElementCount) log.append(el('div', { class: 'ln', text: '(terminat, fără ieșire)' })); return; }
        log.append(el('div', { class: 'ln ' + (e.data.type === 'error' ? 'err' : e.data.type === 'warn' ? 'warn' : ''), text: e.data.text }));
        log.scrollTop = log.scrollHeight;
      };
      window.addEventListener('message', h);
      stopMsg = () => window.removeEventListener('message', h);
      out.append(log, f);
    }
  }
  ta.addEventListener('input', () => { if (!dirty) { dirty = true; refresh(); } render(); });
  ta.addEventListener('scroll', sync);
  ta.addEventListener('keydown', e => {
    if (e.key === 'Tab') { e.preventDefault(); ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end'); ta.dispatchEvent(new Event('input')); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
    else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); run(); }
  });
  w.onClose = () => { if (dirty && !confirm('Ai modificări nesalvate. Închizi oricum?')) return false; if (stopMsg) stopMsg(); return true; };
  w.body.append(
    el('div', { class: 'tool' }, btn('Salvează', 'Ctrl+S', save, 'primary'), btn('▶ Rulează', 'Ctrl+Enter', run),
      btn('📦 Instalează…', 'Instalează fișierul HTML ca aplicație', () => {
        if (!cur || dirty) save();
        if (!cur) return;
        if (!/\.html?$/i.test(cur)) return alert('Doar fișierele .html pot deveni aplicații.');
        installDialog(cur);
      }),
      btn('Șablon app', 'Pornește de la un șablon de aplicație', () => {
        if (ta.value.trim() && !confirm('Înlocuiești conținutul cu un șablon de aplicație?')) return;
        ta.value = TEMPLATE_APP; forceLang = 'html'; dirty = true; refresh(); render();
      }), status),
    el('div', { class: 'ce' }, gut, el('div', { class: 'ce-code' }, hl, ta)),
    out);
  refresh(); render(); ta.focus();
}

/* ---------- Fișiere (explorer) ---------- */
const INTERNAL = 'application/x-helium-path';
const hasFiles = e => [...(e.dataTransfer?.types || [])].includes('Files');
const KIND_LABEL = { image: 'Imagine', audio: 'Audio', video: 'Video', code: 'Cod sursă', text: 'Document text', bin: 'Fișier', link: 'Scurtătură' };
const fmtDate = t => t ? new Date(t).toLocaleString('ro-RO', { dateStyle: 'short', timeStyle: 'short' }) : '';
const renameDialog = p => { const lnk = /\.lnk$/i.test(p), cur = lnk ? stripLnk(base(p)) : base(p), nn = prompt('Nume nou:', cur); if (nn && nn !== cur) { loadThen(p, () => { const to = norm(lnk ? nn + '.lnk' : nn, norm('..', p)), er = fs.mv(p, to); if (er) alert(er); else recordRename(p, to); }); } };
const deleteDialog = p => deleteMany([p]);
function fileMenuItems(p, x) {
  const k = x.type === 'dir' ? 'dir' : kindOf(x, p);
  return [
    { label: 'Deschide', icon: '▸', fn: () => openPath(p) },
    ...(k === 'link' ? linkMenuItems(p, x) : []),
    ...(x.type === 'file' && !x.bin && /\.html?$/i.test(p) ? [{ label: 'Deschide ca aplicație', icon: '🧩', fn: () => loadThen(p, () => runTempApp(p)) }, { label: 'Instalează ca aplicație…', icon: '📦', fn: () => installDialog(p) }] : []),
    ...(k === 'image' ? [{ label: 'Editează în Paint', icon: '🎨', fn: () => loadThen(p, () => paint(p)) }, { label: 'Setează ca fundal', icon: '🖼️', fn: () => loadThen(p, () => setWallpaperFromPath(p)) }] : []),
    ...(x.type === 'file' ? [{ label: 'Descarcă', icon: '⬇', fn: () => loadThen(p, () => download(p)) }, { label: 'Adaugă în seif criptat…', icon: '🔐', fn: () => vaultAddFromPath(p) }] : []),
    '-',
    { label: 'Copiază', icon: '📋', fn: () => fileClipSet('copy', [p]) },
    { label: 'Taie', icon: '✂️', fn: () => fileClipSet('cut', [p]) },
    ...(x.type === 'dir' ? [{ label: 'Lipește în folder', icon: '📥', disabled: !fileClipHas(), fn: () => pasteInto(p) }] : []),
    ...(k !== 'link' ? [{ label: 'Scurtătură pe desktop', icon: '🔗', fn: () => linkToDesktop(p) }, { label: 'Creează scurtătură', icon: '🔗', fn: () => makeLinkFor(p) }] : []),
    { label: 'Redenumește', icon: '✎', fn: () => renameDialog(p) },
    { label: 'Șterge', icon: '✕', fn: () => deleteDialog(p) }
  ];
}
function uniqueName(dir, stem, extn) {
  let n = stem + extn, i = 2;
  while (node(norm(n, dir))) n = `${stem} (${i++})${extn}`;
  return n;
}

function files(start = '/') {
  const w = openWindow({ title: 'Fișiere', app: 'files', w: 780, h: 500 });
  let cwd = '/', hist = [], hpos = -1, selSet = new Set(), anchor = null, cursor = null, order = [], sortBy = 'name', desc = false, query = '';
  const crumbs = el('div', { class: 'crumbs', title: 'Click pentru a scrie o cale' });
  const pathIn = el('input', { class: 'path', style: 'display:none', spellcheck: 'false', 'aria-label': 'Cale' });
  const searchIn = el('input', { class: 'path search', type: 'search', placeholder: 'Caută', 'aria-label': 'Caută' });
  const bBack = btn('◀', 'Înapoi', () => nav(-1), 'nbtn');
  const bFwd = btn('▶', 'Înainte', () => nav(1), 'nbtn');
  const bUp = btn('↑', 'Folder părinte', () => go(cwd + '/..'), 'nbtn');
  const navPane = el('div', { class: 'nav-pane' });
  const cols = el('div', { class: 'cols' });
  const list = el('div', { class: 'flist', tabindex: '0' });
  const status = el('div', { class: 'statusbar' });

  const accepts = e => hasFiles(e) || [...(e.dataTransfer?.types || [])].includes(INTERNAL);
  function handleDrop(e, dest) {
    const sp = dragPaths(e);
    if (sp.length) moveInto(sp, dest);
    else if (e.dataTransfer.files.length) importFiles([...e.dataTransfer.files], dest);
  }
  const dropTarget = (elm, getDest) => {
    elm.addEventListener('dragover', e => { if (accepts(e)) { e.preventDefault(); e.stopPropagation(); elm.classList.add('drop'); } });
    elm.addEventListener('dragleave', () => elm.classList.remove('drop'));
    elm.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); elm.classList.remove('drop'); handleDrop(e, getDest()); });
  };

  /* --- selecție multiplă --- */
  const selArr = () => [...selSet];
  const selBytes = () => selArr().reduce((a, p) => { const n = node(p); return a + (n && n.type === 'file' ? sizeOf(n) : 0); }, 0);
  const bCopy = btn('Copiază', 'Ctrl+C', () => clipSel('copy'), 'cmd');
  const bCut = btn('Taie', 'Ctrl+X', () => clipSel('cut'), 'cmd');
  const bPaste = btn('Lipește', 'Ctrl+V', () => pasteInto(cwd), 'cmd');
  const bUndo = btn('↶ Anulează', 'Ctrl+Z', () => undoFileOp(), 'cmd');
  const bRedo = btn('↷ Refă', 'Ctrl+Y', () => redoFileOp(), 'cmd');
  const bOpen = btn('Deschide', 'Enter', () => selSet.size && open(selArr()[0]), 'cmd');
  const bRen = btn('Redenumește', 'F2', () => selSet.size === 1 && renameDialog(selArr()[0]), 'cmd');
  const bDel = btn('Șterge', 'Delete', () => selSet.size && deleteMany(selArr()), 'cmd');
  const clipSel = mode => { if (selSet.size) fileClipSet(mode, selArr()); };
  function updateStatus() {
    const clip = fileClipHas() ? ` · în clipboard: ${plural(fileClip.paths.length, 'element', 'elemente')}${fileClip.mode === 'cut' ? ' (tăiate)' : ''}` : '';
    status.textContent = (selSet.size ? `${plural(selSet.size, 'element selectat', 'elemente selectate')}${selBytes() ? ' (' + fmtSize(selBytes()) + ')' : ''}` : `${order.length} ${query ? 'rezultate' : 'elemente'}`) + clip;
    const n = selSet.size;
    bCopy.disabled = bCut.disabled = bOpen.disabled = bDel.disabled = !n; bRen.disabled = n !== 1;
    bPaste.disabled = !fileClipHas();
    bUndo.disabled = !fileUndo.length; bUndo.title = fileUndo.length ? 'Anulează: ' + fileUndo[fileUndo.length - 1].label : 'Nimic de anulat';
    bRedo.disabled = !fileRedo.length; bRedo.title = fileRedo.length ? 'Refă: ' + fileRedo[fileRedo.length - 1].label : 'Nimic de refăcut';
  }
  function applySel() { list.querySelectorAll('.frow').forEach(r => r.classList.toggle('sel', selSet.has(r.dataset.p))); updateStatus(); }
  function selectOnly(p) { selSet = new Set(p ? [p] : []); anchor = cursor = p; applySel(); }
  function toggleSel(p) { if (selSet.has(p)) selSet.delete(p); else selSet.add(p); anchor = cursor = p; applySel(); }
  function selectRange(p) {
    const a = order.indexOf(anchor), b = order.indexOf(p);
    if (a < 0) return selectOnly(p);
    const [i, j] = a < b ? [a, b] : [b, a]; selSet = new Set(order.slice(i, j + 1)); cursor = p; applySel();
  }
  const rowClick = (e, p) => { if (e.shiftKey) selectRange(p); else if (e.ctrlKey || e.metaKey) toggleSel(p); else selectOnly(p); };

  function go(p, push = true) {
    cwd = norm(p);
    const n = node(cwd); if (!n || n.type !== 'dir') cwd = '/';
    if (push) { hist = hist.slice(0, hpos + 1); if (hist[hist.length - 1] !== cwd) hist.push(cwd); hpos = hist.length - 1; }
    selSet = new Set(); anchor = cursor = null; query = ''; searchIn.value = ''; render();
  }
  function nav(d) { const np = hpos + d; if (np < 0 || np >= hist.length) return; hpos = np; go(hist[hpos], false); }
  const open = p => node(p).type === 'dir' ? go(p) : openPath(p);

  function editPath() { crumbs.style.display = 'none'; pathIn.style.display = ''; pathIn.value = cwd; pathIn.focus(); pathIn.select(); }
  function endEdit() { pathIn.style.display = 'none'; crumbs.style.display = ''; }
  crumbs.addEventListener('click', e => { if (e.target === crumbs) editPath(); });
  pathIn.addEventListener('keydown', e => { if (e.key === 'Enter') { const v = pathIn.value; endEdit(); go(v); } else if (e.key === 'Escape') endEdit(); });
  pathIn.addEventListener('blur', endEdit);
  searchIn.addEventListener('input', () => { query = searchIn.value.trim(); selSet = new Set(); anchor = cursor = null; render(); });

  function renderCrumbs() {
    crumbs.textContent = '';
    crumbs.append(el('button', { class: 'crumb', text: 'Computer', onclick: () => go('/') }));
    let acc = '';
    for (const s of split(cwd)) { acc += '/' + s; const p = acc; crumbs.append(el('span', { class: 'crumb-sep', text: '▸' }), el('button', { class: 'crumb', text: s, onclick: () => go(p) })); }
  }
  function renderNav() {
    navPane.textContent = '';
    const item = (icon, label, p) => {
      const b = el('button', { class: 'nav-i' + (cwd === p ? ' on' : ''), onclick: () => go(p) }, el('span', { text: icon }), el('span', { text: label }));
      dropTarget(b, () => p); return b;
    };
    const trashItem = el('button', { class: 'nav-i', onclick: () => recycleBin() }, el('span', { text: '🗑️' }), el('span', { text: 'Coș de reciclare' }));
    trashItem.addEventListener('dragover', e => { if ([...(e.dataTransfer?.types || [])].includes(INTERNAL)) { e.preventDefault(); e.stopPropagation(); trashItem.classList.add('drop'); } });
    trashItem.addEventListener('dragleave', () => trashItem.classList.remove('drop'));
    trashItem.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); trashItem.classList.remove('drop'); const sp = dragPaths(e); if (sp.length) deleteMany(sp, true); });
    navPane.append(el('div', { class: 'nav-h', text: 'Favorite' }),
      item('🖥️', 'Desktop', '/Desktop'), item('📄', 'Documente', '/Documents'), item('🖼️', 'Imagini', '/Pictures'), item('🎵', 'Muzică', '/Music'),
      el('div', { class: 'nav-h', text: 'Computer' }), item('💽', 'Rădăcină', '/'), trashItem, ...mountNavItems(go, cwd));
  }
  function renderCols() {
    cols.textContent = '';
    for (const [k, l, c] of [['name', 'Nume', 'c-name'], ['date', 'Data modificării', 'c-date'], ['type', 'Tip', 'c-type'], ['size', 'Mărime', 'c-size']])
      cols.append(el('button', { class: 'ch ' + c, text: l + (sortBy === k ? (desc ? ' ▾' : ' ▴') : ''), onclick: () => { if (sortBy === k) desc = !desc; else { sortBy = k; desc = false; } render(); } }));
  }
  function entries() {
    let arr = [];
    if (query) {
      const q = query.toLowerCase();
      (function walk(d) { for (const [nm, x] of fs.ls(d)) { if (d === '/' && nm === '.Trash') continue; const p = norm(nm, d); if (nm.toLowerCase().includes(q)) arr.push([p, nm, x, p.slice(cwd === '/' ? 1 : cwd.length + 1)]); if (x.type === 'dir') walk(p); } })(cwd);
    } else arr = fs.ls(cwd).filter(([nm]) => !(cwd === '/' && nm === '.Trash')).map(([nm, x]) => [norm(nm, cwd), nm, x, nm]);
    const key = { name: a => a[1].toLowerCase(), date: a => a[2].mtime || 0, type: a => a[2].type === 'dir' ? '' : kindOf(a[2], a[0]), size: a => a[2].type === 'dir' ? -1 : sizeOf(a[2]) }[sortBy];
    arr.sort((a, b) => { if (a[2].type !== b[2].type) return a[2].type === 'dir' ? -1 : 1; const x = key(a), y = key(b), r = x < y ? -1 : x > y ? 1 : 0; return desc ? -r : r; });
    return arr;
  }
  function multiMenu() {
    const ps = selArr(), n = plural(ps.length, 'element', 'elemente');
    return [
      { label: `Copiază (${n})`, icon: '📋', fn: () => clipSel('copy') },
      { label: `Taie (${n})`, icon: '✂️', fn: () => clipSel('cut') },
      '-', { label: `Șterge (${n})`, icon: '✕', fn: () => deleteMany(ps) }
    ];
  }
  function render() {
    renderCrumbs(); renderNav(); renderCols();
    list.textContent = '';
    const arr = entries();
    order = arr.map(a => a[0]);
    selSet = new Set([...selSet].filter(p => node(p)));
    const cn = node(cwd);
    if (!arr.length && cn && cn.offline) {
      const rec = settings.mounts.find(r => r.id === cn.mountRoot);
      list.append(el('div', { class: 'empty' }, el('p', { text: 'Discul este deconectat.' }), btn('Reconectează', '', async () => { if (rec && await reconnectMount(rec.id)) render(); }, 'primary')));
    } else if (!arr.length) list.append(el('p', { class: 'empty', text: query ? 'Nu s-a găsit nimic.' : 'Folderul e gol. Trage fișiere aici din calculator.' }));
    const cutSet = fileClip.mode === 'cut' ? new Set(fileClip.paths) : null;
    for (const [p, , x, label] of arr) {
      const isDir = x.type === 'dir', k = isDir ? 'dir' : kindOf(x, p);
      const row = el('div', { class: 'frow' + (selSet.has(p) ? ' sel' : '') + (cutSet && cutSet.has(p) ? ' cut' : ''), tabindex: '-1', draggable: 'true', 'data-p': p,
        onclick: e => rowClick(e, p), ondblclick: () => open(p),
        oncontextmenu: e => { e.preventDefault(); e.stopPropagation(); if (!selSet.has(p)) selectOnly(p); ctxMenu(e.clientX, e.clientY, selSet.size > 1 ? multiMenu() : fileMenuItems(p, x)); },
        ondragstart: e => { if (!selSet.has(p)) selectOnly(p); e.dataTransfer.setData(INTERNAL, selSet.size > 1 ? JSON.stringify(selArr()) : p); e.dataTransfer.effectAllowed = 'move'; }
      },
        el('span', { class: 'c-name' }, k === 'link' ? iconEl(linkIcon(x, p)) : el('span', { text: isDir ? (x.mountRoot ? '💾' : '📁') : FILE_ICON[k] }), el('span', { class: 'nm', text: k === 'link' ? stripLnk(label) : label })),
        el('span', { class: 'c-date', text: fmtDate(x.mtime) }),
        el('span', { class: 'c-type', text: isDir ? 'Folder de fișiere' : KIND_LABEL[k] }),
        el('span', { class: 'c-size', text: isDir ? '' : fmtSize(sizeOf(x)) }));
      if (isDir) dropTarget(row, () => p);
      list.append(row);
    }
    bBack.disabled = hpos <= 0; bFwd.disabled = hpos >= hist.length - 1; bUp.disabled = cwd === '/';
    updateStatus();
  }

  const newFile = () => {
    const n = prompt('Nume fișier:', uniqueName(cwd, 'Fișier nou', '.txt')); if (!n) return;
    const p = norm(n, cwd); if (node(p)) return alert('Există deja.');
    const e = fs.write(p, ''); if (e) alert(e); else { recordCreate(p, false); selSet = new Set([p]); anchor = cursor = p; }
  };
  const newFolder = () => {
    const n = prompt('Nume folder:', uniqueName(cwd, 'Folder nou', '')); if (!n) return;
    const p = norm(n, cwd), e = fs.mkdir(p); if (e) alert(e); else { recordCreate(p, true); selSet = new Set([p]); anchor = cursor = p; }
  };
  const doImport = () => pickFiles('', f => importFiles(f, cwd));
  list.addEventListener('click', e => { if (e.target === list) selectOnly(null); });
  list.addEventListener('contextmenu', e => {
    if (e.target.closest('.frow')) return;
    e.preventDefault();
    ctxMenu(e.clientX, e.clientY, [
      { label: 'Lipește', icon: '📥', disabled: !fileClipHas(), fn: () => pasteInto(cwd) },
      { label: fileUndo.length ? 'Anulează: ' + fileUndo[fileUndo.length - 1].label : 'Anulează', icon: '↶', disabled: !fileUndo.length, fn: () => undoFileOp() },
      { label: 'Refă', icon: '↷', disabled: !fileRedo.length, fn: () => redoFileOp() },
      '-', { label: 'Selectează tot', icon: '☑', fn: () => { selSet = new Set(order); anchor = order[0]; applySel(); } },
      '-', { label: 'Fișier nou', icon: '📄', fn: newFile }, { label: 'Folder nou', icon: '📁', fn: newFolder }, { label: 'Scurtătură nouă…', icon: '🔗', fn: () => newLinkDialog(cwd) }, { label: 'Importă fișiere…', icon: '⬆', fn: doImport },
      '-', { label: 'Reîmprospătează', icon: '⟳', fn: render }]);
  });
  list.addEventListener('keydown', e => {
    const mod = e.ctrlKey || e.metaKey;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault(); if (!order.length) return;
      const i = order.indexOf(cursor), ni = Math.max(0, Math.min(order.length - 1, (i < 0 ? (e.key === 'ArrowDown' ? -1 : order.length) : i) + (e.key === 'ArrowDown' ? 1 : -1)));
      if (e.shiftKey) { if (anchor === null) anchor = order[Math.max(0, i)]; selectRange(order[ni]); } else selectOnly(order[ni]);
      cursor = order[ni]; const r = [...list.querySelectorAll('.frow')].find(x => x.dataset.p === cursor); if (r) r.scrollIntoView({ block: 'nearest' });
    } else if (mod && e.code === 'KeyA') { e.preventDefault(); selSet = new Set(order); anchor = order[0]; applySel(); }
    else if (mod && e.code === 'KeyC') { e.preventDefault(); clipSel('copy'); }
    else if (mod && e.code === 'KeyX') { e.preventDefault(); clipSel('cut'); }
    else if (mod && e.code === 'KeyV') { e.preventDefault(); pasteInto(cwd); }
    else if (mod && e.code === 'KeyZ' && !e.shiftKey) { e.preventDefault(); undoFileOp(); }
    else if (mod && (e.code === 'KeyY' || (e.code === 'KeyZ' && e.shiftKey))) { e.preventDefault(); redoFileOp(); }
    else if (e.key === 'Enter' && selSet.size) open(selArr()[0]);
    else if (e.key === 'Delete' && selSet.size) deleteMany(selArr());
    else if (e.key === 'F2' && selSet.size === 1) renameDialog(selArr()[0]);
    else if (e.key === 'Escape') selectOnly(null);
    else if (e.key === 'Backspace') go(cwd + '/..');
  });
  dropTarget(list, () => cwd);

  w.body.append(
    el('div', { class: 'tool' }, bBack, bFwd, bUp, crumbs, pathIn, searchIn),
    el('div', { class: 'cmdbar' },
      btn('Fișier nou', '', newFile, 'cmd'), btn('Folder nou', '', newFolder, 'cmd'), btn('Scurtătură', 'Scurtătură nouă', () => newLinkDialog(cwd), 'cmd'), btn('Importă', 'Adaugă fișiere din calculator', doImport, 'cmd'),
      el('span', { class: 'cmd-sep' }), bCopy, bCut, bPaste, bUndo, bRedo,
      el('span', { class: 'cmd-sep' }), bOpen, bRen, bDel),
    el('div', { class: 'exp' }, navPane, el('div', { class: 'exp-main' }, cols, list, status)));
  const onFs = () => render();
  const onSelect = e => { const ps = (e.paths || []).filter(p => norm('..', p) === cwd && node(p)); if (ps.length) { selSet = new Set(ps); anchor = cursor = ps[0]; } };
  window.addEventListener('files-select', onSelect);
  window.addEventListener('fs-change', onFs);
  w.onClose = () => { window.removeEventListener('fs-change', onFs); window.removeEventListener('files-select', onSelect); };
  go(start);
}

/* ---------- Imagini ---------- */
function imageViewer(path) {
  const w = openWindow({ title: 'Imagini', app: 'images', w: 680, h: 480 });
  const stage = el('div', { class: 'iv' });
  const status = el('span', { class: 'np-status' });
  let list = [], idx = 0, url = null, img = null, zoom = null, token = 0;
  const imagesIn = d => fs.ls(d).filter(([nm, x]) => x.type === 'file' && kindOf(x, norm(nm, d)) === 'image').map(([nm]) => norm(nm, d));
  const applyZoom = () => {
    if (!img) return;
    if (zoom == null) img.style.cssText = '';
    else { img.style.maxWidth = 'none'; img.style.maxHeight = 'none'; img.style.width = (img.naturalWidth || 300) * zoom + 'px'; }
  };
  const cur = () => zoom ?? (img && img.naturalWidth ? img.clientWidth / img.naturalWidth : 1);
  const zoomBy = f => { if (!img) return; zoom = Math.min(8, Math.max(0.05, cur() * f)); applyZoom(); };
  function show(i) {
    const t = ++token, p = list[i], n = node(p); if (!n) return;
    if (n.lazy) { ensureLoaded(p).then(() => show(i)).catch(e => alert('Nu s-a putut citi: ' + (e && e.message || e))); return; }
    const u = fileURL(n, p);
    if (url) URL.revokeObjectURL(url);
    url = u; idx = i; zoom = null;
    img = el('img', { alt: base(p), src: u }); img.onload = applyZoom;
    stage.textContent = ''; stage.append(img);
    w.setTitle(base(p)); status.textContent = `${i + 1} / ${list.length}`;
  }
  const step = d => { if (list.length) show((idx + d + list.length) % list.length); };
  function showEmpty() {
    stage.textContent = '';
    stage.append(el('div', { class: 'empty' }, el('p', { text: 'Nu e nicio imagine deschisă.' }), btn('Importă imagini', '', pick, 'primary')));
  }
  function pick() {
    pickFiles('image/*', async f => {
      const paths = await importFiles(f, '/Pictures');
      if (paths.length) { list = imagesIn('/Pictures'); show(Math.max(0, list.indexOf(paths[0]))); }
    });
  }
  stage.addEventListener('wheel', e => { if (!img) return; e.preventDefault(); zoomBy(e.deltaY < 0 ? 1.1 : 0.9); }, { passive: false });
  w.onClose = () => { if (url) URL.revokeObjectURL(url); };
  w.body.append(el('div', { class: 'tool' },
    btn('‹', 'Anterioara', () => step(-1)), btn('›', 'Următoarea', () => step(1)),
    btn('−', 'Micșorează', () => zoomBy(0.8)), btn('+', 'Mărește', () => zoomBy(1.25)),
    btn('Potrivește', '', () => { zoom = null; applyZoom(); }), btn('100%', '', () => { zoom = 1; applyZoom(); }),
    btn('Importă', '', pick), btn('Fundal', 'Setează ca fundal', () => { if (list[idx]) setWallpaperFromPath(list[idx]); }), btn('Paint', 'Editează în Paint', () => { if (list[idx]) paint(list[idx]); }), status), stage);
  if (path) { list = imagesIn(norm('..', path)); show(Math.max(0, list.indexOf(path))); }
  else { list = imagesIn('/Pictures'); if (list.length) show(0); else showEmpty(); }
}

/* ---------- Muzică și video ---------- */
function player(path) {
  const w = openWindow({ title: 'Muzică', app: 'music', w: 540, h: 450 });
  w.body.classList.add('mp');
  let dir = path ? norm('..', path) : '/Music', list = [], idx = -1, url = null, ctx = null, analyser = null, raf = 0, data = null;
  const audio = el('audio', { controls: '' });
  const video = el('video', { controls: '', style: 'display:none' });
  const canvas = el('canvas');
  const now = el('div', { class: 'mp-now', text: 'Nimic în redare' });
  const listEl = el('div', { class: 'mp-list' });
  const mediaIn = d => fs.ls(d).filter(([nm, x]) => x.type === 'file' && ['audio', 'video'].includes(kindOf(x, norm(nm, d)))).map(([nm]) => norm(nm, d));
  function renderList() {
    listEl.textContent = '';
    list.forEach((p, i) => listEl.append(el('button', { class: 'mp-item' + (i === idx ? ' on' : ''), text: base(p), onclick: () => play(i) })));
    if (!list.length) listEl.append(el('p', { class: 'empty', style: 'color:#9fb0d8', text: 'Nicio melodie încă. Apasă „+ Adaugă” sau trage fișiere audio pe desktop.' }));
  }
  function play(i) {
    const p = list[i], n = node(p); if (!n) return;
    if (n.lazy) { ensureLoaded(p).then(() => play(i)).catch(e => alert('Nu s-a putut citi: ' + (e && e.message || e))); return; }
    const u = fileURL(n, p); if (url) URL.revokeObjectURL(url); url = u; idx = i;
    const isVid = kindOf(n, p) === 'video';
    audio.pause(); video.pause();
    canvas.style.display = isVid ? 'none' : ''; video.style.display = isVid ? '' : 'none';
    const m = isVid ? video : audio; m.src = u; m.play().catch(() => {});
    now.textContent = base(p); w.setTitle(base(p)); renderList();
  }
  const next = () => { if (idx + 1 < list.length) play(idx + 1); };
  audio.addEventListener('ended', next); video.addEventListener('ended', next);
  function draw() {
    raf = requestAnimationFrame(draw);
    if (!canvas.isConnected) return cancelAnimationFrame(raf);
    const W = canvas.width = canvas.clientWidth, H = canvas.height = canvas.clientHeight, c = canvas.getContext('2d');
    analyser.getByteFrequencyData(data);
    const bw = W / data.length;
    for (let i = 0; i < data.length; i++) {
      const h = data[i] / 255 * H;
      c.fillStyle = `rgba(${110 + i},${190 - i},255,.85)`; c.fillRect(i * bw + 1, H - h, Math.max(1, bw - 2), h);
    }
  }
  audio.addEventListener('play', () => {
    if (ctx) { ctx.resume(); return; }
    try {
      ctx = new AudioContext();
      const src = ctx.createMediaElementSource(audio);
      analyser = ctx.createAnalyser(); analyser.fftSize = 128; data = new Uint8Array(analyser.frequencyBinCount);
      src.connect(analyser); analyser.connect(ctx.destination); ctx.resume(); draw();
    } catch { ctx = null; }
  });
  w.onClose = () => { cancelAnimationFrame(raf); audio.pause(); video.pause(); if (ctx) ctx.close(); if (url) URL.revokeObjectURL(url); };
  w.body.append(
    el('div', { class: 'tool' }, btn('+ Adaugă', 'Importă muzică', () => pickFiles('audio/*,video/*', async f => { await importFiles(f, '/Music'); dir = '/Music'; list = mediaIn(dir); idx = -1; renderList(); if (list.length && !audio.src) play(0); })), btn('⏮', 'Anterioara', () => idx > 0 && play(idx - 1)), btn('⏭', 'Următoarea', next)),
    el('div', { class: 'mp-top' }, canvas, video), now, audio, listEl);
  list = mediaIn(dir);
  if (path) idx = list.indexOf(path);
  renderList();
  if (idx >= 0) play(idx);
}

/* ---------- Terminal ---------- */
function tokenize(s) {
  const t = []; let cur = '', q = null, has = false;
  const flush = () => { if (cur || has) t.push(cur); cur = ''; has = false; };
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) { if (ch === q) q = null; else cur += ch; }
    else if (ch === '"' || ch === "'") { q = ch; has = true; }
    else if (/\s/.test(ch)) flush();
    else if (ch === '>') { flush(); if (s[i + 1] === '>') { t.push({ op: '>>' }); i++; } else t.push({ op: '>' }); }
    else cur += ch;
  }
  flush(); return t;
}
function terminal() {
  const w = openWindow({ title: 'Terminal', app: 'terminal', w: 640, h: 390 });
  let cwd = '/'; const hist = []; let hi = 0;
  const out = el('div'); const ps1 = el('span', { class: 'ps1' });
  const inp = el('input', { class: 'term-in', spellcheck: 'false', autocomplete: 'off', 'aria-label': 'Comandă' });
  w.body.classList.add('term'); w.body.append(out, el('div', { class: 'term-line' }, ps1, inp));
  w.body.addEventListener('click', () => { if (!getSelection().toString()) inp.focus(); });
  const setPs1 = () => { ps1.textContent = `user@helium:${cwd}$`; };
  const print = (text, cls = '') => { out.append(el('div', { class: 'ln ' + cls, text })); w.body.scrollTop = w.body.scrollHeight; };
  const need = (a, n, u) => { if (a.length < n) throw `utilizare: ${u}`; };
  const cmds = {
    help: () => 'Comenzi: help ls cd pwd cat echo mkdir touch rm [-r] mv cp trash notify remind reminders desk run lnk search mount clear date whoami open edit apps neofetch\nRedirecționare: echo salut > fisier.txt  (sau >> ca să adaugi)\nrun <aplicație|cale|adresă>  ca Win+R;  lnk <țintă> [nume]  creează scurtătură pe desktop\nopen <aplicație|fișier>  ex: open music, open /Pictures/poza.png\nedit <fișier>  deschide în editorul de cod',
    ls: a => { const p = norm(a[0] || '.', cwd), n = node(p); if (!n) throw `ls: ${a[0]}: nu există`; return n.type === 'file' ? base(p) : fs.ls(p).map(([nm, x]) => x.type === 'dir' ? nm + '/' : nm).join('  '); },
    cd: a => { const p = norm(a[0] || '/', cwd), n = node(p); if (!n || n.type !== 'dir') throw `cd: ${a[0] || '/'}: nu e folder`; cwd = p; return ''; },
    pwd: () => cwd,
    cat: a => { need(a, 1, 'cat <fișier>'); return a.map(f => { const p = norm(f, cwd), n = node(p); if (!n || n.type !== 'file') throw `cat: ${f}: fișier inexistent`; if (n.lazy) throw `cat: ${f}: fișier de pe disc, neîncărcat (deschide-l cu "open" sau "edit")`; if (n.bin) throw `cat: ${f}: fișier binar`; return n.content.replace(/\n$/, ''); }).join('\n'); },
    echo: a => a.join(' '),
    mkdir: a => { need(a, 1, 'mkdir <folder>'); a.forEach(f => { const e = fs.mkdir(norm(f, cwd)); if (e) throw `mkdir: ${e}`; }); return ''; },
    touch: a => { need(a, 1, 'touch <fișier>'); a.forEach(f => { const p = norm(f, cwd); if (!node(p)) { const e = fs.write(p, ''); if (e) throw `touch: ${e}`; } }); return ''; },
    rm: a => { const r = a.includes('-r'); const t = a.filter(x => x !== '-r'); need(t, 1, 'rm [-r] <cale>'); t.forEach(f => { const e = fs.rm(norm(f, cwd), r); if (e) throw `rm: ${e}`; }); return ''; },
    mv: a => { need(a, 2, 'mv <sursă> <destinație>'); const e = fs.mv(norm(a[0], cwd), norm(a[1], cwd)); if (e) throw `mv: ${e}`; return ''; },
    cp: a => { need(a, 2, 'cp <sursă> <destinație>'); const e = fs.cp(norm(a[0], cwd), norm(a[1], cwd)); if (e) throw `cp: ${e}`; return ''; },
    search: a => {
      need(a, 1, 'search <text>   (filtre: a: f: s: c: w: n:)');
      const r = gsSearch(a.join(' ')).flat.slice(0, 20);
      return r.length ? r.map(x => `[${x.tag || GS_TAGS[x.cat]}] ${x.title}${x.sub ? '  —  ' + x.sub : ''}`).join('\n') : 'Nimic găsit.';
    },
    mount: a => {
      if (a[0] === 'add') { mountDialog(); return ''; }
      return settings.mounts.length ? settings.mounts.map(r => `${mountOnline(r) ? 'conectat   ' : 'deconectat'}  ${r.mode === 'read' ? 'r ' : 'rw'}  ${mountPath(r)}`).join('\n') : 'Niciun disc montat. Folosește „mount add” sau „Montează folder…” din Fișiere.';
    },
    run: a => { need(a, 1, 'run <aplicație|cale|adresă>'); if (!runCommand(a.join(' '))) throw 'nu am găsit ținta'; return ''; },
    lnk: a => {
      need(a, 1, 'lnk <țintă> [nume]'); const t = a[0], abs = norm(t, cwd);
      if (!resolveApp(t) && !node(abs) && !isUrl(t)) throw `țintă inexistentă: ${t}`;
      const target = node(abs) && !resolveApp(t) ? abs : t, p = makeLink('/Desktop', a[1] || targetName(target), target, false);
      return p ? 'Scurtătură creată: ' + p : '';
    },
    desk: a => {
      if (!a.length) return settings.vdesks.map((n, i) => `${i === vd.cur ? '*' : ' '} ${i + 1}  ${n}`).join('\n');
      if (a[0] === 'new') { addDesk(true); return ''; }
      const i = parseInt(a[0], 10) - 1;
      if (isNaN(i) || i < 0 || i >= settings.vdesks.length) throw 'desktop inexistent (scrie desk pentru listă)';
      switchDesk(i); return '';
    },
    notify: a => { need(a, 1, 'notify <mesaj>'); notify({ title: 'Terminal', body: a.join(' '), icon: 'app:terminal', click: { type: 'app', app: 'terminal' } }); return ''; },
    remind: a => { need(a, 2, 'remind <timp> <mesaj>   ex: remind 10m scoate pâinea'); const sec = parseDelay(a[0]); if (!sec) throw 'timp invalid (exemple: 30s, 10m, 2h, 1d)'; addReminder(a.slice(1).join(' '), sec); return `Memento peste ${fmtDur(sec)}.`; },
    reminders: () => settings.reminders.length ? settings.reminders.map(r => `${new Date(r.at).toLocaleString('ro-RO')}  ${r.text}`).join('\n') : 'Niciun memento.',
    trash: a => { need(a, 1, 'trash <cale>'); a.forEach(f => { const e = fs.trash(norm(f, cwd)); if (e) throw `trash: ${e}`; }); return ''; },
    clear: () => { out.textContent = ''; return ''; },
    date: () => new Date().toString(),
    whoami: () => 'user',
    apps: () => Object.keys(apps).join('  '),
    open: a => { need(a, 1, 'open <aplicație|fișier>'); if (Object.hasOwn(apps, a[0])) { apps[a[0]].open(); return ''; } const p = norm(a[0], cwd); if (!node(p)) throw `open: ${a[0]}: nu există`; openPath(p); return ''; },
    edit: a => { need(a, 1, 'edit <fișier>'); const p = norm(a[0], cwd), n = node(p); if (!n || n.type !== 'file' || n.bin) throw `edit: ${a[0]}: nu e fișier text`; codeEditor(p); return ''; },
    neofetch: () => `user@helium\n-----------\nOS: HeliumOS 0.13 (Aero)\nMotor: ${(navigator.userAgent.match(/Chrome\/[\d.]+/) || ['Chromium'])[0]}\nTemă: ${settings.theme}\nAplicații: ${Object.keys(apps).length}\nStocare: IndexedDB`
  };
  function exec(v) {
    const t = tokenize(v); let target = null, mode = null;
    const ri = t.findIndex(x => typeof x === 'object');
    if (ri >= 0) {
      mode = t[ri].op; target = t[ri + 1];
      if (typeof target !== 'string' || !target) return print(`Sintaxă: lipsește fișierul după ${mode}`, 'err');
      t.length = ri;
    }
    const [cmd, ...args] = t; if (!cmd) return;
    if (!Object.hasOwn(cmds, cmd)) return print(`${cmd}: comandă necunoscută. Scrie help.`, 'err');
    try {
      const res = cmds[cmd](args) ?? '';
      if (target) {
        const p = norm(target, cwd); let content = res + '\n';
        if (mode === '>>') { const old = fs.read(p) ?? ''; content = old + (old && !old.endsWith('\n') ? '\n' : '') + content; }
        const e = fs.write(p, content); if (e) throw e;
      } else if (res) print(res);
    } catch (e) { print(String(e), 'err'); }
  }
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const v = inp.value; print(`${ps1.textContent} ${v}`, 'cmd'); inp.value = '';
      if (v.trim()) { hist.push(v); hi = hist.length; exec(v); }
      setPs1();
    } else if (e.key === 'ArrowUp') { if (hi > 0) { hi--; inp.value = hist[hi]; } e.preventDefault(); }
    else if (e.key === 'ArrowDown') { if (hi < hist.length - 1) { hi++; inp.value = hist[hi]; } else { hi = hist.length; inp.value = ''; } e.preventDefault(); }
  });
  print('HeliumOS Terminal. Scrie help pentru comenzi.');
  setPs1(); inp.focus();
}

/* ---------- Calculator ---------- */
function calc(expr) {
  const t = expr.match(/\d+\.?\d*|\.\d+|[()+\-*/]/g) || []; let i = 0;
  const peek = () => t[i], next = () => t[i++];
  function prim() { const x = next(); if (x === '(') { const v = add(); if (next() !== ')') throw 0; return v; } if (x === '-') return -prim(); if (x === '+') return prim(); const n = parseFloat(x); if (isNaN(n)) throw 0; return n; }
  function mul() { let v = prim(); while (peek() === '*' || peek() === '/') { const o = next(), r = prim(); v = o === '*' ? v * r : v / r; } return v; }
  function add() { let v = mul(); while (peek() === '+' || peek() === '-') { const o = next(), r = mul(); v = o === '+' ? v + r : v - r; } return v; }
  const r = add(); if (i < t.length) throw 0; return r;
}
function calculator() {
  const w = openWindow({ title: 'Calculator', app: 'calc', w: 290, h: 410 });
  let expr = '';
  const disp = el('div', { class: 'calc-d', text: '0' });
  const show = () => { disp.textContent = expr || '0'; };
  const press = k => {
    if (k === 'C') expr = '';
    else if (k === '⌫') expr = expr.slice(0, -1);
    else if (k === '=') { try { const r = calc(expr.replace(/×/g, '*').replace(/÷/g, '/')); expr = Number.isFinite(r) ? String(+r.toPrecision(12)) : 'Eroare'; } catch { expr = 'Eroare'; } }
    else { if (expr === 'Eroare') expr = ''; expr += k; }
    show();
  };
  const keys = ['C', '(', ')', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '⌫', '='];
  const grid = el('div', { class: 'calc-g' }, keys.map(k => el('button', { class: /[÷×\-+C⌫()]/.test(k) ? 'op' : k === '=' ? 'eq' : '', text: k, onclick: () => press(k) })));
  w.body.append(el('div', { class: 'calc', style: 'flex:1' }, disp, grid));
  w.body.addEventListener('keydown', e => {
    if (/^[0-9+\-*/().]$/.test(e.key)) press(e.key === '*' ? '×' : e.key === '/' ? '÷' : e.key);
    else if (e.key === 'Enter') press('='); else if (e.key === 'Backspace') press('⌫'); else if (e.key === 'Escape') press('C');
  });
  w.body.tabIndex = 0; w.body.focus();
}

/* ---------- Browser ---------- */
function browser(url) {
  const w = openWindow({ title: 'Browser', app: 'browser', w: 800, h: 510 });
  const addr = el('input', { class: 'path', placeholder: 'Caută sau scrie o adresă', spellcheck: 'false', 'aria-label': 'Adresă' });
  const frame = el('iframe', { class: 'frame', referrerpolicy: 'no-referrer', sandbox: 'allow-scripts allow-forms allow-same-origin allow-popups' });
  const go = () => {
    const v = addr.value.trim(); if (!v) return;
    let u;
    if (/^https?:\/\//i.test(v)) u = v;
    else if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(v)) u = 'https://' + v;
    else u = 'https://duckduckgo.com/?q=' + encodeURIComponent(v);
    addr.value = u; frame.src = u;
  };
  addr.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  w.body.append(el('div', { class: 'tool' }, addr,
    btn('Du-te', '', go, 'primary'),
    btn('⟳', 'Reîncarcă', () => { if (frame.src) frame.src = frame.src; }),
    btn('↗', 'Deschide într-un tab real', () => { if (addr.value) window.open(addr.value, '_blank'); }),
    btn('🔗', 'Creează scurtătură pe desktop', () => { const v = addr.value.trim(); if (!isUrl(v)) return alert('Încarcă mai întâi o pagină.'); makeLink('/Desktop', targetName(v), v); })), frame);
  addr.focus();
  if (url) { addr.value = url; go(); }
}

/* ---------- meniu contextual, imagini (fundal / pictograme) ---------- */
let ctxEl = null;
function closeCtx() { if (ctxEl) { ctxEl.remove(); ctxEl = null; } }
function ctxMenu(x, y, items) {
  closeCtx();
  const m = el('div', { class: 'ctx', role: 'menu' });
  for (const it of items) {
    if (it === '-') { m.append(el('div', { class: 'ctx-sep' })); continue; }
    const props = { class: 'ctx-i', role: 'menuitem', onclick: () => { closeCtx(); it.fn(); } };
    if (it.disabled) props.disabled = '';
    m.append(el('button', props, el('span', { class: 'ctx-ic', text: it.icon || '' }), el('span', { text: it.label })));
  }
  document.body.append(m); ctxEl = m;
  m.style.left = Math.max(2, Math.min(x, innerWidth - m.offsetWidth - 4)) + 'px';
  m.style.top = Math.max(2, Math.min(y, innerHeight - m.offsetHeight - 4)) + 'px';
}

async function loadImg(blob) {
  const u = URL.createObjectURL(blob);
  try { const i = new Image(); i.src = u; await i.decode(); return i; } finally { URL.revokeObjectURL(u); }
}
async function shrinkToDataURL(blob, { max = 2560, square = 0, cover = false, type = 'image/jpeg', q = 0.9 } = {}) {
  const img = await loadImg(blob);
  const iw = img.naturalWidth || square || 256, ih = img.naturalHeight || square || 256;
  const c = document.createElement('canvas'), g = c.getContext('2d');
  if (square) {
    c.width = c.height = square;
    const s = cover ? Math.max(square / iw, square / ih) : Math.min(square / iw, square / ih);
    const dw = iw * s, dh = ih * s;
    g.drawImage(img, (square - dw) / 2, (square - dh) / 2, dw, dh);
  } else {
    const k = Math.min(1, max / Math.max(iw, ih));
    c.width = Math.round(iw * k); c.height = Math.round(ih * k);
    g.drawImage(img, 0, 0, c.width, c.height);
  }
  return c.toDataURL(type, q);
}
function nodeBlob(n, p) {
  return n.bin ? dataToBlob(n.content, n.mime || MIME_EXT[ext(p)]) : new Blob([n.content], { type: ext(p) === 'svg' ? 'image/svg+xml' : 'text/plain' });
}
async function setWallpaperBlob(blob, target = wallDefaultTarget()) {
  try {
    const img = await shrinkToDataURL(blob, { max: 2560, type: 'image/jpeg', q: 0.9 });
    setWallFor(target, { wall: 'custom', wallImg: img });
    toast(settings.wallPerDesk && target !== 'all' ? `Fundal schimbat pentru ${deskName(target)}` : 'Fundal schimbat');
  } catch { alert('Imaginea nu a putut fi citită.'); }
}
async function setWallpaperFromPath(p, target) { const n = node(p); if (n) await setWallpaperBlob(nodeBlob(n, p), target); }
function changeIcon(k, done) {
  pickFiles('image/*', async f => {
    try { settings.icons[k] = await shrinkToDataURL(f[0], { square: 96, type: 'image/png' }); saveSettings(); refreshShell(); if (done) done(); }
    catch { alert('Imaginea nu a putut fi citită.'); }
  });
}
const avatarEl = () => settings.avatar ? el('img', { src: settings.avatar, alt: '' }) : document.createTextNode('👤');

/* ---------- ecran de blocare, calendar ---------- */
/* ---------- parolă, sesiune, ecran de login ---------- */
const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
const randHex = n => hex(crypto.getRandomValues(new Uint8Array(n)));
async function hashPw(pw, saltHex) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
  const salt = new Uint8Array(saltHex.match(/../g).map(h => parseInt(h, 16)));
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, key, 256));
}
const sessStore = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.session ? chrome.storage.session : null;
const sess = {
  async get(k) { try { if (sessStore) return (await sessStore.get(k))[k]; } catch {} return sessionStorage.getItem('helium_' + k) === '1'; },
  async set(k, v) { try { if (sessStore) { await sessStore.set({ [k]: v }); return; } } catch {} sessionStorage.setItem('helium_' + k, v ? '1' : '0'); }
};
const sessSet = (k, v) => sess.set(k, v);

function lock(opts = {}) {
  vaultLock();
  if ($('#lock')) return;
  const hasPw = !!settings.pw;
  const blocked = ['#desktop', '#taskbar', '#menu'].map(s => $(s));
  blocked.forEach(e => { e.inert = true; });
  const box = el('div', { class: 'lk-box' });
  const l = el('div', { id: 'lock', tabindex: '0', role: 'dialog', 'aria-label': 'Ecran blocat' }, box);
  l.style.background = wallCSS();
  const msg = el('div', { class: 'lk-msg', role: 'alert' });
  let focusEl = l, fails = 0;

  function finish(welcome) {
    sessSet('unlocked', true);
    if (welcome) { box.textContent = ''; box.append(el('div', { class: 'lk-welcome', text: 'Bun venit' }), el('div', { class: 'spin' })); }
    setTimeout(() => { blocked.forEach(e => { e.inert = false; }); l.classList.add('out'); setTimeout(() => l.remove(), 320); }, welcome ? 900 : 0);
  }
  async function forgot() {
    if (!confirm('Parola nu poate fi recuperată. Singura cale este resetarea: se șterg TOATE fișierele și setările. Continui?')) return;
    if (!confirm('Ești sigur? Acțiunea nu se poate anula.')) return;
    root = seed(); await dbSet('fs', root); await dbSet('settings', { ...DEFAULTS, icons: {} }); await sessSet('unlocked', false); location.reload();
  }
  box.append(el('div', { class: 'lk-av' }, avatarEl()), el('div', { class: 'lk-name', text: settings.userName }));
  if (!hasPw) {
    box.append(el('div', { class: 'lk-hint', text: 'Apasă pe pictogramă ca să te conectezi' }));
    box.firstChild.addEventListener('click', () => finish(false));
    l.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') finish(false); });
  } else {
    const inp = el('input', { type: 'password', class: 'lk-pw', placeholder: 'Parola', autocomplete: 'off', 'aria-label': 'Parola' });
    const go = el('button', { class: 'lk-go', title: 'Conectează-te', 'aria-label': 'Conectează-te', text: '→' });
    const submit = async () => {
      if (inp.disabled || !inp.value) return;
      const ok = (await hashPw(inp.value, settings.pw.salt)) === settings.pw.hash;
      if (ok) return finish(true);
      fails++; msg.textContent = 'Parola este incorectă.'; inp.value = '';
      box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake');
      if (fails >= 3) { inp.disabled = go.disabled = true; msg.textContent = 'Prea multe încercări. Așteaptă 5 secunde.'; setTimeout(() => { inp.disabled = go.disabled = false; msg.textContent = ''; inp.focus(); }, 5000); }
      else inp.focus();
    };
    go.addEventListener('click', submit);
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
    box.append(el('div', { class: 'lk-row' }, inp, go), msg);
    if (settings.pwHint) box.append(el('button', { class: 'lk-link', text: 'Indiciu parolă', onclick: () => { msg.textContent = 'Indiciu: ' + settings.pwHint; } }));
    box.append(el('button', { class: 'lk-link', text: 'Ai uitat parola?', onclick: forgot }));
    focusEl = inp;
  }
  document.body.append(l); focusEl.focus();
}

/* ---------- animația de pornire ---------- */
function makeBoot() {
  return el('div', { id: 'boot', role: 'status', 'aria-label': 'Se pornește HeliumOS' },
    el('div', { class: 'bt-logo' }, el('i'), el('i'), el('i'), el('i')),
    el('div', { class: 'bt-name', text: 'HeliumOS' }),
    el('div', { class: 'bt-bar' }, el('span')));
}
function bootAnimation() {
  const b = $('#boot'); if (!b) return Promise.resolve();
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  return new Promise(res => {
    let finished = false;
    const done = () => { if (finished) return; finished = true; b.classList.add('out'); setTimeout(() => b.remove(), 520); res(); };
    const t = setTimeout(done, reduce ? 500 : 2700);
    setTimeout(() => window.addEventListener('pointerdown', () => { clearTimeout(t); done(); }, { once: true }), 700);
  });
}
function hideBoot() { const b = $('#boot'); if (b) { b.classList.add('out'); setTimeout(() => b.remove(), 520); } }
function previewBoot() { if ($('#boot')) return; document.body.append(makeBoot()); bootAnimation(); }

function toggleCal() {
  const old = $('#cal'); if (old) { old.remove(); return; }
  const nc = $('#ncenter'); if (nc) nc.remove();
  const now = new Date(); let y = now.getFullYear(), m = now.getMonth();
  const box = el('div', { id: 'cal' });
  const draw = () => {
    box.textContent = '';
    const g = el('div', { class: 'cal-g' });
    ['L', 'Ma', 'Mi', 'J', 'V', 'S', 'D'].forEach(x => g.append(el('span', { class: 'cal-w', text: x })));
    const first = (new Date(y, m, 1).getDay() + 6) % 7, days = new Date(y, m + 1, 0).getDate();
    for (let i = 0; i < first; i++) g.append(el('span'));
    for (let i = 1; i <= days; i++) g.append(el('span', { class: 'cal-d' + (i === now.getDate() && m === now.getMonth() && y === now.getFullYear() ? ' today' : ''), text: String(i) }));
    box.append(
      el('div', { class: 'cal-clock', text: now.toLocaleTimeString('ro-RO', { hour: '2-digit', minute: '2-digit' }) }),
      el('div', { class: 'cal-h' },
        el('button', { class: 'cal-b', text: '‹', onclick: () => { m--; if (m < 0) { m = 11; y--; } draw(); } }),
        el('b', { text: new Date(y, m, 1).toLocaleDateString('ro-RO', { month: 'long', year: 'numeric' }) }),
        el('button', { class: 'cal-b', text: '›', onclick: () => { m++; if (m > 11) { m = 0; y++; } draw(); } })), g);
  };
  draw(); document.body.append(box);
}

/* ---------- Setări ---------- */
const WALLS = [
  { name: 'Aero cer', css: 'radial-gradient(ellipse 70% 50% at 20% 100%,rgba(255,255,255,.55),transparent 70%),radial-gradient(ellipse 60% 45% at 85% 0%,rgba(150,230,255,.7),transparent 70%),linear-gradient(160deg,#06306b,#1b6fc4 50%,#6fc0f2)' },
  { name: 'Aero smarald', css: 'radial-gradient(ellipse 70% 50% at 20% 100%,rgba(255,255,255,.5),transparent 70%),radial-gradient(ellipse 60% 45% at 85% 0%,rgba(170,255,220,.6),transparent 70%),linear-gradient(160deg,#04403a,#14937c 50%,#7fe0b9)' },
  { name: 'Amurg', css: 'linear-gradient(160deg,#1d2a5b,#5a3f9e 55%,#e0785f)' },
  { name: 'Prună', css: 'linear-gradient(160deg,#3b1f4a,#a14a76)' },
  { name: 'Ardezie', css: 'linear-gradient(160deg,#252b3b,#3f4a63)' }
];
const FIT = { cover: 'center/cover no-repeat', contain: 'center/contain no-repeat', stretch: 'center/100% 100% no-repeat', tile: '0 0/auto repeat', center: 'center/auto no-repeat' };
const ACCENTS = ['#3f8fdc', '#2aa7a0', '#58a85a', '#e0a030', '#d9573c', '#c2559a', '#7a5ad8', '#6d7a8c'];
const DEFAULTS = {
  wall: 0, wallImg: null, wallFit: 'cover', accent: '#3f8fdc', theme: 'aero', glass: true,
  icons: {}, pinned: ['files', 'browser', 'music'],
  desk: ['trash', 'computer', 'files', 'browser', 'music', 'images', 'paint', 'solitaire', 'vault', 'code', 'terminal', 'settings'],
  userName: 'Utilizator', avatar: null,
  notifBalloons: true, dnd: false, notifSound: false, notifTimeout: 5, notifSystem: false, reminders: [], lastBackup: 0, createdAt: 0,
  pw: null, pwHint: '', pwMode: 'session', bootAnim: 'session', seenTrash: true,
  iconPos: {}, seenPaint: true,
  vdesks: ['Desktop 1'], solStats: { played: 0, won: 0, best: 0 }, seenSol: true, userApps: [], seenApps: true, mounts: [], vault: { autoLock: 5, clip: true }, seenVault: true,
  vdWalls: [null], wallPerDesk: false, runHistory: [], gsRecent: []
};
const wallSpec = i => (settings.wallPerDesk && settings.vdWalls && settings.vdWalls[i]) || settings;
function wallCSS(i = vd.cur) {
  const sp = wallSpec(i);
  if (sp.wall === 'custom' && sp.wallImg) return `url("${sp.wallImg}") ${FIT[sp.wallFit] || FIT.cover}, #101a2e`;
  return (WALLS[sp.wall] || WALLS[0]).css;
}
// aplică fundalul desktopului curent; la schimbarea desktopului face o tranziție lină
function applyWall(animate) {
  const css = wallCSS(), old = applySettings.last;
  if (css === old) return;
  desktop.style.background = css; applySettings.last = css;
  if (animate && old && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const f = el('div', { class: 'wallfade' }); f.style.background = old; desktop.append(f);
    void f.offsetWidth; f.style.opacity = '0'; setTimeout(() => f.remove(), 450);
  }
}
const wallDefaultTarget = () => settings.wallPerDesk ? vd.cur : 'all';
function setWallFor(target, patch) {
  if (target === 'all' || !settings.wallPerDesk) Object.assign(settings, patch);
  else settings.vdWalls[target] = { ...(settings.vdWalls[target] || { wall: settings.wall, wallImg: settings.wallImg, wallFit: settings.wallFit }), ...patch };
  saveSettings();
}
function applySettings() {
  const r = document.documentElement;
  r.dataset.theme = settings.theme; r.dataset.glass = settings.glass ? 'on' : 'off';
  r.style.setProperty('--accent', settings.accent);
  applyWall(false);
}
const saveSettings = () => { applySettings(); dbSet('settings', settings).catch(() => {}); };

function settingsApp(tab = 'personal', deskTarget) {
  const w = openWindow({ title: 'Setări', app: 'settings', w: 600, h: 560 });
  if (typeof deskTarget === 'number' && !settings.wallPerDesk) { settings.wallPerDesk = true; saveSettings(); }
  let urls = [], wtarget = typeof deskTarget === 'number' ? deskTarget : wallDefaultTarget();
  const spec = () => wtarget === 'all' ? settings : (settings.vdWalls[wtarget] || settings);
  const area = el('div', { class: 'sett' });
  const tabsEl = el('div', { class: 'tabs', role: 'tablist' });
  const revoke = () => { urls.forEach(u => URL.revokeObjectURL(u)); urls = []; };
  w.onClose = revoke;
  const sec = (label, ...kids) => el('div', {}, el('p', { class: 'lbl', text: label }), ...kids);
  const chk = (label, checked, fn) => { const i = el('input', { type: 'checkbox', onchange: e => fn(e.target.checked) }); i.checked = checked; return el('label', {}, i, el('span', { text: label })); };

  function paneP() {
    const themeBtns = {};
    const mark = () => Object.entries(themeBtns).forEach(([k, b]) => b.classList.toggle('primary', k === settings.theme));
    for (const [k, l] of [['aero', 'Aero (Windows 7)'], ['flat', 'Plat']]) themeBtns[k] = btn(l, '', () => { settings.theme = k; saveSettings(); mark(); });
    mark();
    const colorIn = el('input', { type: 'color', value: settings.accent, 'aria-label': 'Culoare personalizată', oninput: e => { settings.accent = e.target.value; saveSettings(); } });
    const dots = el('div', { class: 'swatches' }, ACCENTS.map(c => el('button', { class: 'dot', title: c, 'aria-label': c, style: `background:${c}`, onclick: () => { settings.accent = c; colorIn.value = c; saveSettings(); } })), colorIn);

    const sw = el('div', { class: 'swatches' });
    const fit = el('select', { class: 'path', 'aria-label': 'Potrivire fundal', onchange: e => { setWallFor(wtarget, { wallFit: e.target.value }); } },
      [['cover', 'Umple'], ['contain', 'Potrivește'], ['stretch', 'Întinde'], ['tile', 'Mozaic'], ['center', 'Centrat']].map(([v, l]) => el('option', { value: v, text: l })));
    const drawSw = () => {
      sw.textContent = ''; const sp = spec(); fit.value = sp.wallFit || 'cover';
      if (sp.wallImg) sw.append(el('button', { class: 'sw' + (sp.wall === 'custom' ? ' sel' : ''), title: 'Imaginea mea', style: `background:url("${sp.wallImg}") center/cover`, onclick: () => { setWallFor(wtarget, { wall: 'custom' }); drawSw(); } }));
      WALLS.forEach((x, i) => sw.append(el('button', { class: 'sw' + (sp.wall === i ? ' sel' : ''), title: x.name, 'aria-label': x.name, style: `background:${x.css}`, onclick: () => { setWallFor(wtarget, { wall: i }); drawSw(); } })));
    };
    drawSw();
    const pics = fs.ls('/Pictures').filter(([nm, x]) => x.type === 'file' && kindOf(x, norm(nm, '/Pictures')) === 'image').slice(0, 12);
    const thumbs = el('div', { class: 'swatches' });
    for (const [nm, x] of pics) {
      const p = norm(nm, '/Pictures'), u = fileURL(x, p); urls.push(u);
      thumbs.append(el('button', { class: 'sw', title: nm, style: `background:url("${u}") center/cover`, onclick: async () => { await setWallpaperFromPath(p, wtarget); drawSw(); } }));
    }
    const perDesk = chk('Fundal diferit pe fiecare desktop virtual', !!settings.wallPerDesk, v => { settings.wallPerDesk = v; wtarget = v ? vd.cur : 'all'; saveSettings(); applyWall(true); show('personal'); });
    let deskRow = null;
    if (settings.wallPerDesk) {
      const tsel = el('select', { class: 'path', 'aria-label': 'Desktop', onchange: e => { wtarget = +e.target.value; drawSw(); } }, settings.vdesks.map((n, i) => el('option', { value: String(i), text: n })));
      tsel.value = String(wtarget);
      deskRow = el('div', { class: 'row2', style: 'margin:8px 0' }, el('span', { text: 'Se schimbă pentru:' }), tsel,
        btn('Folosește fundalul comun', 'Elimină fundalul propriu al acestui desktop', () => { settings.vdWalls[wtarget] = null; saveSettings(); applyWall(true); drawSw(); }));
    }
    const nameIn = el('input', { class: 'path', value: settings.userName, 'aria-label': 'Nume utilizator', oninput: e => { settings.userName = e.target.value || 'Utilizator'; saveSettings(); renderMenu(); } });

    area.append(
      sec('Temă', el('div', { class: 'row2' }, themeBtns.aero, themeBtns.flat), chk('Transparență (sticlă Aero)', settings.glass, v => { settings.glass = v; saveSettings(); })),
      sec('Culoare ferestre', dots),
      sec('Fundal desktop', perDesk, ...(deskRow ? [deskRow] : []), sw,
        el('div', { class: 'row2', style: 'margin-top:10px' }, btn('Alege imagine din calculator…', '', () => pickFiles('image/*', async f => { await setWallpaperBlob(f[0], wtarget); drawSw(); }), 'primary'), fit),
        ...(pics.length ? [el('p', { class: 'hint', text: 'Sau alege din /Pictures:' }), thumbs] : [el('p', { class: 'hint', text: 'Poți seta fundal și din aplicația Imagini (butonul „Fundal”) sau cu click dreapta pe o imagine în Fișiere.' })])),
      sec('Utilizator', el('div', { class: 'row2' }, nameIn, btn('Poză…', '', () => pickFiles('image/*', async f => { try { settings.avatar = await shrinkToDataURL(f[0], { square: 128, cover: true, type: 'image/jpeg' }); saveSettings(); renderMenu(); } catch { alert('Imaginea nu a putut fi citită.'); } })), btn('↺', 'Fără poză', () => { settings.avatar = null; saveSettings(); renderMenu(); }))));
  }
  function paneI() {
    area.append(el('p', { class: 'hint', style: 'margin:0', text: 'Alege o imagine (PNG, JPG, SVG, ICO) sau un emoji pentru fiecare aplicație. Merge și din click dreapta pe pictogramă.' }));
    for (const [k, a] of Object.entries(apps)) {
      if (a.hidden) continue;
      area.append(el('div', { class: 'irow' },
        el('span', { class: 'ig' }, iconEl(iconOf(k))), el('span', { class: 'in', text: a.name }),
        btn('Imagine…', '', () => changeIcon(k, () => show('icons'))),
        btn('Emoji…', '', () => { const v = prompt('Scrie un emoji sau un caracter:', ''); if (v && v.trim()) { settings.icons[k] = [...new Intl.Segmenter().segment(v.trim())][0].segment; saveSettings(); refreshShell(); show('icons'); } }),
        btn('↺', 'Pictograma implicită', () => { delete settings.icons[k]; saveSettings(); refreshShell(); show('icons'); }),
        chk('Desktop', settings.desk.includes(k), v => { settings.desk = v ? [...settings.desk, k] : settings.desk.filter(x => x !== k); saveSettings(); renderDesktop(); }),
        chk('Bară', settings.pinned.includes(k), v => { settings.pinned = v ? [...settings.pinned, k] : settings.pinned.filter(x => x !== k); saveSettings(); renderTasks(); })));
    }
  }
  function paneS() {
    area.append(
      sec('Copie de siguranță', el('div', { class: 'row2' },
        btn('Exportă (.json)', '', async () => {
          settings.lastBackup = Date.now(); saveSettings();
          const vaultBlob = await dbGet('vault').catch(() => null);
          const url = URL.createObjectURL(new Blob([JSON.stringify({ v: 1, fs: fsForSave(), settings: { ...settings, mounts: [] }, vault: vaultBlob || null })], { type: 'application/json' }));
          const a = el('a', { href: url, download: 'heliumos-backup.json' }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
        }),
        btn('Restaurează…', '', () => pickFiles('.json,application/json', async f => {
          try {
            const d = JSON.parse(await f[0].text()); if (!d.fs || d.fs.type !== 'dir') throw 0;
            if (!confirm('Înlocuiești tot (fișiere și setări) cu această copie?')) return;
            root = d.fs; await dbSet('fs', root); if (d.settings) await dbSet('settings', d.settings); if (d.vault) await dbSet('vault', d.vault); location.reload();
          } catch { alert('Fișier de copie invalid.'); }
        }))),
        el('p', { class: 'hint', text: 'Fișierele stau în browser (IndexedDB). Dacă ștergi datele browserului, dispar, deci exportă din când în când o copie.' })),
      sec('Discuri montate (foldere reale)',
        ...(settings.mounts.length ? settings.mounts.map(r => el('div', { class: 'irow' },
          el('span', { class: 'ig' }, el('span', { class: 'ico', text: mountOnline(r) ? '💾' : '🔌' })),
          el('div', { class: 'in' }, el('div', { text: r.name }), el('span', { class: 'hint', text: `${mountPath(r)} · ${r.mode === 'read' ? 'doar citire' : 'citire și scriere'} · ${mountOnline(r) ? 'conectat' : 'deconectat'}` })),
          mountOnline(r) ? btn('Reîncarcă', '', async () => { await reconnectMount(r.id); show('system'); }) : btn('Reconectează', '', async () => { await reconnectMount(r.id); show('system'); }),
          ...(mountOnline(r) ? [btn('Deconectează', '', () => { disconnectMount(r.id); show('system'); })] : []),
          btn('Elimină', '', async () => { if (confirm(`Elimini „${r.name}” din listă? Fișierele de pe disc nu se șterg.`)) { await removeMount(r.id); show('system'); } }))) : [el('p', { class: 'hint', style: 'margin:0 0 8px', text: 'Niciun disc montat.' })]),
        btn('Montează un folder…', '', mountDialog, 'primary'),
        el('p', { class: 'hint', text: 'Fișierele reale apar în Fișiere sub /Mount. Salvările se scriu pe disc, iar ștergerile sunt definitive.' })),
      sec('Resetare', btn('Resetează sistemul de fișiere și setările', '', async () => {
        if (!confirm('Ștergi toate fișierele și revii la starea inițială? Seiful criptat și folderele reale montate nu sunt șterse.')) return;
        root = seed(); await dbSet('fs', root); await dbSet('settings', { ...DEFAULTS, icons: {} }); location.reload();
      })));
  }
  function paneC() {
    const has = !!settings.pw;
    const pwf = ph => el('input', { type: 'password', class: 'path', placeholder: ph, autocomplete: 'off', 'aria-label': ph });
    const cur = pwf('Parola curentă'), np = pwf(has ? 'Parola nouă' : 'Parola'), np2 = pwf('Repetă parola');
    const hint = el('input', { class: 'path', placeholder: 'Indiciu (opțional, se vede pe ecranul de login)', value: settings.pwHint || '', 'aria-label': 'Indiciu' });
    const msg = el('p', { class: 'hint', role: 'status' });
    const say = t => { msg.textContent = t; };
    const check = async () => !has || (await hashPw(cur.value, settings.pw.salt)) === settings.pw.hash;
    const saveBtn = btn(has ? 'Schimbă parola' : 'Setează parola', '', async () => {
      if (!(await check())) return say('Parola curentă nu este corectă.');
      if (np.value.length < 4) return say('Parola trebuie să aibă cel puțin 4 caractere.');
      if (np.value !== np2.value) return say('Parolele nu coincid.');
      const salt = randHex(16);
      settings.pw = { salt, hash: await hashPw(np.value, salt) }; settings.pwHint = hint.value.trim();
      saveSettings(); await sessSet('unlocked', true); notify({ title: 'Parolă setată', body: 'Ecranul de login va cere parola.', icon: '🔒' }); show('account');
    }, 'primary');
    const rmBtn = has ? btn('Elimină parola', '', async () => {
      if (!(await check())) return say('Parola curentă nu este corectă.');
      settings.pw = null; settings.pwHint = ''; saveSettings(); notify({ title: 'Parola a fost eliminată', icon: '🔓' }); show('account');
    }) : null;
    const pick = (opts, val, fn) => { const sl = el('select', { class: 'path', onchange: e => fn(e.target.value) }, opts.map(([v, l]) => el('option', { value: v, text: l }))); sl.value = val; return sl; };
    area.append(
      sec('Parolă de utilizator', ...(has ? [cur] : []), np, np2, hint, el('div', { class: 'row2' }, saveBtn, ...(rmBtn ? [rmBtn] : [])), msg,
        el('p', { class: 'hint', text: 'Parola oprește accesul obișnuit la desktop, dar nu criptează fișierele. Dacă o uiți, singura cale este resetarea (se șterg toate datele).' })),
      sec('Când se cere parola', pick([['session', 'O dată pe sesiune de browser'], ['always', 'La fiecare tab nou']], settings.pwMode, v => { settings.pwMode = v; saveSettings(); })),
      sec('Animația de pornire', pick([['session', 'O dată pe sesiune de browser'], ['always', 'La fiecare tab nou'], ['off', 'Dezactivată']], settings.bootAnim, v => { settings.bootAnim = v; saveSettings(); }),
        el('div', { class: 'row2' }, btn('Previzualizează', '', previewBoot))));
  }
  function paneN() {
    const dur = el('select', { class: 'path', 'aria-label': 'Durată balon', onchange: e => { settings.notifTimeout = +e.target.value; saveSettings(); } },
      [3, 5, 8, 15].map(v => el('option', { value: String(v), text: v + ' secunde' })));
    dur.value = String(settings.notifTimeout || 5);
    area.append(
      sec('Afișare', chk('Baloane pe desktop', settings.notifBalloons !== false, v => { settings.notifBalloons = v; saveSettings(); }),
        chk('Nu deranja (fără baloane și sunete)', !!settings.dnd, v => { settings.dnd = v; saveSettings(); updateBadge(); }),
        chk('Sunet la notificări', !!settings.notifSound, v => { settings.notifSound = v; saveSettings(); })),
      sec('Cât rămâne un balon pe ecran', dur),
      sec('Notificări de sistem', chk('Arată și ca notificări ale sistemului, când tab-ul nu e în față', !!settings.notifSystem, async v => {
        if (!v) { settings.notifSystem = false; saveSettings(); return; }
        try {
          const ok = await chrome.permissions.request({ permissions: ['notifications'] });
          if (!ok) throw 0;
          settings.notifSystem = true; saveSettings();
          notify({ title: 'Notificări de sistem active', body: 'Le vei vedea și când ești în alt tab sau fereastră.', icon: '🔔' });
        } catch { settings.notifSystem = false; saveSettings(); alert('Browserul nu a permis notificările de sistem.'); show('notif'); }
      }), el('p', { class: 'hint', text: 'Necesită permisiunea „notificări”. Funcționează doar dacă browserul tău suportă notificări de sistem.' })),
      sec('Test', btn('Trimite o notificare de test', '', () => notify({ title: 'Notificare de test', body: 'Așa arată o notificare în HeliumOS.', icon: '🔔', click: { type: 'settings', tab: 'notif' }, btn: { label: 'Deschide Setări', type: 'settings', tab: 'notif' } }), 'primary')),
      sec('Mementouri', el('p', { class: 'hint', style: 'margin:0', text: 'Setează-le din panoul 🔔 (dreapta jos) sau în Terminal: remind 10m scoate pâinea. Sună cât timp HeliumOS e deschis într-un tab; cele ratate apar la următoarea deschidere.' })));
  }
  function paneA() {
    area.append(
      el('p', { class: 'hint', style: 'margin:0', text: 'Aplicațiile tale sunt fișiere HTML care rulează izolat, într-o fereastră a sistemului. Ghid: /Documents/Aplicatii-proprii.md' }),
      el('div', { class: 'row2' },
        btn('Din calculator…', 'Importă un fișier HTML și instaleaz-o', () => pickFiles('.html,.htm,text/html', async f => { const ps = await importFiles(f, '/Documents/Aplicatii'); if (ps[0]) installDialog(ps[0]); })),
        btn('Din Fișiere…', 'Alege un fișier HTML din sistem', () => { const p = prompt('Calea fișierului HTML (ex: /Documents/aplicatie.html):', '/Documents/'); if (!p) return; const q = norm(p.trim(), '/'); const n = node(q); if (n && n.type === 'file' && !n.bin) installDialog(q); else alert('Nu am găsit un fișier text la această cale.'); }),
        btn('Aplicație nouă', 'Pornește de la un șablon', newAppFromTemplate, 'primary'),
        btn('Adaugă exemple', '', () => { seedExamples(true); show('apps'); })));
    if (!settings.userApps.length) area.append(el('p', { class: 'hint', text: 'Nicio aplicație instalată încă. Încearcă „Adaugă exemple”, apoi click dreapta pe un fișier .html → „Instalează ca aplicație…”.' }));
    for (const r of settings.userApps) {
      const k = 'u:' + r.id, perms = [r.perms.notify && 'notificări', r.perms.files && 'fișiere proprii', r.perms.net && 'internet', r.perms.fsAll && 'tot sistemul de fișiere'].filter(Boolean).join(', ') || 'fără permisiuni';
      area.append(el('div', { class: 'irow' },
        el('span', { class: 'ig' }, iconEl(iconOf(k))),
        el('div', { class: 'in' }, el('div', { text: r.name }), el('span', { class: 'hint', text: r.path + ' · ' + perms })),
        btn('Deschide', '', () => runUserApp(r.id)), btn('Editează', '', () => codeEditor(r.path)),
        btn('Proprietăți', '', () => installDialog(r.path, r)), btn('Dezinstalează', '', () => uninstallApp(r.id, () => show('apps')))));
    }
  }
  const PANES = { apps: paneA, personal: paneP, icons: paneI, account: paneC, notif: paneN, system: paneS };
  function show(name) {
    revoke(); area.textContent = '';
    tabsEl.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.dataset.t === name));
    PANES[name]();
  }
  for (const [k, l] of [['personal', 'Personalizare'], ['icons', 'Pictograme'], ['account', 'Cont'], ['apps', 'Aplicații'], ['notif', 'Notificări'], ['system', 'Sistem']])
    tabsEl.append(el('button', { class: 'tab', role: 'tab', 'data-t': k, text: l, onclick: () => show(k) }));
  w.body.append(tabsEl, area);
  show(tab);
}

/* ---------- Manager de activități ---------- */
function taskManager() {
  const w = openWindow({ title: 'Manager de activități', app: 'taskmgr', w: 600, h: 460 });
  let tab = 'apps', sel = null, sig = '', lag = 0, last = performance.now(), est = null, tick = 0;
  const hist = [], startedAt = Date.now();
  const list = el('div', { class: 'flist' });
  const status = el('span', { class: 'np-status' });
  const cur = () => (sel && allWins.has(sel)) ? sel : null;

  function refreshApps() {
    const rows = [...allWins];
    const s = rows.map(x => `${x.title}|${x.minimized()}|${x.isActive()}|${x === sel}|${x.desk}`).join('\n');
    if (s === sig) { list.querySelectorAll('.c-size').forEach((c, i) => { if (rows[i]) c.textContent = String(rows[i].win.querySelectorAll('*').length); }); return; }
    sig = s; list.textContent = '';
    if (!rows.length) list.append(el('p', { class: 'empty', text: 'Nicio fereastră deschisă.' }));
    for (const x of rows) {
      list.append(el('div', { class: 'frow' + (x === sel ? ' sel' : ''), onclick: () => { sel = x; refreshApps(); }, ondblclick: () => x.focus() },
        el('span', { class: 'c-name' }, iconEl(iconOf(x.app)), el('span', { class: 'nm', text: x.title })),
        el('span', { class: 'c-date', text: x.desk !== vd.cur ? deskName(x.desk) : x.minimized() ? 'Minimizată' : x.isActive() ? 'Activă' : 'Rulează' }),
        el('span', { class: 'c-type', text: (apps[x.app] || {}).name || x.app }),
        el('span', { class: 'c-size', text: String(x.win.querySelectorAll('*').length) })));
    }
    status.textContent = `Ferestre: ${rows.length}`;
  }
  const newTask = () => {
    const v = (prompt('Scrie numele unei aplicații (ex: terminal) sau calea unui fișier/folder:') || '').trim();
    if (!v) return;
    if (!runCommand(v)) alert(`Nu am găsit „${v}”.`);
  };
  const appsPane = el('div', { class: 'exp-main', style: 'flex:1;min-height:0' },
    el('div', { class: 'cols' }, ...['Fereastră', 'Stare', 'Aplicație', 'Elemente'].map((l, i) => el('span', { class: 'ch ' + ['c-name', 'c-date', 'c-type', 'c-size'][i], text: l }))),
    list,
    el('div', { class: 'tool', style: 'border-top:1px solid var(--line);border-bottom:0' },
      btn('Comută la', '', () => { const x = cur(); if (x) x.focus(); }),
      btn('Închide fereastra', '', () => { const x = cur(); if (x) { x.close(); sel = null; sig = ''; setTimeout(refreshApps, 200); } }),
      btn('Task nou…', '', newTask), status));

  const canvas = el('canvas', { class: 'perf' });
  const stats = el('div', { class: 'stats' });
  const perfPane = el('div', { class: 'exp-main', style: 'flex:1;min-height:0;display:none' }, canvas, stats);
  function drawPerf() {
    const W = canvas.width = canvas.clientWidth, H = canvas.height = canvas.clientHeight, c = canvas.getContext('2d');
    if (!c) return;
    c.clearRect(0, 0, W, H); c.lineWidth = 1; c.strokeStyle = 'rgba(120,200,255,.15)'; c.font = '12px system-ui,sans-serif';
    for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(0, H * i / 4); c.lineTo(W, H * i / 4); c.stroke(); }
    const X = i => (i + 60 - hist.length) / 59 * W;
    const heap = hist.map(h => h.heap).filter(v => v != null);
    if (heap.length) {
      const max = Math.max(...heap) * 1.25 || 1;
      c.strokeStyle = '#58d26b'; c.lineWidth = 2; c.beginPath();
      hist.forEach((h, i) => { const y = H - (h.heap / max) * H; if (i) c.lineTo(X(i), y); else c.moveTo(X(i), y); });
      c.stroke(); c.fillStyle = '#9fe6ad'; c.fillText(`Memorie JS: ${heap[heap.length - 1].toFixed(1)} MB`, 8, 16);
    } else { c.fillStyle = '#9fb0d8'; c.fillText('Memoria JS nu e disponibilă în acest browser.', 8, 16); }
    const lm = Math.max(50, ...hist.map(h => h.lag));
    c.strokeStyle = '#4aa8ff'; c.lineWidth = 1.5; c.beginPath();
    hist.forEach((h, i) => { const y = H - (h.lag / lm) * H * 0.4; if (i) c.lineTo(X(i), y); else c.moveTo(X(i), y); });
    c.stroke(); c.fillStyle = '#8fc9ff'; c.fillText(`Latență buclă: ${Math.round(lag)} ms`, 8, 32);
  }
  function refreshStats() {
    let files = 0, bytes = 0;
    (function walk(n) { for (const x of Object.values(n.children)) { if (x.type === 'dir') walk(x); else { files++; bytes += sizeOf(x); } } })(root);
    const s = Math.floor((Date.now() - startedAt) / 1000), mem = performance.memory;
    const rows = [
      ['Activ de', `${Math.floor(s / 60)} min ${s % 60} s`], ['Ferestre', allWins.size],
      ['Elemente DOM', document.getElementsByTagName('*').length], ['Fișiere', files],
      ['Date în fișiere', fmtSize(bytes)], ['Memorie JS', mem ? `${(mem.usedJSHeapSize / 1048576).toFixed(1)} / ${(mem.jsHeapSizeLimit / 1048576).toFixed(0)} MB` : '—'],
      ['Stocare browser', est ? `${fmtSize(est.usage)} din ${fmtSize(est.quota)}` : '…'], ['Latență buclă', `${Math.round(lag)} ms`]
    ];
    stats.textContent = '';
    for (const [k, v] of rows) stats.append(el('span', { text: k }), el('b', { text: String(v) }));
  }
  const tabsEl = el('div', { class: 'tabs' });
  function show(t) {
    tab = t;
    tabsEl.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', b.dataset.t === t));
    appsPane.style.display = t === 'apps' ? 'flex' : 'none'; perfPane.style.display = t === 'perf' ? 'flex' : 'none';
    if (t === 'apps') { sig = ''; refreshApps(); } else { drawPerf(); refreshStats(); }
  }
  for (const [k, l] of [['apps', 'Aplicații'], ['perf', 'Performanță']]) tabsEl.append(el('button', { class: 'tab', 'data-t': k, text: l, onclick: () => show(k) }));
  const timer = setInterval(() => {
    const now = performance.now(); lag = Math.max(0, now - last - 1000); last = now;
    hist.push({ heap: performance.memory ? performance.memory.usedJSHeapSize / 1048576 : null, lag }); if (hist.length > 60) hist.shift();
    if (tick++ % 5 === 0 && navigator.storage && navigator.storage.estimate) navigator.storage.estimate().then(e => { est = e; }).catch(() => {});
    if (tab === 'apps') refreshApps(); else { drawPerf(); refreshStats(); }
  }, 1000);
  w.onClose = () => clearInterval(timer);
  w.body.append(tabsEl, appsPane, perfPane);
  show('apps');
}

/* ---------- Coș de reciclare ---------- */
function recycleBin() {
  const w = openWindow({ title: 'Coș de reciclare', app: 'trash', w: 660, h: 420 });
  let sel = null;
  const list = el('div', { class: 'flist', tabindex: '0' });
  const status = el('div', { class: 'statusbar' });
  const restore = nm => { const e = fs.restore(nm); if (e) alert(e); else toast('Restaurat'); };
  const purge = nm => { if (confirm(`Ștergi definitiv „${nm}”? Nu se mai poate recupera.`)) fs.rm('/.Trash/' + nm, true); };
  function select(nm) { sel = nm; list.querySelectorAll('.frow').forEach(r => r.classList.toggle('sel', r.dataset.p === nm)); }
  function render() {
    list.textContent = '';
    const items = fs.ls('/.Trash');
    if (!items.length) list.append(el('p', { class: 'empty', text: 'Coșul de reciclare este gol.' }));
    for (const [nm, x] of items) {
      const isDir = x.type === 'dir', p = '/.Trash/' + nm;
      list.append(el('div', { class: 'frow' + (nm === sel ? ' sel' : ''), tabindex: '-1', 'data-p': nm,
        onclick: () => select(nm),
        ondblclick: () => { if (!isDir) openPath(p); },
        oncontextmenu: e => { e.preventDefault(); select(nm); ctxMenu(e.clientX, e.clientY, [{ label: 'Restaurează', icon: '↩', fn: () => restore(nm) }, ...(isDir ? [] : [{ label: 'Deschide', icon: '▸', fn: () => openPath(p) }]), '-', { label: 'Șterge definitiv', icon: '✕', fn: () => purge(nm) }]); }
      },
        el('span', { class: 'c-name' }, el('span', { text: isDir ? '📁' : FILE_ICON[kindOf(x, p)] }), el('span', { class: 'nm', text: nm })),
        el('span', { class: 'c-date', text: x.trash && x.trash.from ? norm('..', x.trash.from) : '—' }),
        el('span', { class: 'c-type', text: fmtDate(x.trash && x.trash.at) }),
        el('span', { class: 'c-size', text: isDir ? '' : fmtSize(sizeOf(x)) })));
    }
    status.textContent = `${items.length} ${items.length === 1 ? 'element' : 'elemente'}`;
  }
  list.addEventListener('keydown', e => { if (!sel) return; if (e.key === 'Delete') purge(sel); else if (e.key === 'Enter') restore(sel); });
  list.addEventListener('click', e => { if (e.target === list) { sel = null; select(null); } });
  w.body.append(
    el('div', { class: 'cmdbar' },
      btn('Restaurează', 'Mută înapoi în locul inițial', () => sel && restore(sel), 'cmd'),
      btn('Restaurează tot', '', () => fs.ls('/.Trash').forEach(([nm]) => restore(nm)), 'cmd'),
      btn('Golește coșul', '', () => { const n = fs.ls('/.Trash').length; if (n && confirm(`Ștergi definitiv ${n} ${n === 1 ? 'element' : 'elemente'}?`)) fs.ls('/.Trash').forEach(([nm]) => fs.rm('/.Trash/' + nm, true)); }, 'cmd')),
    el('div', { class: 'exp-main', style: 'flex:1;min-height:0' },
      el('div', { class: 'cols' }, ...['Nume', 'Locația inițială', 'Data ștergerii', 'Mărime'].map((l, i) => el('span', { class: 'ch ' + ['c-name', 'c-date', 'c-type', 'c-size'][i], text: l }))),
      list, status));
  const onFs = () => render();
  window.addEventListener('fs-change', onFs);
  w.onClose = () => window.removeEventListener('fs-change', onFs);
  render();
}

/* ---------- Paint ---------- */
const hexToRgb = h => { const v = parseInt(h.slice(1), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
// umplere cu găleata (flood fill pe date RGBA); modifică `d` pe loc
function floodFillData(d, W, H, sx, sy, [fr, fg, fb], tol = 40) {
  const i0 = (sy * W + sx) * 4, tr = d[i0], tg = d[i0 + 1], tb = d[i0 + 2], ta = d[i0 + 3];
  if (tr === fr && tg === fg && tb === fb && ta === 255) return false;
  const ok = i => Math.abs(d[i] - tr) + Math.abs(d[i + 1] - tg) + Math.abs(d[i + 2] - tb) + Math.abs(d[i + 3] - ta) <= tol;
  const seen = new Uint8Array(W * H), stack = [sx, sy];
  while (stack.length) {
    const y = stack.pop(); let x = stack.pop();
    while (x >= 0 && !seen[y * W + x] && ok((y * W + x) * 4)) x--;
    x++;
    let up = false, dn = false;
    for (; x < W && !seen[y * W + x] && ok((y * W + x) * 4); x++) {
      const p = y * W + x, i = p * 4;
      seen[p] = 1; d[i] = fr; d[i + 1] = fg; d[i + 2] = fb; d[i + 3] = 255;
      if (y > 0) { const o = (y - 1) * W + x, can = !seen[o] && ok(o * 4); if (can && !up) { stack.push(x, y - 1); up = true; } else if (!can) up = false; }
      if (y < H - 1) { const o = (y + 1) * W + x, can = !seen[o] && ok(o * 4); if (can && !dn) { stack.push(x, y + 1); dn = true; } else if (!can) dn = false; }
    }
  }
  return true;
}

const PAINT_COLORS = ['#000000', '#7f7f7f', '#880015', '#ed1c24', '#ff7f27', '#fff200', '#22b14c', '#00a2e8', '#3f48cc', '#a349a4',
  '#ffffff', '#c3c3c3', '#b97a57', '#ffaec9', '#ffc90e', '#efe4b0', '#b5e61d', '#99d9ea', '#7092be', '#c8bfe7'];
const PAINT_TOOLS = [['pencil', '✏️', 'Creion'], ['brush', '🖌️', 'Pensulă'], ['eraser', '🧽', 'Radieră'], ['spray', '💨', 'Spray'],
  ['line', '📏', 'Linie'], ['rect', '▭', 'Dreptunghi'], ['ellipse', '⬭', 'Elipsă'], ['fill', '🪣', 'Umplere'], ['picker', '💧', 'Pipetă'], ['text', '🅰️', 'Text']];

function paint(path) {
  const w = openWindow({ title: 'Paint', app: 'paint', w: 800, h: 580 });
  const cv = el('canvas', { class: 'pt-cv', width: 640, height: 400 });
  const g = cv.getContext('2d', { willReadFrequently: true });
  g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height);
  let tool = 'brush', c1 = '#000000', c2 = '#ffffff', size = 4, shapeMode = 0;
  let undo = [], redo = [], cur = path || null, dirty = false;
  const status = el('div', { class: 'statusbar' });
  const refresh = () => { w.setTitle((cur ? base(cur) : 'Fără titlu') + (dirty ? ' •' : '') + ' – Paint'); status.textContent = `${cv.width} × ${cv.height} px`; };
  const snapshot = () => g.getImageData(0, 0, cv.width, cv.height);
  const restore = img => { if (cv.width !== img.width || cv.height !== img.height) { cv.width = img.width; cv.height = img.height; } g.putImageData(img, 0, 0); };
  function pushUndo() { undo.push(snapshot()); if (undo.length > 25) undo.shift(); redo = []; dirty = true; refresh(); }
  function doUndo() { if (!undo.length) return; redo.push(snapshot()); restore(undo.pop()); dirty = true; refresh(); }
  function doRedo() { if (!redo.length) return; undo.push(snapshot()); restore(redo.pop()); dirty = true; refresh(); }
  function resize(nw, nh) {
    pushUndo(); const old = snapshot();
    cv.width = nw; cv.height = nh; g.fillStyle = '#fff'; g.fillRect(0, 0, nw, nh); g.putImageData(old, 0, 0); refresh();
  }
  function newImage() {
    const v = prompt('Dimensiuni (lățime x înălțime):', '640x400'); if (!v) return;
    const m = v.match(/^\s*(\d{1,4})\s*[x×*,]\s*(\d{1,4})\s*$/i);
    if (!m || +m[1] < 1 || +m[2] < 1 || +m[1] > 4000 || +m[2] > 4000) return alert('Scrie dimensiunile așa: 800x600 (maxim 4000).');
    if (dirty && !confirm('Ai modificări nesalvate. Continui?')) return;
    cv.width = +m[1]; cv.height = +m[2]; g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height);
    undo = []; redo = []; cur = null; dirty = false; refresh();
  }
  async function loadBlob(blob, p) {
    try {
      const img = await loadImg(blob);
      let nw = img.naturalWidth || 640, nh = img.naturalHeight || 400;
      const k = Math.min(1, 4000 / Math.max(nw, nh)); nw = Math.round(nw * k); nh = Math.round(nh * k);
      cv.width = nw; cv.height = nh; g.fillStyle = '#fff'; g.fillRect(0, 0, nw, nh); g.drawImage(img, 0, 0, nw, nh);
      undo = []; redo = []; cur = p || null; dirty = false; refresh();
    } catch { alert('Imaginea nu a putut fi citită.'); }
  }
  function saveTo(p) {
    const e = ext(p), type = (e === 'jpg' || e === 'jpeg') ? 'image/jpeg' : 'image/png';
    if (!['png', 'jpg', 'jpeg'].includes(e)) p = p.replace(/\.[^./]+$/, '') + '.png';
    const err = fs.put(p, { ...mkFile(cv.toDataURL(type, 0.92)), bin: true, mime: type });
    if (err) return alert(err);
    changed(); cur = p; dirty = false; refresh(); notify({ title: 'Imagine salvată', body: p, icon: 'app:paint', click: { type: 'path', path: p } });
  }
  function save() { const p = cur || prompt('Salvează ca (cale .png sau .jpg):', '/Pictures/desen.png'); if (p) saveTo(norm(p)); }
  function exportPng() {
    cv.toBlob(b => { const url = URL.createObjectURL(b), a = el('a', { href: url, download: (cur ? base(cur).replace(/\.[^.]+$/, '') : 'desen') + '.png' }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000); });
  }

  /* --- desenare --- */
  const pt = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
  function stroke(a, b, col, lw) {
    g.strokeStyle = col; g.lineWidth = lw; g.lineCap = 'round'; g.lineJoin = 'round';
    g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0] + 0.01, b[1]); g.stroke();
  }
  function shape(t, a, b, col, col2) {
    g.lineWidth = size; g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = col; g.fillStyle = shapeMode === 1 ? col : col2;
    g.beginPath();
    if (t === 'line') { g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); return; }
    if (t === 'rect') g.rect(a[0], a[1], b[0] - a[0], b[1] - a[1]);
    else g.ellipse((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, Math.abs(b[0] - a[0]) / 2, Math.abs(b[1] - a[1]) / 2, 0, 0, Math.PI * 2);
    if (shapeMode !== 0) g.fill();
    if (shapeMode !== 1) g.stroke();
  }
  const sprayAt = (p, col) => { g.fillStyle = col; const r = size * 2 + 4; for (let i = 0; i < 18; i++) { const a = Math.random() * 6.283, d = Math.random() * r; g.fillRect(p[0] + Math.cos(a) * d, p[1] + Math.sin(a) * d, 1, 1); } };

  let drawing = false, start = null, last = null, base0 = null, col = c1, sprayTimer = 0;
  cv.addEventListener('contextmenu', e => e.preventDefault());
  cv.addEventListener('pointerdown', e => {
    if (e.button !== 0 && e.button !== 2) return;
    const p = pt(e); col = e.button === 2 ? c2 : c1;
    const other = e.button === 2 ? c1 : c2;
    if (tool === 'picker') {
      const px = g.getImageData(Math.floor(p[0]), Math.floor(p[1]), 1, 1).data;
      const h = '#' + [px[0], px[1], px[2]].map(v => v.toString(16).padStart(2, '0')).join('');
      if (e.button === 2) c2 = h; else c1 = h; drawColors(); return;
    }
    if (tool === 'text') {
      const t = prompt('Text:'); if (!t) return;
      pushUndo(); g.fillStyle = col; g.font = `${Math.max(12, size * 4)}px "Segoe UI",system-ui,sans-serif`; g.textBaseline = 'top'; g.fillText(t, p[0], p[1]); return;
    }
    if (tool === 'fill') {
      const x = Math.floor(p[0]), y = Math.floor(p[1]);
      if (x < 0 || y < 0 || x >= cv.width || y >= cv.height) return;
      pushUndo(); const img = snapshot();
      if (floodFillData(img.data, cv.width, cv.height, x, y, hexToRgb(col))) g.putImageData(img, 0, 0);
      return;
    }
    pushUndo(); drawing = true; start = last = p; cv.setPointerCapture(e.pointerId);
    if (tool === 'line' || tool === 'rect' || tool === 'ellipse') { base0 = snapshot(); g.__other = other; }
    else if (tool === 'spray') { sprayAt(p, col); sprayTimer = setInterval(() => last && sprayAt(last, col), 30); }
    else stroke(p, p, tool === 'eraser' ? '#ffffff' : col, tool === 'pencil' ? 1 : tool === 'eraser' ? size * 2 + 2 : size);
  });
  cv.addEventListener('pointermove', e => {
    const p = pt(e); status.textContent = `${Math.round(p[0])}, ${Math.round(p[1])} px   |   ${cv.width} × ${cv.height} px`;
    if (!drawing) return;
    if (tool === 'line' || tool === 'rect' || tool === 'ellipse') { g.putImageData(base0, 0, 0); shape(tool, start, p, col, g.__other); }
    else if (tool === 'spray') { last = p; }
    else { stroke(last, p, tool === 'eraser' ? '#ffffff' : col, tool === 'pencil' ? 1 : tool === 'eraser' ? size * 2 + 2 : size); last = p; }
  });
  const endDraw = () => { drawing = false; clearInterval(sprayTimer); base0 = null; last = null; };
  cv.addEventListener('pointerup', endDraw); cv.addEventListener('pointercancel', endDraw);

  /* --- interfață --- */
  const toolBtns = {};
  const markTool = () => Object.entries(toolBtns).forEach(([k, b]) => b.classList.toggle('on', k === tool));
  for (const [k, ic, lbl] of PAINT_TOOLS) { toolBtns[k] = el('button', { class: 'btn pt-tool', title: lbl, 'aria-label': lbl, text: ic, onclick: () => { tool = k; markTool(); } }); }
  const sizeSel = el('select', { class: 'path', title: 'Grosime', 'aria-label': 'Grosime', style: 'flex:none;width:70px', onchange: e => { size = +e.target.value; } },
    [1, 2, 3, 4, 6, 8, 12, 16, 24, 32].map(v => el('option', { value: String(v), text: v + ' px' })));
  sizeSel.value = '4';
  const modeSel = el('select', { class: 'path', title: 'Formă', 'aria-label': 'Mod formă', style: 'flex:none;width:130px', onchange: e => { shapeMode = +e.target.value; } },
    [['0', 'Doar contur'], ['1', 'Umplut'], ['2', 'Contur + umplere']].map(([v, l]) => el('option', { value: v, text: l })));
  const sw1 = el('button', { class: 'pt-cur', title: 'Culoare principală', 'aria-label': 'Culoare principală' });
  const sw2 = el('button', { class: 'pt-cur sec', title: 'Culoare secundară', 'aria-label': 'Culoare secundară' });
  const drawColors = () => { sw1.style.background = c1; sw2.style.background = c2; };
  const custom = el('input', { type: 'color', value: '#000000', title: 'Culoare personalizată (principală)', 'aria-label': 'Culoare personalizată', oninput: e => { c1 = e.target.value; drawColors(); } });
  const pal = el('div', { class: 'pt-pal' }, PAINT_COLORS.map(h => {
    const b = el('button', { class: 'pt-sw', title: h, 'aria-label': h, style: `background:${h}` });
    b.addEventListener('click', () => { c1 = h; custom.value = h; drawColors(); });
    b.addEventListener('contextmenu', e => { e.preventDefault(); c2 = h; drawColors(); });
    return b;
  }));
  const openFile = () => pickFiles('image/*', f => loadBlob(f[0], null));
  w.body.append(
    el('div', { class: 'tool' }, btn('Nou', '', newImage), btn('Deschide…', '', openFile), btn('Salvează', 'Ctrl+S', save, 'primary'), btn('Exportă', 'Descarcă PNG', exportPng),
      btn('Fundal', 'Setează ca fundal desktop', () => cv.toBlob(b => setWallpaperBlob(b))),
      el('span', { class: 'spacer' }), btn('↶', 'Anulează (Ctrl+Z)', doUndo), btn('↷', 'Refă (Ctrl+Y)', doRedo),
      btn('Redimensionează', '', () => { const v = prompt('Dimensiuni noi (lățime x înălțime):', `${cv.width}x${cv.height}`); const m = v && v.match(/^\s*(\d{1,4})\s*[x×*,]\s*(\d{1,4})\s*$/i); if (m && +m[1] > 0 && +m[2] > 0 && +m[1] <= 4000 && +m[2] <= 4000) resize(+m[1], +m[2]); }),
      btn('Golește', '', () => { pushUndo(); g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height); })),
    el('div', { class: 'tool pt-row' }, ...PAINT_TOOLS.map(([k]) => toolBtns[k]), sizeSel, modeSel,
      el('span', { class: 'spacer' }), el('div', { class: 'pt-cur-wrap' }, sw2, sw1), pal, custom),
    el('div', { class: 'pt-area' }, cv), status);
  w.body.tabIndex = 0;
  w.body.addEventListener('keydown', e => {
    if (!(e.ctrlKey || e.metaKey)) return;
    const k = e.key.toLowerCase();
    if (k === 'z') { e.preventDefault(); doUndo(); } else if (k === 'y') { e.preventDefault(); doRedo(); } else if (k === 's') { e.preventDefault(); save(); }
  });
  w.onClose = () => { clearInterval(sprayTimer); return dirty ? confirm('Ai modificări nesalvate. Închizi oricum?') : true; };
  markTool(); drawColors(); refresh();
  if (path) { const n = node(path); if (n && n.type === 'file') loadBlob(nodeBlob(n, path), path); }
}

/* ---------- notificări ---------- */
let notifs = [], toastBox = null;
const persistNotifs = debounce(() => dbSet('notifs', notifs).catch(() => {}), 300);
const unreadCount = () => notifs.filter(n => !n.read).length;
const nIcon = n => (n.icon && n.icon.startsWith('app:')) ? iconOf(n.icon.slice(4)) : (n.icon || '🔔');

function ago(t) {
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return 'acum';
  if (s < 3600) return Math.floor(s / 60) + ' min';
  if (s < 86400) return Math.floor(s / 3600) + ' h';
  return new Date(t).toLocaleDateString('ro-RO');
}
function parseDelay(s) {
  const m = String(s).trim().toLowerCase().match(/^(\d+(?:[.,]\d+)?)\s*(s|sec|m|min|h|ora|ore|d|z|zi|zile)?$/);
  if (!m) return 0;
  const k = { s: 1, sec: 1, m: 60, min: 60, h: 3600, ora: 3600, ore: 3600, d: 86400, z: 86400, zi: 86400, zile: 86400 }[m[2] || 'm'];
  return Math.min(30 * 86400, Math.round(parseFloat(m[1].replace(',', '.')) * k));
}
function fmtDur(s) {
  if (s < 60) return s + ' s';
  if (s < 3600) return Math.round(s / 60) + ' min';
  if (s < 86400) return String(+(s / 3600).toFixed(1)).replace('.', ',') + ' h';
  return Math.round(s / 86400) + ' zile';
}
function sysIcon() {
  if (sysIcon.url) return sysIcon.url;
  const c = document.createElement('canvas'); c.width = c.height = 96;
  const g = c.getContext('2d'), gr = g.createRadialGradient(48, 22, 4, 48, 48, 52);
  gr.addColorStop(0, '#cdf3ff'); gr.addColorStop(0.4, '#4aa6ea'); gr.addColorStop(1, '#0a3d82');
  g.fillStyle = gr; g.beginPath(); g.arc(48, 48, 46, 0, Math.PI * 2); g.fill();
  g.fillStyle = '#fff'; g.font = '46px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('❖', 48, 50);
  return (sysIcon.url = c.toDataURL('image/png'));
}
function chime() {
  try {
    const a = new AudioContext();
    [660, 880].forEach((f, i) => {
      const o = a.createOscillator(), v = a.createGain(), t = a.currentTime + i * 0.14;
      o.type = 'sine'; o.frequency.value = f;
      v.gain.setValueAtTime(0.0001, t); v.gain.exponentialRampToValueAtTime(0.15, t + 0.02); v.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
      o.connect(v); v.connect(a.destination); o.start(t); o.stop(t + 0.32);
    });
    setTimeout(() => a.close(), 900);
  } catch {}
}
function sysNotify(n) {
  try {
    if (typeof chrome === 'undefined' || !chrome.notifications) return;
    chrome.notifications.create('hel-' + n.id, { type: 'basic', iconUrl: sysIcon(), title: n.title || 'HeliumOS', message: n.body || ' ' });
  } catch {}
}
function runAction(a) {
  if (!a) return;
  if (a.type === 'app' && apps[a.app]) apps[a.app].open();
  else if (a.type === 'path' && node(a.path)) openPath(a.path);
  else if (a.type === 'settings') settingsApp(a.tab || 'personal');
  else if (a.type === 'uninstall') uninstallApp(a.id);
  else if (a.type === 'seedapps') { seedExamples(true); settingsApp('apps'); }
  else if (a.type === 'trashlink') { const e = fs.trash(a.path); if (e) alert(e); }
  else if (a.type === 'undofile') undoFileOp();
  else if (a.type === 'restore') { const e = fs.restore(a.name); if (e) alert(e); else toast('Restaurat'); }
}
function updateBadge() {
  const b = $('#nbadge'), btnEl = $('#notif-btn'); if (!b || !btnEl) return;
  const n = unreadCount();
  b.textContent = n > 9 ? '9+' : String(n); b.hidden = !n;
  btnEl.classList.toggle('dnd', !!settings.dnd);
  btnEl.title = settings.dnd ? 'Notificări (Nu deranja)' : 'Notificări';
}
function markRead(id) { const n = notifs.find(x => x.id === id); if (n && !n.read) { n.read = true; persistNotifs(); updateBadge(); } }

function showBalloon(n, ms, compact) {
  if (!toastBox || !toastBox.isConnected) { toastBox = el('div', { id: 'toasts', 'aria-live': 'polite' }); document.body.append(toastBox); }
  let timer;
  const b = el('div', { class: 'balloon' + (compact ? ' compact' : ''), role: 'status' });
  const close = () => { clearTimeout(timer); b.classList.add('out'); setTimeout(() => b.remove(), 200); };
  const text = el('div', { class: 'bl-tx' });
  if (n.title) text.append(el('b', { text: n.title }));
  if (n.body) text.append(el('span', { text: n.body }));
  if (n.btn) text.append(el('button', { class: 'bl-btn', text: n.btn.label, onclick: e => { e.stopPropagation(); runAction(n.btn); markRead(n.id); close(); } }));
  b.append(el('span', { class: 'bl-ic' }, iconEl(nIcon(n))), text, el('button', { class: 'bl-x', title: 'Închide', 'aria-label': 'Închide', text: '✕', onclick: e => { e.stopPropagation(); close(); } }));
  if (n.click) { b.classList.add('clickable'); b.addEventListener('click', () => { runAction(n.click); markRead(n.id); close(); }); }
  b.addEventListener('mouseenter', () => clearTimeout(timer));
  b.addEventListener('mouseleave', () => { timer = setTimeout(close, 2000); });
  toastBox.append(b);
  timer = setTimeout(close, ms);
  while (toastBox.children.length > 4) toastBox.firstChild.remove();
}

// o = { title, body, icon (emoji sau 'app:cheie'), click: acțiune, btn: { label, ...acțiune }, store:false (doar balon), sound, timeout (ms) }
function notify(o) {
  const n = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: o.title || '', body: o.body || '', icon: o.icon || '🔔', at: Date.now(), read: false, click: o.click || null, btn: o.btn || null };
  const store = o.store !== false, centerOpen = !!$('#ncenter');
  if (store) { if (centerOpen) n.read = true; notifs.unshift(n); if (notifs.length > 60) notifs.length = 60; persistNotifs(); updateBadge(); if (centerOpen) renderCenter(); }
  const quiet = !!settings.dnd || (store && centerOpen);
  if (!quiet && settings.notifBalloons !== false) showBalloon(n, o.timeout || (settings.notifTimeout || 5) * 1000, !store);
  if (!quiet && store && (o.sound || settings.notifSound)) chime();
  if (store && !settings.dnd && settings.notifSystem && (document.hidden || !document.hasFocus())) sysNotify(n);
  return n;
}

/* --- mementouri --- */
function addReminder(text, secs) {
  settings.reminders.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), at: Date.now() + secs * 1000, text });
  saveSettings(); toast(`Memento peste ${fmtDur(secs)}: ${text}`);
  if ($('#ncenter')) renderCenter();
}
function checkReminders() {
  const now = Date.now(), due = settings.reminders.filter(r => r.at <= now);
  if (!due.length) return;
  settings.reminders = settings.reminders.filter(r => r.at > now); saveSettings();
  for (const r of due) notify({ title: now - r.at > 90000 ? 'Memento ratat' : 'Memento', body: r.text, icon: '⏰', sound: true });
  if ($('#ncenter')) renderCenter();
}

/* --- centrul de notificări (🔔) --- */
function toggleCenter() {
  const old = $('#ncenter'); if (old) { old.remove(); return; }
  const cal = $('#cal'); if (cal) cal.remove();
  document.body.append(el('div', { id: 'ncenter', role: 'dialog', 'aria-label': 'Notificări' }));
  notifs.forEach(n => { n.read = true; }); persistNotifs(); updateBadge();
  renderCenter();
}
function renderCenter() {
  const box = $('#ncenter'); if (!box) return;
  box.textContent = '';
  const dnd = el('input', { type: 'checkbox', onchange: e => { settings.dnd = e.target.checked; saveSettings(); updateBadge(); } });
  dnd.checked = !!settings.dnd;
  const list = el('div', { class: 'nc-list' });
  if (!notifs.length) list.append(el('p', { class: 'empty', style: 'margin:18px;text-align:center', text: 'Nicio notificare.' }));
  for (const n of notifs) {
    const item = el('div', { class: 'nc-item' + (n.click ? ' clickable' : '') },
      el('span', { class: 'bl-ic' }, iconEl(nIcon(n))),
      el('div', { class: 'nc-t' }, ...(n.title ? [el('b', { text: n.title })] : []), ...(n.body ? [el('span', { text: n.body })] : []),
        el('span', { class: 'nc-time', text: ago(n.at) }),
        ...(n.btn ? [el('button', { class: 'bl-btn', text: n.btn.label, onclick: e => { e.stopPropagation(); runAction(n.btn); } })] : [])),
      el('button', { class: 'bl-x', title: 'Șterge', 'aria-label': 'Șterge notificarea', text: '✕', onclick: e => { e.stopPropagation(); notifs = notifs.filter(x => x !== n); persistNotifs(); renderCenter(); } }));
    if (n.click) item.addEventListener('click', () => { box.remove(); runAction(n.click); });
    list.append(item);
  }
  const text = el('input', { class: 'path', placeholder: 'Memento nou…', 'aria-label': 'Text memento', onkeydown: e => { if (e.key === 'Enter') add.click(); } });
  const when = el('select', { class: 'path', 'aria-label': 'Peste cât timp', style: 'flex:none;width:96px' }, [['300', '5 min'], ['900', '15 min'], ['1800', '30 min'], ['3600', '1 oră'], ['10800', '3 ore'], ['86400', 'mâine']].map(([v, l]) => el('option', { value: v, text: l })));
  const add = btn('+', 'Adaugă memento', () => { const t = text.value.trim(); if (!t) return text.focus(); addReminder(t, +when.value); text.value = ''; }, 'primary');
  const pend = settings.reminders.slice().sort((a, b) => a.at - b.at);
  box.append(
    el('div', { class: 'nc-h' }, el('b', { text: 'Notificări' }), el('span', { class: 'spacer' }),
      el('label', { class: 'nc-dnd', title: 'Fără baloane și sunete' }, dnd, el('span', { text: 'Nu deranja' })),
      btn('Șterge tot', '', () => { notifs = []; persistNotifs(); renderCenter(); }, 'cmd')),
    list,
    el('div', { class: 'nc-sec' }, el('b', { text: 'Mementouri' }), el('div', { class: 'nc-rem' }, text, when, add),
      ...pend.map(r => el('div', { class: 'nc-r' }, el('span', { text: '⏰ ' + r.text }), el('span', { class: 'nc-time', text: 'în ' + fmtDur(Math.max(1, Math.round((r.at - Date.now()) / 1000))) }),
        el('button', { class: 'bl-x', title: 'Anulează', 'aria-label': 'Anulează mementoul', text: '✕', onclick: () => { settings.reminders = settings.reminders.filter(x => x.id !== r.id); saveSettings(); renderCenter(); } })))));
}

/* --- verificări la pornire (o dată pe sesiune) --- */
async function startupChecks() {
  try {
    if (await sess.get('checked')) return;
    await sess.set('checked', true);
    let bytes = 0;
    (function walk(n) { for (const x of Object.values(n.children)) { if (x.type === 'dir') walk(x); else bytes += sizeOf(x); } })(root);
    if (bytes > 80 * 1048576) notify({ title: 'Fișierele ocupă mult spațiu', body: `${fmtSize(bytes)}. Salvările pot deveni lente; mută sau șterge fișiere mari.`, icon: '💾', click: { type: 'app', app: 'files' } });
    const ref = settings.lastBackup || settings.createdAt;
    if (ref && Date.now() - ref > 14 * 86400000) notify({ title: 'Fă o copie de siguranță', body: 'Datele stau doar în browser. Exportă o copie din Setări → Sistem.', icon: '🛟', click: { type: 'settings', tab: 'system' }, btn: { label: 'Exportă acum', type: 'settings', tab: 'system' } });
  } catch {}
}

/* ---------- Solitaire (Klondike) ---------- */
const SOL = { w: 72, h: 100, gap: 12, pad: 16, topY: 12, tabY: 140, down: 12, up: 24 };
const SUIT_CH = ['♠', '♥', '♦', '♣'], RANK_CH = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const isRedCard = c => c.suit === 1 || c.suit === 2;
const solX = col => SOL.pad + col * (SOL.w + SOL.gap);
const fmtTime = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

function solDeal(draw = 1) {
  const deck = [];
  for (let s = 0; s < 4; s++) for (let r = 1; r <= 13; r++) deck.push({ suit: s, rank: r, up: false });
  for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
  const tab = [];
  for (let c = 0; c < 7; c++) { const pile = deck.splice(0, c + 1); pile[c].up = true; tab.push(pile); }
  return { stock: deck, waste: [], found: [[], [], [], []], tab, score: 0, moves: 0, draw };
}
function solCanTab(card, pile) {
  if (!pile.length) return card.rank === 13;
  const t = pile[pile.length - 1];
  return t.up && t.rank === card.rank + 1 && isRedCard(t) !== isRedCard(card);
}
function solCanFound(card, f) {
  if (!f.length) return card.rank === 1;
  const t = f[f.length - 1];
  return t.suit === card.suit && t.rank === card.rank - 1;
}
function solStack(S, src) {
  if (src.zone === 'waste') return S.waste.length ? [S.waste[S.waste.length - 1]] : [];
  if (src.zone === 'found') { const f = S.found[src.col]; return f.length ? [f[f.length - 1]] : []; }
  if (src.idx < 0) return [];
  const p = S.tab[src.col].slice(src.idx);
  return p.length && p[0].up ? p : [];
}
function solCanDrop(S, src, tgt) {
  const cards = solStack(S, src); if (!cards.length) return false;
  if (tgt.zone === 'tab') return !(src.zone === 'tab' && src.col === tgt.col) && solCanTab(cards[0], S.tab[tgt.col]);
  if (tgt.zone === 'found') return cards.length === 1 && solCanFound(cards[0], S.found[tgt.col]);
  return false;
}
function solApply(S, src, tgt) {
  let cards;
  if (src.zone === 'waste') cards = [S.waste.pop()];
  else if (src.zone === 'found') cards = [S.found[src.col].pop()];
  else cards = S.tab[src.col].splice(src.idx);
  if (tgt.zone === 'tab') S.tab[tgt.col].push(...cards); else S.found[tgt.col].push(...cards);
  let pts = 0;
  if (tgt.zone === 'found') pts += 10; else if (src.zone === 'waste') pts += 5; else if (src.zone === 'found') pts -= 15;
  if (src.zone === 'tab') { const p = S.tab[src.col]; if (p.length && !p[p.length - 1].up) { p[p.length - 1].up = true; pts += 5; } }
  S.score = Math.max(0, S.score + pts); S.moves++;
}
function solDrawStock(S) {
  if (S.stock.length) {
    const n = Math.min(S.draw, S.stock.length);
    for (let i = 0; i < n; i++) { const c = S.stock.pop(); c.up = true; S.waste.push(c); }
    S.moves++; return true;
  }
  if (S.waste.length) {
    while (S.waste.length) { const c = S.waste.pop(); c.up = false; S.stock.push(c); }
    if (S.draw === 1) S.score = Math.max(0, S.score - 100);
    S.moves++; return true;
  }
  return false;
}
const solWon = S => S.found.every(f => f.length === 13);
const solCanAuto = S => !solWon(S) && !S.stock.length && !S.waste.length && S.tab.every(p => p.every(c => c.up));
function solAutoStep(S) {
  const srcs = [{ zone: 'waste', col: 0, idx: S.waste.length - 1 }, ...S.tab.map((p, c) => ({ zone: 'tab', col: c, idx: p.length - 1 }))];
  for (const src of srcs) {
    const cs = solStack(S, src); if (cs.length !== 1) continue;
    for (let f = 0; f < 4; f++) if (solCanFound(cs[0], S.found[f])) { solApply(S, src, { zone: 'found', col: f }); return true; }
  }
  return false;
}
function solTargetAt(x, y) {
  const col = Math.floor((x - SOL.pad + SOL.gap / 2) / (SOL.w + SOL.gap));
  if (col < 0 || col > 6) return null;
  if (y < SOL.tabY - 20) return col >= 3 ? { zone: 'found', col: col - 3 } : null;
  return { zone: 'tab', col };
}

function solitaire() {
  const w = openWindow({ title: 'Solitaire', app: 'solitaire', w: 690, h: 650 });
  const st = settings.solStats;
  let S = solDeal(1), history = [], started = false, secs = 0, timer = 0, won = false, autoOn = false;
  const board = el('div', { class: 'sol-board' });
  const area = el('div', { class: 'sol-area' }, board);
  const status = el('div', { class: 'statusbar' });
  const autoBtn = btn('Auto-completare', 'Mută restul cărților pe fundații', () => autoComplete(), 'primary');
  autoBtn.style.display = 'none';
  const drawSel = el('select', { class: 'path', 'aria-label': 'Extragere', style: 'flex:none;width:104px', onchange: e => newGame(+e.target.value) },
    [['1', 'Extrage 1'], ['3', 'Extrage 3']].map(([v, l]) => el('option', { value: v, text: l })));
  const updateStatus = () => { status.textContent = `Punctaj: ${S.score}    Mutări: ${S.moves}    Timp: ${fmtTime(secs)}    |    Câștigate: ${st.won} din ${st.played}    Record: ${st.best}`; };
  const snap = () => { history.push(JSON.stringify(S)); if (history.length > 60) history.shift(); };
  function begin() {
    if (started || won) return;
    started = true; st.played++; saveSettings();
    timer = setInterval(() => { secs++; updateStatus(); }, 1000);
  }
  function newGame(draw = S.draw) {
    if (started && !won && !confirm('Începi un joc nou? Jocul curent se pierde.')) { drawSel.value = String(S.draw); return; }
    clearInterval(timer); S = solDeal(draw); history = []; started = false; secs = 0; won = false; autoOn = false;
    drawSel.value = String(draw); render();
  }
  function undo() { if (!history.length || won || autoOn) return; S = JSON.parse(history.pop()); render(); }
  function onWin() {
    won = true; clearInterval(timer); st.won++; st.best = Math.max(st.best, S.score); saveSettings();
    notify({ title: 'Solitaire: ai câștigat!', body: `${S.score} puncte în ${fmtTime(secs)}`, icon: 'app:solitaire' });
    const over = el('div', { class: 'sol-win' }, el('b', { text: 'Felicitări! Ai câștigat!' }), el('span', { text: `${S.score} puncte · ${S.moves} mutări · ${fmtTime(secs)}` }), btn('Joc nou', '', () => newGame(S.draw), 'primary'));
    for (let i = 0; i < 18; i++) over.append(el('span', { class: 'sol-fall', style: `left:${(i * 37) % 96}%;animation-delay:${(i % 6) * 0.4}s`, text: SUIT_CH[i % 4] }));
    area.append(over);
  }
  function autoComplete() {
    if (autoOn || !solCanAuto(S)) return;
    autoOn = true;
    const step = () => {
      if (!allWins.has(w)) return;
      snap();
      if (solAutoStep(S)) { render(); setTimeout(step, 110); } else { history.pop(); autoOn = false; render(); }
    };
    step();
  }
  function render() {
    board.textContent = '';
    const slot = (col, y, cls, txt = '') => board.append(el('div', { class: 'slot ' + cls, style: `left:${solX(col)}px;top:${y}px`, text: txt }));
    slot(0, SOL.topY, 'stock', '↻'); slot(1, SOL.topY, 'waste');
    for (let f = 0; f < 4; f++) slot(3 + f, SOL.topY, 'found', 'A');
    for (let c = 0; c < 7; c++) slot(c, SOL.tabY, 'tab');
    const card = (c, x, y, z, zone, col, idx) => {
      const d = el('div', { class: 'card ' + (c.up ? (isRedCard(c) ? 'red' : 'blk') : 'down'), 'data-zone': zone, 'data-col': String(col), 'data-idx': String(idx), style: `left:${x}px;top:${y}px;z-index:${z}` });
      if (c.up) d.append(el('span', { class: 'cr', text: RANK_CH[c.rank] + SUIT_CH[c.suit] }), el('span', { class: 'cs', text: SUIT_CH[c.suit] }));
      board.append(d);
    };
    if (S.stock.length) card(S.stock[S.stock.length - 1], solX(0), SOL.topY, 1, 'stock', 0, 0);
    const vis = S.draw === 3 ? S.waste.slice(-3) : S.waste.slice(-1), wb = S.waste.length - vis.length;
    vis.forEach((c, i) => card(c, solX(1) + i * (S.draw === 3 ? 16 : 0), SOL.topY, 2 + i, 'waste', 0, wb + i));
    S.found.forEach((f, i) => { if (f.length) card(f[f.length - 1], solX(3 + i), SOL.topY, 1, 'found', i, f.length - 1); });
    S.tab.forEach((pile, c) => { let y = SOL.tabY; pile.forEach((cd, j) => { card(cd, solX(c), y, j + 1, 'tab', c, j); y += cd.up ? SOL.up : SOL.down; }); });
    autoBtn.style.display = solCanAuto(S) ? '' : 'none';
    updateStatus();
    if (!won && solWon(S)) onWin();
  }
  const srcOf = c => ({ zone: c.dataset.zone, col: +c.dataset.col, idx: +c.dataset.idx });
  board.addEventListener('click', e => {
    if (won || autoOn || !(e.target.closest('.slot.stock') || e.target.closest('.card[data-zone="stock"]'))) return;
    snap(); if (solDrawStock(S)) begin(); else history.pop();
    render();
  });
  board.addEventListener('dblclick', e => {
    const c = e.target.closest('.card'); if (!c || won || autoOn || c.classList.contains('down') || c.dataset.zone === 'stock' || c.dataset.zone === 'found') return;
    const src = srcOf(c);
    if (src.zone === 'waste' && src.idx !== S.waste.length - 1) return;
    if (src.zone === 'tab' && src.idx !== S.tab[src.col].length - 1) return;
    for (let f = 0; f < 4; f++) if (solCanDrop(S, src, { zone: 'found', col: f })) { snap(); solApply(S, src, { zone: 'found', col: f }); begin(); render(); return; }
  });
  board.addEventListener('pointerdown', e => {
    const c = e.target.closest('.card'); if (!c || e.button !== 0 || won || autoOn || c.dataset.zone === 'stock' || c.classList.contains('down')) return;
    const src = srcOf(c);
    if (src.zone === 'waste' && src.idx !== S.waste.length - 1) return;
    if (!solStack(S, src).length) return;
    const els = [...board.querySelectorAll('.card')].filter(x => x.dataset.zone === src.zone && x.dataset.col === c.dataset.col && +x.dataset.idx >= src.idx);
    const starts = els.map(x => [x, x.offsetLeft, x.offsetTop]), sx = e.clientX, sy = e.clientY;
    let moved = false;
    const mv = ev => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (!moved) { if (Math.abs(dx) + Math.abs(dy) < 5) return; moved = true; els.forEach(x => { x.classList.add('drag'); x.style.zIndex = 200 + +x.dataset.idx; }); }
      starts.forEach(([x, l, t]) => { x.style.left = l + dx + 'px'; x.style.top = t + dy + 'px'; });
    };
    const up = ev => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
      if (!moved) return;
      const br = board.getBoundingClientRect(), tgt = solTargetAt(ev.clientX - br.left, ev.clientY - br.top);
      if (tgt && solCanDrop(S, src, tgt)) { snap(); solApply(S, src, tgt); begin(); }
      render();
    };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  });
  w.body.tabIndex = 0;
  w.body.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); } else if (e.key === 'F2') newGame(S.draw); });
  w.onClose = () => { clearInterval(timer); autoOn = false; };
  w.body.append(el('div', { class: 'tool' }, btn('Joc nou', 'F2', () => newGame(S.draw), 'primary'), btn('Anulează', 'Ctrl+Z', undo), drawSel, autoBtn), area, status);
  render();
}

/* ---------- Rulează (Alt+R), scurtături (.lnk), comutare ferestre (Alt+`) ---------- */
const APP_ALIAS = { cmd: 'terminal', powershell: 'terminal', shell: 'terminal', explorer: 'files', mspaint: 'paint', control: 'settings', 'control panel': 'settings', 'panou de control': 'settings', calculator: 'calc', calculatoare: 'calc', iexplore: 'browser', chrome: 'browser', helium: 'browser', 'task manager': 'taskmgr', taskmanager: 'taskmgr', cos: 'trash', 'cos de reciclare': 'trash', recycle: 'trash', sol: 'solitaire', wmplayer: 'music', mplayer: 'music' };
const RUN_SPECIAL = { lock: () => lock(), blocheaza: () => lock(), restart: () => location.reload(), reporneste: () => location.reload(), desktop: () => showDesktop(), taskview: () => toggleTaskView() };
const normKey = s => String(s).trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const stripLnk = nm => nm.replace(/\.lnk$/i, '');
const isUrl = t => /^https?:\/\//i.test(t) || /^(www\.)?[a-z0-9-]+(\.[a-z0-9-]+)+(\/\S*)?$/i.test(t);
function resolveApp(t) {
  const k = normKey(t);
  if (Object.hasOwn(apps, k)) return k;
  if (Object.hasOwn(APP_ALIAS, k)) return APP_ALIAS[k];
  for (const [key, a] of Object.entries(apps)) if (normKey(a.name) === k) return key;
  return null;
}
// interpretează un text ca Win+R: aplicație, comandă, cale în sistemul de fișiere sau adresă web
function runCommand(str) {
  const t = String(str).trim(); if (!t) return false;
  const a = resolveApp(t); if (a) { apps[a].open(); return true; }
  const sp = RUN_SPECIAL[normKey(t)]; if (sp) { sp(); return true; }
  for (const d of t.startsWith('/') ? ['/'] : ['/', '/Desktop', '/Documents']) { const p = norm(t, d); if (node(p)) { openPath(p); return true; } }
  const l = norm(t + '.lnk', '/Desktop'); if (node(l)) { openPath(l); return true; }
  if (isUrl(t)) { browser(/^https?:\/\//i.test(t) ? t : 'https://' + t); return true; }
  return false;
}

/* --- scurtături --- */
let runDepth = 0;
function parseLink(n) { try { const d = JSON.parse(n.content); return d && typeof d.target === 'string' ? d : null; } catch { return null; } }
function linkIcon(n, p) {
  const d = parseLink(n); if (!d) return '⚠️';
  if (d.icon) return d.icon;
  const a = resolveApp(d.target); if (a) return iconOf(a);
  const tp = norm(d.target, '/'), tn = node(tp);
  if (tn) return tn.type === 'dir' ? '📁' : (kindOf(tn, tp) === 'link' ? '🔗' : FILE_ICON[kindOf(tn, tp)]);
  return isUrl(d.target) ? '🌐' : '❓';
}
function runShortcut(n, p) {
  const d = parseLink(n);
  if (!d) { notify({ title: 'Scurtătură nevalidă', body: base(p), icon: '⚠️' }); return false; }
  if (runDepth > 5) { notify({ title: 'Scurtătură în buclă', body: base(p), icon: '⚠️' }); return false; }
  runDepth++;
  try {
    if (runCommand(d.target)) return true;
    notify({ title: 'Țintă lipsă', body: `„${d.target}” nu mai există.`, icon: '⚠️', click: { type: 'path', path: norm('..', p) }, btn: { label: 'Șterge scurtătura', type: 'trashlink', path: p } });
    return false;
  } finally { runDepth--; }
}
function targetName(t) {
  const a = resolveApp(t); if (a) return apps[a].name;
  if (!node(norm(t, '/')) && isUrl(t)) { try { return new URL(/^https?:\/\//i.test(t) ? t : 'https://' + t).hostname.replace(/^www\./, ''); } catch {} }
  return stripLnk(base(t)) || t;
}
function makeLink(dir, name, target, say = true) {
  const stem = String(name).replace(/[\/\\]/g, '_').replace(/\.lnk$/i, '').trim() || 'Scurtătură';
  const fname = uniqueName(dir, stem, '.lnk'), p = norm(fname, dir);
  const err = fs.write(p, JSON.stringify({ v: 1, target }));
  if (err) { alert(err); return null; }
  if (say) toast(`Scurtătură creată: ${stem}`);
  return p;
}
const linkName = p => `${stripLnk(base(p))} - Scurtătură`;
const makeLinkFor = p => makeLink(norm('..', p), linkName(p), p);
const linkToDesktop = p => makeLink('/Desktop', linkName(p), p);
function newLinkDialog(dir = '/Desktop') {
  const t = (prompt('Scrie locația elementului (aplicație, cale sau adresă web):', '') || '').trim();
  if (!t) return;
  const abs = norm(t, '/');
  if (!resolveApp(t) && !node(abs) && !isUrl(t)) return alert(`Nu am găsit „${t}”.`);
  const target = node(abs) && !resolveApp(t) ? abs : t;
  const nm = prompt('Nume scurtătură:', targetName(target));
  if (nm && nm.trim()) makeLink(dir, nm.trim(), target);
}
function linkMenuItems(p, n) {
  const d = parseLink(n) || { target: '' };
  const tp = norm(d.target || '/', '/'), tn = d.target && !resolveApp(d.target) ? node(tp) : null;
  const save = obj => { n.content = JSON.stringify(obj); n.mtime = Date.now(); changed(); };
  return [
    ...(tn ? [{ label: 'Deschide locația țintei', icon: '📂', fn: () => files(tn.type === 'dir' ? tp : norm('..', tp)) }] : []),
    { label: 'Schimbă ținta…', icon: '🎯', fn: () => { const v = prompt('Țintă (aplicație, cale sau adresă web):', d.target); if (v && v.trim()) save({ ...d, target: v.trim() }); } },
    { label: 'Schimbă pictograma…', icon: '🖼️', fn: () => pickFiles('image/*', async f => { try { save({ ...d, icon: await shrinkToDataURL(f[0], { square: 96, type: 'image/png' }) }); } catch { alert('Imaginea nu a putut fi citită.'); } }) },
    ...(d.icon ? [{ label: 'Pictogramă implicită', icon: '↺', fn: () => { const { icon, ...rest } = d; save(rest); } }] : []),
    { label: 'Editează ca text', icon: '📝', fn: () => notepad(p) }
  ];
}

/* --- dialogul „Rulează” --- */
function runDialog() {
  const old = $('#rundlg'); if (old) { const i = old.querySelector('input'); if (i) i.focus(); return; }
  const close = () => { const d = $('#rundlg'); if (d) d.remove(); };
  const inp = el('input', { class: 'path', id: 'run-in', list: 'run-list', placeholder: 'ex: paint, /Documents, exemplu.ro', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Deschidere' });
  const names = [...Object.values(apps).filter(a => !a.hidden).map(a => a.name), ...(settings.runHistory || [])];
  const dl = el('datalist', { id: 'run-list' }, [...new Set(names)].map(v => el('option', { value: v })));
  const msg = el('p', { class: 'run-msg', role: 'alert' });
  const dlg = el('section', { id: 'rundlg', class: 'win active', role: 'dialog', 'aria-label': 'Rulează' },
    el('header', { class: 'win-bar' }, el('span', { class: 'ico', text: '▶' }), el('span', { class: 'win-title', text: 'Rulează' }),
      el('span', { class: 'wb-group' }, el('button', { class: 'wb close', title: 'Închide', 'aria-label': 'Închide', text: '✕', onclick: close }))),
    el('div', { class: 'win-body run-body' },
      el('div', { class: 'run-row' }, el('span', { class: 'run-ic', text: '🚀' }), el('p', { text: 'Scrie numele unei aplicații, al unui folder sau document, ori o adresă web, iar HeliumOS îl va deschide.' })),
      el('div', { class: 'run-row' }, el('label', { for: 'run-in', text: 'Deschidere:' }), inp, dl), msg,
      el('div', { class: 'run-btns' }, btn('OK', '', go, 'primary'), btn('Anulare', '', close))));
  function go() {
    const v = inp.value.trim(); if (!v) return;
    if (runCommand(v)) {
      settings.runHistory = [v, ...(settings.runHistory || []).filter(x => x !== v)].slice(0, 15); saveSettings(); close();
    } else {
      msg.textContent = `HeliumOS nu găsește „${v}”. Verifică numele și încearcă din nou.`;
      dlg.classList.remove('shake'); void dlg.offsetWidth; dlg.classList.add('shake'); inp.select();
    }
  }
  dlg.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } else if (e.key === 'Escape') { e.stopPropagation(); close(); } });
  document.body.append(dlg); inp.focus();
}

/* --- comutare între ferestre (Alt+` / Alt+Q, ținând Alt apăsat) --- */
let sw = null;
const switcherList = () => [...allWins].filter(x => x.desk === vd.cur).sort((a, b) => (+b.win.style.zIndex || 0) - (+a.win.style.zIndex || 0));
function clearPeek() { allWins.forEach(x => x.win.classList.remove('pk-dim', 'pk-show')); }
function applyPeek() {
  if (!sw || !sw.visible) return;
  const cur = sw.list[sw.sel];
  allWins.forEach(x => { if (x.desk !== vd.cur) return; x.win.classList.toggle('pk-show', x === cur); x.win.classList.toggle('pk-dim', x !== cur); });
}
function openSwitcher(dir) {
  const list = switcherList();
  if (list.length < 2) { if (list[0]) list[0].focus(); return; }
  sw = { list, sel: dir > 0 ? 1 : list.length - 1, el: null, visible: false, timer: 0 };
  sw.timer = setTimeout(() => { if (sw) { sw.visible = true; renderSwitcher(); } }, 140);
}
function stepSwitcher(dir) {
  if (!sw) return;
  sw.sel = (sw.sel + dir + sw.list.length) % sw.list.length;
  clearTimeout(sw.timer); sw.visible = true;
  if (sw.el) markSwitcher(); else renderSwitcher();
}
function markSwitcher() {
  if (!sw || !sw.el) return;
  sw.el.querySelectorAll('.sw-card').forEach((c, i) => c.classList.toggle('on', i === sw.sel));
  const t = sw.el.querySelector('.sw-title'); if (t) t.textContent = sw.list[sw.sel].title;
  applyPeek();
}
function renderSwitcher() {
  if (!sw) return;
  sw.el = el('div', { id: 'switcher', role: 'listbox', 'aria-label': 'Comutare între ferestre' });
  const cards = sw.list.map((x, i) => el('div', { class: 'sw-card' + (i === sw.sel ? ' on' : ''), role: 'option',
    onclick: () => { sw.sel = i; commitSwitcher(); }, onmouseenter: () => { sw.sel = i; markSwitcher(); } },
    el('span', { class: 'sw-ic' }, iconEl(iconOf(x.app))), el('span', { class: 'sw-t', text: x.title })));
  sw.el.append(el('div', { class: 'sw-row' }, ...cards), el('div', { class: 'sw-title', text: sw.list[sw.sel].title }));
  document.body.append(sw.el); applyPeek();
}
function endSwitcher() { if (!sw) return null; clearTimeout(sw.timer); if (sw.el) sw.el.remove(); clearPeek(); const s = sw; sw = null; return s; }
function commitSwitcher() { const s = endSwitcher(); if (!s) return; const x = s.list[s.sel]; if (x && allWins.has(x)) x.focus(); }
function cancelSwitcher() { endSwitcher(); }

function installShortcuts() {
  document.addEventListener('keydown', e => {
    if (desktopKeys(e)) { e.preventDefault(); return; }
    const plainAlt = e.altKey && !e.ctrlKey && !e.metaKey;
    if (plainAlt && (e.code === 'Backquote' || e.code === 'KeyQ' || e.key === 'Tab')) {
      e.preventDefault(); if (e.repeat) return;
      const dir = e.shiftKey ? -1 : 1;
      if (!sw) openSwitcher(dir); else stepSwitcher(dir);
      return;
    }
    if ((e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey && e.code === 'KeyK') || (plainAlt && !e.shiftKey && e.code === 'KeyS')) { e.preventDefault(); toggleGS(); return; }
    if ((plainAlt && !e.shiftKey && e.code === 'KeyR') || (e.metaKey && !e.altKey && !e.ctrlKey && e.code === 'KeyR')) { e.preventDefault(); runDialog(); return; }
    if (sw) {
      if (e.key === 'Escape') { e.preventDefault(); cancelSwitcher(); }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); stepSwitcher(1); }
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); stepSwitcher(-1); }
      else if (e.key === 'Enter') { e.preventDefault(); commitSwitcher(); }
    }
  }, true);
  document.addEventListener('keyup', e => { if (sw && e.key === 'Alt') { e.preventDefault(); commitSwitcher(); } }, true);
  window.addEventListener('blur', cancelSwitcher);
}

/* ---------- aplicații proprii (HTML/JS rulat în sandbox) ---------- */
const uaSlug = s => normKey(s).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'app';
const stripExt = n => n.replace(/\.[^.]+$/, '');
async function dbDel(k) {
  const db = await idb();
  return new Promise((res, rej) => { const t = db.transaction(STORE, 'readwrite'); t.objectStore(STORE).delete(k); t.oncomplete = res; t.onerror = () => rej(t.error); });
}
const userAppById = id => settings.userApps.find(a => a.id === id);
const defaultPerms = () => ({ notify: true, files: true, fsAll: false, net: false });

function syncUserApps() {
  for (const k of Object.keys(apps)) if (k.startsWith('u:')) delete apps[k];
  for (const r of settings.userApps) apps['u:' + r.id] = { name: r.name, icon: r.icon || '🧩', user: true, open: () => runUserApp(r.id) };
}

// aplicațiile fără permisiunea „internet” primesc o politică CSP care blochează orice cerere externă
function withCsp(html, net) {
  if (net) return html;
  const meta = '<meta http-equiv="Content-Security-Policy" content="connect-src \'none\'; img-src data: blob:; media-src data: blob:; font-src data:; frame-src \'none\'; form-action \'none\'">';
  const m = html.match(/<head[^>]*>/i);
  if (m) return html.replace(m[0], () => m[0] + meta);
  const d = html.match(/^\s*<!doctype[^>]*>/i);
  return d ? d[0] + meta + html.slice(d[0].length) : meta + html;
}
// include în pagină scripturile, stilurile și imaginile din același folder (căi relative)
function inlineAssets(html, dir) {
  const read = p => { const n = node(norm(p, dir)); return n && n.type === 'file' ? n : null; };
  return html
    .replace(/<script\b([^>]*?)\bsrc=["']([^"':]+)["']([^>]*)>\s*<\/script>/gi, (m, a, src, b) => {
      const n = read(src); return n && !n.bin ? `<script${a}${b}>${n.content.replace(/<\/script/gi, '<\\/script')}</script>` : m;
    })
    .replace(/<link\b[^>]*?href=["']([^"':]+\.css)["'][^>]*>/gi, (m, href) => { const n = read(href); return n && !n.bin ? `<style>${n.content}</style>` : m; })
    .replace(/(<img\b[^>]*?\bsrc=["'])([^"':]+)(["'])/gi, (m, a, src, c) => {
      const n = read(src); if (!n) return m;
      if (n.bin) return a + n.content + c;
      return ext(src) === 'svg' ? a + 'data:image/svg+xml;utf8,' + encodeURIComponent(n.content) + c : m;
    });
}

/* --- RPC: ce poate cere o aplicație sistemului (verificat aici, nu în sandbox) --- */
function makeAppRpc(rec, key, w) {
  const dir = '/Apps/' + rec.id;
  let data = null, times = [];
  const getData = async () => data || (data = (await dbGet('appdata:' + rec.id)) || {});
  const need = perm => { if (!rec.perms[perm]) throw new Error('Permisiune lipsă: ' + perm); };
  const appPath = p => { const q = norm(String(p ?? '.'), dir); if (q !== dir && !q.startsWith(dir + '/')) throw new Error('Calea iese din folderul aplicației'); return q; };
  const absPath = p => norm(String(p ?? '/'), '/');
  const needAll = () => {
    if (rec.perms.fsAll) return;
    if (!confirm(`„${rec.name}” cere acces la TOATE fișierele tale (citire, scriere, ștergere). Permiți?`)) throw new Error('Acces refuzat');
    rec.perms.fsAll = true; if (!rec.temp) saveSettings();
  };
  const readF = p => { const n = node(p); if (!n || n.type !== 'file') throw new Error('Fișier inexistent: ' + p); return n.content; };
  const writeF = (p, c) => {
    c = String(c ?? ''); if (c.length > 5e6) throw new Error('Fișier prea mare (maxim 5 MB)');
    const e1 = fs.mkdirp(norm('..', p)); if (e1) throw new Error(e1);
    let err;
    if (c.startsWith('data:') && c.includes(',')) {
      const mime = c.slice(5, c.indexOf(',')).split(';')[0] || 'application/octet-stream';
      err = fs.put(p, { ...mkFile(c), bin: true, mime }); if (!err) changed();
    } else err = fs.write(p, c);
    if (err) throw new Error(err);
    return true;
  };
  const listF = p => { const n = node(p); if (!n || n.type !== 'dir') throw new Error('Folder inexistent: ' + p); return fs.ls(p).map(([name, x]) => ({ name, type: x.type, size: x.type === 'dir' ? 0 : sizeOf(x), mtime: x.mtime || 0 })); };
  const rmF = p => { const e = fs.rm(p, true); if (e) throw new Error(e); return true; };
  const putData = async d => { await dbSet('appdata:' + rec.id, d); return true; };
  return async function rpc(method, a) {
    switch (method) {
      case 'notify': {
        need('notify'); const t = Date.now(); times = times.filter(x => t - x < 10000);
        if (times.length >= 6) throw new Error('Prea multe notificări într-un timp scurt');
        times.push(t);
        notify({ title: String(a[0] ?? '').slice(0, 80), body: String(a[1] ?? '').slice(0, 300), icon: 'app:' + key, click: { type: 'app', app: key } });
        return true;
      }
      case 'storage.get': return (await getData())[String(a[0])] ?? null;
      case 'storage.set': {
        const d = await getData(), k = String(a[0]), old = d[k]; d[k] = a[1];
        if (JSON.stringify(d).length > 1e6) { if (old === undefined) delete d[k]; else d[k] = old; throw new Error('Spațiul de stocare al aplicației e plin (1 MB)'); }
        return putData(d);
      }
      case 'storage.remove': { const d = await getData(); delete d[String(a[0])]; return putData(d); }
      case 'storage.keys': return Object.keys(await getData());
      case 'files.read': need('files'); return readF(appPath(a[0]));
      case 'files.write': need('files'); return writeF(appPath(a[0]), a[1]);
      case 'files.list': need('files'); fs.mkdirp(dir); return listF(appPath(a[0]));
      case 'files.remove': need('files'); return rmF(appPath(a[0]));
      case 'fs.read': needAll(); return readF(absPath(a[0]));
      case 'fs.write': needAll(); return writeF(absPath(a[0]), a[1]);
      case 'fs.list': needAll(); return listF(absPath(a[0]));
      case 'fs.remove': needAll(); return rmF(absPath(a[0]));
      case 'run': needAll(); return runCommand(String(a[0] ?? ''));
      case 'system.info': return { version: '0.10', accent: settings.accent, theme: settings.theme, user: settings.userName, app: { id: rec.id, name: rec.name } };
      case 'window.setTitle': if (w) w.setTitle(String(a[0] ?? '').slice(0, 80)); return !!w;
      case 'window.focus': if (w) w.focus(); return !!w;
      case 'window.close': if (w) setTimeout(() => w.close(), 0); return !!w;
      case 'window.resize': {
        if (!w) return false;
        const W = Math.max(240, Math.min(2400, +a[0] || 0)), H = Math.max(160, Math.min(1600, +a[1] || 0));
        w.win.style.width = W + 'px'; w.win.style.height = H + 'px'; return true;
      }
      default: throw new Error('Metodă necunoscută: ' + method);
    }
  };
}
function attachAppBridge(frame, rec, key, w) {
  const rpc = makeAppRpc(rec, key, w);
  const h = async e => {
    if (e.source !== frame.contentWindow) return;
    const m = e.data; if (!m || m.type !== 'rpc' || typeof m.method !== 'string') return;
    const reply = r => { if (frame.contentWindow) frame.contentWindow.postMessage({ type: 'rpc-result', id: m.id, ...r }, '*'); };
    try { reply({ result: await rpc(m.method, Array.isArray(m.args) ? m.args : []) }); } catch (err) { reply({ error: String(err && err.message || err) }); }
  };
  window.addEventListener('message', h);
  return { dispose() { window.removeEventListener('message', h); } };
}

/* --- pornire --- */
function openAppWindow(key, rec, html, dir) {
  const w = openWindow({ title: rec.name, app: key, w: rec.w || 520, h: rec.h || 420 });
  const frame = el('iframe', { class: 'app-frame', src: 'sandbox.html', title: rec.name });
  w.body.append(frame);
  const bridge = attachAppBridge(frame, rec, key, w);
  frame.addEventListener('load', () => frame.contentWindow.postMessage({ type: 'app', code: withCsp(inlineAssets(html, dir), rec.perms.net), meta: { id: rec.id, name: rec.name } }, '*'));
  // clic în interiorul iframe-ului nu ajunge la fereastra-părinte: aducem fereastra în față când iframe-ul primește focusul
  const onBlur = () => setTimeout(() => { if (document.activeElement === frame && allWins.has(w)) w.focus(); }, 0);
  window.addEventListener('blur', onBlur);
  w.onClose = () => { bridge.dispose(); window.removeEventListener('blur', onBlur); };
  return w;
}
function runUserApp(id) {
  const rec = userAppById(id); if (!rec) return;
  const n = node(rec.path);
  if (!n || n.type !== 'file' || n.bin) {
    notify({ title: 'Aplicația nu poate porni', body: `Fișierul „${rec.path}” lipsește.`, icon: '⚠️', btn: { label: 'Dezinstalează', type: 'uninstall', id } });
    return;
  }
  openAppWindow('u:' + id, rec, n.content, norm('..', rec.path));
}
function runTempApp(path) {
  const n = node(path); if (!n || n.type !== 'file' || n.bin) return;
  const rec = { id: 'tmp-' + uaSlug(path), name: stripExt(base(path)), path, w: 520, h: 420, perms: defaultPerms(), temp: true };
  openAppWindow('tmpapp', rec, n.content, norm('..', path));
}

/* --- instalare / proprietăți --- */
function installDialog(path, rec0) {
  const editing = !!rec0;
  const d = JSON.parse(JSON.stringify(rec0 || { name: stripExt(base(path)), icon: '', path, w: 520, h: 420, perms: defaultPerms() }));
  d.perms = { ...defaultPerms(), ...d.perms };
  const place = { desktop: true, bar: false };
  const w = openWindow({ title: editing ? 'Proprietăți aplicație' : 'Instalează aplicația', app: 'settings', w: 480, h: 600 });
  const area = el('div', { class: 'sett' });
  const iconBox = el('span', { class: 'ig' });
  const drawIcon = () => { iconBox.textContent = ''; iconBox.append(iconEl(d.icon || '🧩')); };
  drawIcon();
  const field = (label, inp) => el('div', {}, el('p', { class: 'lbl', text: label }), inp);
  const nameIn = el('input', { class: 'path', value: d.name, 'aria-label': 'Nume', oninput: e => { d.name = e.target.value; } });
  const pathIn = el('input', { class: 'path', value: d.path, 'aria-label': 'Fișier', oninput: e => { d.path = e.target.value.trim(); } });
  const num = (v, fn, lbl) => el('input', { class: 'path', type: 'number', min: '240', max: '2400', value: String(v), 'aria-label': lbl, style: 'width:90px;flex:none', oninput: e => fn(+e.target.value || 0) });
  const chk = (label, checked, fn, cls = '') => { const i = el('input', { type: 'checkbox', onchange: e => fn(e.target.checked) }); i.checked = checked; return el('label', { class: cls }, i, el('span', { text: label })); };
  area.append(
    field('Nume', nameIn),
    el('div', {}, el('p', { class: 'lbl', text: 'Pictogramă' }), el('div', { class: 'row2' }, iconBox,
      btn('Imagine…', '', () => pickFiles('image/*', async f => { try { d.icon = await shrinkToDataURL(f[0], { square: 96, type: 'image/png' }); drawIcon(); } catch { alert('Imaginea nu a putut fi citită.'); } })),
      btn('Emoji…', '', () => { const v = prompt('Scrie un emoji sau un caracter:', ''); if (v && v.trim()) { d.icon = [...new Intl.Segmenter().segment(v.trim())][0].segment; drawIcon(); } }),
      btn('↺', 'Pictograma implicită', () => { d.icon = ''; drawIcon(); }))),
    field('Fișierul aplicației (.html)', pathIn),
    el('div', {}, el('p', { class: 'lbl', text: 'Dimensiunea ferestrei' }), el('div', { class: 'row2' }, num(d.w, v => { d.w = v; }, 'Lățime'), el('span', { text: '×' }), num(d.h, v => { d.h = v; }, 'Înălțime'), el('span', { class: 'hint', text: 'pixeli' }))),
    el('div', {}, el('p', { class: 'lbl', text: 'Permisiuni' }),
      chk('Notificări', d.perms.notify, v => { d.perms.notify = v; }),
      chk('Fișiere proprii (folderul /Apps/…)', d.perms.files, v => { d.perms.files = v; }),
      chk('Acces la internet (aplicația poate trimite date în afară)', d.perms.net, v => { d.perms.net = v; }, 'warn'),
      chk('Tot sistemul de fișiere (citire, scriere, ștergere)', d.perms.fsAll, v => { d.perms.fsAll = v; }, 'warn'),
      el('p', { class: 'hint', text: 'Implicit, aplicația nu are internet și vede doar propriul folder. Dă acces numai codului pe care îl ai scris sau îl înțelegi.' })),
    ...(editing ? [] : [el('div', {}, el('p', { class: 'lbl', text: 'Unde apare' }),
      chk('Pe desktop', true, v => { place.desktop = v; }), chk('În bara de activități', false, v => { place.bar = v; }))]),
    el('div', { class: 'row2' }, btn(editing ? 'Salvează' : 'Instalează', '', save, 'primary'), btn('Anulare', '', () => w.close())));
  w.body.append(area);
  function save() {
    const nm = d.name.trim();
    if (!nm) return alert('Alege un nume pentru aplicație.');
    const n = node(d.path);
    if (!n || n.type !== 'file' || n.bin) return alert('Fișierul aplicației nu există sau nu e un fișier text (.html).');
    d.w = Math.max(240, Math.min(2400, d.w || 520)); d.h = Math.max(160, Math.min(1600, d.h || 420));
    if (editing) {
      Object.assign(rec0, { name: nm, icon: d.icon, path: d.path, w: d.w, h: d.h, perms: d.perms });
      saveSettings(); syncUserApps(); refreshShell(); w.close(); toast('Salvat');
      return;
    }
    const taken = new Set(settings.userApps.map(a => a.id)); let id = uaSlug(nm), i = 2; const b = id;
    while (taken.has(id)) id = `${b}-${i++}`;
    settings.userApps.push({ id, name: nm, icon: d.icon, path: d.path, w: d.w, h: d.h, perms: d.perms });
    const k = 'u:' + id;
    if (place.desktop) settings.desk.push(k);
    if (place.bar) settings.pinned.push(k);
    saveSettings(); syncUserApps(); refreshShell(); w.close();
    notify({ title: 'Aplicație instalată', body: nm, icon: 'app:' + k, click: { type: 'app', app: k }, btn: { label: 'Deschide', type: 'app', app: k } });
  }
}
async function uninstallApp(id, done) {
  const rec = userAppById(id); if (!rec) return;
  if (!confirm(`Dezinstalezi „${rec.name}”? Fișierul ${rec.path} rămâne neschimbat.`)) return;
  const k = 'u:' + id;
  [...(winsByApp.get(k) || [])].forEach(x => x.close());
  const wipe = confirm('Ștergi și datele aplicației (stocarea proprie și folderul /Apps/' + id + ')?');
  settings.userApps = settings.userApps.filter(a => a.id !== id);
  settings.desk = settings.desk.filter(x => x !== k); settings.pinned = settings.pinned.filter(x => x !== k);
  delete settings.icons[k]; delete settings.iconPos['a:' + k];
  if (wipe) { try { await dbDel('appdata:' + id); } catch {} if (node('/Apps/' + id)) fs.rm('/Apps/' + id, true); }
  saveSettings(); syncUserApps(); refreshShell(); toast('Aplicație dezinstalată');
  if (done) done();
}
function userAppMenuItems(k) {
  const rec = userAppById(k.slice(2)); if (!rec) return [];
  return [
    { label: 'Editează codul', icon: '📝', fn: () => codeEditor(rec.path) },
    { label: 'Proprietăți…', icon: '⚙️', fn: () => installDialog(rec.path, rec) },
    { label: 'Dezinstalează', icon: '🗑️', fn: () => uninstallApp(rec.id) }
  ];
}

/* --- șabloane și exemple --- */
const TEMPLATE_APP = "<!doctype html>\n<html lang=\"ro\">\n<head>\n<meta charset=\"utf-8\">\n<title>Aplicația mea</title>\n<style>\n  body { margin: 0; padding: 16px; font: 15px system-ui, sans-serif; background: #f6f9fd; color: #16233a; }\n  h1 { margin: 0 0 8px; font-size: 20px; }\n  button { padding: 6px 14px; border: 1px solid #6f7f99; border-radius: 4px; background: #fff; cursor: pointer; }\n</style>\n</head>\n<body>\n  <h1>Salut din aplicația mea!</h1>\n  <p id=\"info\">Se încarcă…</p>\n  <button id=\"b\">Trimite o notificare</button>\n  <script>\n    // Obiectul \"helium\" oferă: notify, storage, files, window, system.\n    // Vezi ghidul: /Documents/Aplicatii-proprii.md\n    (async () => {\n      const sys = await helium.system();\n      document.getElementById('info').textContent = 'Aplicația „' + sys.app.name + '” rulează pentru ' + sys.user + '.';\n      document.body.style.borderLeft = '6px solid ' + sys.accent;\n    })();\n    document.getElementById('b').onclick = () => helium.notify('Salut!', 'Aplicația ta funcționează.');\n  </script>\n</body>\n</html>\n";
const EXAMPLE_FILES = {
  '/Documents/Aplicatii-exemplu/contor.html': "<!doctype html>\n<html lang=\"ro\">\n<head>\n<meta charset=\"utf-8\">\n<title>Contor</title>\n<style>\n  body { margin: 0; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 14px; font: 16px system-ui, sans-serif; background: #f4f7fc; color: #16233a; }\n  #n { font-size: 84px; font-weight: 700; }\n  button { font-size: 22px; padding: 8px 22px; border: 1px solid #6f7f99; border-radius: 6px; background: #fff; cursor: pointer; }\n  button:hover { background: #e6f0fb; }\n  small { opacity: .7; }\n</style>\n</head>\n<body>\n  <div id=\"n\">0</div>\n  <div><button id=\"m\">−</button> <button id=\"p\">+</button> <button id=\"r\">Reset</button></div>\n  <small id=\"s\">Se încarcă…</small>\n  <script>\n    // Exemplu: helium.storage păstrează date între porniri, helium.notify trimite o notificare.\n    let n = 0;\n    const show = () => { document.getElementById('n').textContent = n; };\n    (async () => {\n      n = (await helium.storage.get('n')) || 0; show();\n      document.getElementById('s').textContent = 'Valoarea se păstrează între porniri.';\n    })();\n    async function set(v) {\n      n = v; show();\n      await helium.storage.set('n', n);\n      if (n > 0 && n % 10 === 0) helium.notify('Contor', 'Ai ajuns la ' + n + '!');\n    }\n    document.getElementById('p').onclick = () => set(n + 1);\n    document.getElementById('m').onclick = () => set(n - 1);\n    document.getElementById('r').onclick = () => set(0);\n  </script>\n</body>\n</html>\n",
  '/Documents/Aplicatii-exemplu/note.html': "<!doctype html>\n<html lang=\"ro\">\n<head>\n<meta charset=\"utf-8\">\n<title>Notițe</title>\n<style>\n  html, body { height: 100%; margin: 0; }\n  body { display: flex; flex-direction: column; font: 15px system-ui, sans-serif; background: #fff; color: #16233a; }\n  textarea { flex: 1; border: 0; outline: 0; resize: none; padding: 12px; font: 15px/1.5 system-ui, sans-serif; }\n  footer { padding: 6px 12px; font-size: 12px; background: #eef3fa; color: #5b6b88; border-top: 1px solid #c3d0e4; }\n</style>\n</head>\n<body>\n  <textarea id=\"t\" placeholder=\"Scrie aici. Se salvează automat în folderul aplicației (/Apps/…).\"></textarea>\n  <footer id=\"s\">Se încarcă…</footer>\n  <script>\n    // Exemplu: helium.files citește și scrie în folderul propriu al aplicației.\n    const t = document.getElementById('t'), s = document.getElementById('s');\n    let timer;\n    (async () => {\n      try { t.value = await helium.files.read('notite.txt'); s.textContent = 'Încărcat.'; }\n      catch (e) { s.textContent = 'Notiță nouă.'; }\n    })();\n    t.addEventListener('input', () => {\n      s.textContent = 'Se modifică…'; clearTimeout(timer);\n      timer = setTimeout(async () => {\n        await helium.files.write('notite.txt', t.value);\n        s.textContent = 'Salvat la ' + new Date().toLocaleTimeString();\n      }, 500);\n    });\n  </script>\n</body>\n</html>\n",
  '/Documents/Aplicatii-proprii.md': "# Aplicații proprii în HeliumOS\n\nO aplicație este un fișier **HTML** (cu CSS și JavaScript) care rulează într-o fereastră a sistemului, izolat de restul. O poți instala ca să apară pe desktop, în Start și în bara de activități.\n\n## Cum faci o aplicație\n\n1. În **Cod** apasă „Șablon app” (sau Setări → Aplicații → „Aplicație nouă”) și scrie codul.\n2. Apasă **▶ Rulează** ca să o încerci (are acces la `helium`, ca o aplicație adevărată).\n3. Apasă **📦 Instalează…**, alege nume, pictogramă, dimensiuni și permisiuni.\n4. Click dreapta pe un fișier `.html` în Fișiere → „Deschide ca aplicație” (fără instalare) sau „Instalează ca aplicație…”.\n\nFișierele `.js` și `.css` din același folder, precum și imaginile, sunt incluse automat dacă le referi cu o cale relativă (de exemplu `<script src=\"app.js\">`). Bibliotecile de pe internet nu se pot încărca: lipește codul lor în folder.\n\n## Obiectul `helium`\n\nToate funcțiile returnează o promisiune (folosește `await`).\n\n| Funcție | Ce face |\n|---|---|\n| `helium.notify(titlu, mesaj)` | Trimite o notificare (permisiunea „Notificări”) |\n| `helium.storage.get(cheie)` / `set(cheie, valoare)` / `remove(cheie)` / `keys()` | Stocare proprie, păstrată între porniri (maxim 1 MB) |\n| `helium.files.read(cale)` / `write(cale, text)` / `list(folder)` / `remove(cale)` | Fișiere în folderul propriu `/Apps/<id>` (permisiunea „Fișiere proprii”) |\n| `helium.fs.read` / `write` / `list` / `remove` | Aceleași operații, dar pe **tot** sistemul de fișiere, cu căi absolute (cere confirmarea ta) |\n| `helium.run(comanda)` | Deschide o aplicație, un fișier sau o adresă, ca Win+R (cere acces la tot sistemul) |\n| `helium.system()` | Informații: `{ version, accent, theme, user, app }` |\n| `helium.window.setTitle(titlu)` / `resize(l, h)` / `close()` / `focus()` | Controlează fereastra aplicației |\n\nScrierea unui text care începe cu `data:` (de exemplu o imagine din canvas) salvează un fișier binar.\n\n## Permisiuni și siguranță\n\n- Aplicațiile rulează într-un **sandbox**: nu ating restul sistemului decât prin `helium`.\n- **Internetul este blocat implicit** (fără `fetch`, imagini sau fonturi externe). Îl poți permite din „Proprietăți”, dacă aplicația chiar are nevoie.\n- Accesul la **tot sistemul de fișiere** se cere la prima folosire și îl poți retrage din „Proprietăți”.\n- Instalează doar cod pe care îl înțelegi sau îl ai scris tu.\n\n## Exemple\n\nÎn `/Documents/Aplicatii-exemplu` găsești „Contor” (stocare + notificări) și „Notițe” (fișiere proprii). Le poți rula, instala și modifica.\n"
};
function seedExamples(say) {
  let n = 0;
  for (const [p, content] of Object.entries(EXAMPLE_FILES)) {
    if (node(p)) continue;
    if (fs.mkdirp(norm('..', p))) continue;
    if (!fs.write(p, content)) n++;
  }
  if (say) notify({ title: n ? 'Exemple adăugate' : 'Exemplele există deja', body: '/Documents/Aplicatii-exemplu și Aplicatii-proprii.md', icon: '🧩', click: { type: 'path', path: '/Documents/Aplicatii-exemplu' } });
  return n;
}
function newAppFromTemplate() {
  if (fs.mkdirp('/Documents/Aplicatii')) return;
  const nm = uniqueName('/Documents/Aplicatii', 'aplicatia-mea', '.html'), p = norm(nm, '/Documents/Aplicatii');
  if (fs.write(p, TEMPLATE_APP)) return;
  codeEditor(p);
  notify({ title: 'Aplicație nouă', body: 'Scrie codul, apasă ▶ Rulează, apoi 📦 Instalează…', icon: '🧩', store: false, timeout: 6000 });
}

/* ---------- căutare globală (Ctrl+K / Alt+S) ---------- */
const normText = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
let gsDirty = true, gsIndex = [], gs = null;
window.addEventListener('fs-change', () => { gsDirty = true; });
const GS_LABELS = { calc: 'Calcul', windows: 'Ferestre deschise', apps: 'Aplicații', commands: 'Comenzi', settings: 'Setări', files: 'Fișiere și foldere', content: 'În conținutul fișierelor', notifs: 'Notificări și mementouri', web: 'Web', recent: 'Recente' };
const GS_TAGS = { calc: 'Calcul', windows: 'Fereastră', apps: 'Aplicație', commands: 'Comandă', settings: 'Setare', files: 'Fișier', content: 'Conținut', notifs: 'Notificare', web: 'Web' };
const GS_LIMIT = { calc: 1, windows: 5, apps: 6, commands: 5, settings: 5, files: 8, content: 5, notifs: 4, web: 2 };
const GS_SETTINGS = [
  { title: 'Fundal desktop', kw: 'tapet wallpaper imagine fundal fit potrivire', tab: 'personal' },
  { title: 'Culoare ferestre', kw: 'accent culoare sticlă aero', tab: 'personal' },
  { title: 'Temă Aero sau Plat', kw: 'aspect stil transparență', tab: 'personal' },
  { title: 'Nume și poză de utilizator', kw: 'avatar profil nume', tab: 'personal' },
  { title: 'Fundal diferit pe fiecare desktop', kw: 'desktopuri virtuale wallpaper', tab: 'personal' },
  { title: 'Pictograme aplicații', kw: 'icon iconițe desktop bară emoji', tab: 'icons' },
  { title: 'Aplicații proprii', kw: 'instalează html helium dezinstalează', tab: 'apps' },
  { title: 'Parolă și login', kw: 'securitate cont autentificare blocare', tab: 'account' },
  { title: 'Animația de pornire', kw: 'boot start pornire', tab: 'account' },
  { title: 'Notificări', kw: 'baloane sunet nu deranja memento', tab: 'notif' },
  { title: 'Notificări de sistem', kw: 'permisiune desktop alerte', tab: 'notif' },
  { title: 'Copie de siguranță', kw: 'backup export restaurare salvare', tab: 'system' },
  { title: 'Resetare sistem', kw: 'șterge totul fabrică reset', tab: 'system' }
];
const gsCommands = () => [
  { id: 'lock', icon: '🔒', title: 'Blochează ecranul', kw: 'blocare lock logare', run: () => lock() },
  { id: 'vaultlock', icon: '🔐', title: 'Blochează seiful', kw: 'seif criptat vault parole', run: () => { vaultLock(); toast('Seiful a fost blocat'); } },
  { id: 'mountdir', icon: '💾', title: 'Montează un folder din calculator…', kw: 'disc folder real fișiere reale file system', run: mountDialog },
  { id: 'restart', icon: '⟳', title: 'Repornește HeliumOS', kw: 'restart reload reîncarcă', run: () => location.reload() },
  { id: 'showdesk', icon: '🖥️', title: 'Arată desktopul', kw: 'minimizează ferestrele show desktop', run: showDesktop },
  { id: 'taskview', icon: '▦', title: 'Vizualizare activități', kw: 'desktopuri virtuale task view', run: toggleTaskView },
  { id: 'newdesk', icon: '＋', title: 'Desktop virtual nou', kw: 'adaugă creează desktop', run: () => addDesk(true) },
  { id: 'dnd', icon: '🔕', title: settings.dnd ? 'Oprește „Nu deranja”' : 'Pornește „Nu deranja”', kw: 'notificări liniște dnd', run: () => { settings.dnd = !settings.dnd; saveSettings(); updateBadge(); toast(settings.dnd ? 'Nu deranja: pornit' : 'Nu deranja: oprit'); } },
  { id: 'clearnotifs', icon: '🧹', title: 'Șterge toate notificările', kw: 'curăță istoric notificări', run: () => { notifs = []; persistNotifs(); updateBadge(); toast('Notificările au fost șterse'); } },
  { id: 'notifs', icon: '🔔', title: 'Deschide notificările', kw: 'centru notificări mementouri', run: toggleCenter },
  { id: 'cal', icon: '📅', title: 'Arată calendarul', kw: 'data ceas calendar', run: toggleCal },
  { id: 'emptytrash', icon: '🗑️', title: 'Golește Coșul de reciclare', kw: 'șterge definitiv coș gunoi', run: () => { const l = fs.ls('/.Trash'); if (!l.length) return toast('Coșul e deja gol'); if (confirm(`Ștergi definitiv ${l.length} ${l.length === 1 ? 'element' : 'elemente'}?`)) l.forEach(([nm]) => fs.rm('/.Trash/' + nm, true)); } },
  { id: 'aero', icon: '🎨', title: 'Folosește tema Aero', kw: 'temă sticlă windows 7 aspect', run: () => { settings.theme = 'aero'; saveSettings(); } },
  { id: 'flat', icon: '🎨', title: 'Folosește tema Plat', kw: 'temă simplă aspect', run: () => { settings.theme = 'flat'; saveSettings(); } },
  { id: 'undofile', icon: '↶', title: 'Anulează ultima operație cu fișiere', kw: 'undo ctrl z fișiere', run: () => undoFileOp() },
  { id: 'redofile', icon: '↷', title: 'Refă operația cu fișiere', kw: 'redo ctrl y fișiere', run: () => redoFileOp() },
  { id: 'newtxt', icon: '📄', title: 'Fișier text nou pe desktop', kw: 'creează document', run: () => { const n = prompt('Nume fișier:', uniqueName('/Desktop', 'Fișier nou', '.txt')); if (n) { const e = fs.write(norm(n, '/Desktop'), ''); if (e) alert(e); } } },
  { id: 'newfolder', icon: '📁', title: 'Folder nou pe desktop', kw: 'creează director', run: () => { const n = prompt('Nume folder:', uniqueName('/Desktop', 'Folder nou', '')); if (n) { const e = fs.mkdir(norm(n, '/Desktop')); if (e) alert(e); } } },
  { id: 'newlink', icon: '🔗', title: 'Scurtătură nouă…', kw: 'lnk creează legătură', run: () => newLinkDialog('/Desktop') },
  { id: 'runbox', icon: '▶', title: 'Rulează…', kw: 'run comandă dialog', run: runDialog },
  { id: 'tm', icon: '📊', title: 'Manager de activități', kw: 'procese task manager performanță', run: () => apps.taskmgr.open() }
];

/* --- calcul rapid --- */
function mathEval(str) {
  const s = str.replace(/\s+/g, '').replace(/,/g, '.');
  const t = s.match(/\d+\.?\d*|\.\d+|[()+\-*/^%]/g);
  if (!t || t.join('') !== s) return null;
  let i = 0;
  const peek = () => t[i], next = () => t[i++];
  function prim() {
    const x = next(); let v;
    if (x === '(') { v = add(); if (next() !== ')') throw 0; }
    else if (x === '-') return -pow();
    else if (x === '+') return pow();
    else { v = parseFloat(x); if (isNaN(v)) throw 0; }
    while (peek() === '%') { next(); v /= 100; }
    return v;
  }
  function pow() { const b = prim(); if (peek() === '^') { next(); return b ** pow(); } return b; }
  function mul() { let v = pow(); while (peek() === '*' || peek() === '/') { const o = next(), r = pow(); v = o === '*' ? v * r : v / r; } return v; }
  function add() { let v = mul(); while (peek() === '+' || peek() === '-') { const o = next(), r = mul(); v = o === '+' ? v + r : v - r; } return v; }
  try { const v = add(); return i === t.length && Number.isFinite(v) ? v : null; } catch { return null; }
}
function gsMath(q) {
  const s = q.trim();
  if (!/^[\d\s+\-*/().,%^]+$/.test(s) || !/[+\-*/^%]/.test(s.replace(/^\s*[-+]/, ''))) return null;
  const v = mathEval(s); if (v === null) return null;
  const n = Number(v.toPrecision(12));
  return { v: n, disp: n.toLocaleString('ro-RO', { maximumFractionDigits: 10 }) };
}

/* --- potrivire --- */
function gsSubseq(s, t) { let j = 0; for (let i = 0; i < s.length && j < t.length; i++) if (s[i] === t[j]) j++; return j === t.length; }
function gsTermScore(nt, t) {
  if (!nt) return 0;
  if (nt === t) return 100;
  if (nt.startsWith(t)) return 80;
  const i = nt.indexOf(t);
  if (i > 0) return /[\s\-_./:()]/.test(nt[i - 1]) ? 60 : 40;
  // potrivire aproximativă (literele în ordine) doar pentru texte scurte, ca să nu apară rezultate false
  return t.length >= 3 && nt.length <= 28 && t.length / nt.length >= 0.4 && gsSubseq(nt, t) ? 15 : 0;
}
function gsScore(nt, terms) {
  let sum = 0;
  for (const t of terms) { const sc = gsTermScore(nt, t); if (!sc) return 0; sum += sc; }
  return sum / terms.length;
}
function gsBuildIndex() {
  const out = [];
  (function walk(d) {
    for (const [nm, x] of fs.ls(d)) {
      if (d === '/' && nm === '.Trash') continue;
      const p = norm(nm, d), isDir = x.type === 'dir', kind = isDir ? 'dir' : kindOf(x, p);
      const label = kind === 'link' ? stripLnk(nm) : nm;
      const e = { p, label, nname: normText(label), kind, isDir, nt: null, raw: null };
      if (!isDir && !x.bin && (kind === 'text' || kind === 'code' || kind === 'link') && x.content.length <= 200000) { e.raw = x.content; e.nt = normText(x.content); }
      out.push(e);
      if (isDir) walk(p);
    }
  })('/');
  return out;
}
function gsSnippet(e, term) {
  const i = e.nt.indexOf(term), src = e.nt.length === e.raw.length ? e.raw : e.nt;
  const a = Math.max(0, i - 24), b = Math.min(src.length, i + term.length + 48);
  return (a ? '…' : '') + src.slice(a, b).replace(/\s+/g, ' ').trim() + (b < src.length ? '…' : '');
}

/* --- rezultate --- */
function gsResolveRecent(rc) {
  if (rc.t === 'app' && apps[rc.v] && !apps[rc.v].hidden) return { cat: 'recent', tag: 'Aplicație', key: 'app:' + rc.v, icon: iconOf(rc.v), title: apps[rc.v].name, sub: apps[rc.v].user ? 'Aplicația ta' : 'Aplicație', run: () => apps[rc.v].open(), rec: rc };
  if (rc.t === 'file' && node(rc.v)) { const n = node(rc.v), k = n.type === 'dir' ? 'dir' : kindOf(n, rc.v); return { cat: 'recent', tag: n.type === 'dir' ? 'Folder' : 'Fișier', key: 'file:' + rc.v, icon: n.type === 'dir' ? '📁' : (k === 'link' ? linkIcon(n, rc.v) : FILE_ICON[k]), title: k === 'link' ? stripLnk(base(rc.v)) : base(rc.v), sub: rc.v, path: rc.v, run: () => openPath(rc.v), rec: rc }; }
  if (rc.t === 'set') { const s = GS_SETTINGS.find(x => x.title === rc.v); if (s) return { cat: 'recent', tag: 'Setare', key: 'set:' + s.title, icon: '⚙️', title: s.title, sub: 'Setări', run: () => settingsApp(s.tab), rec: rc }; }
  if (rc.t === 'cmd') { const c = gsCommands().find(x => x.id === rc.v); if (c) return { cat: 'recent', tag: 'Comandă', key: 'cmd:' + c.id, icon: c.icon, title: c.title, sub: 'Comandă', run: c.run, rec: rc }; }
  return null;
}
function gsRemember(rc) {
  if (!rc) return;
  settings.gsRecent = [rc, ...(settings.gsRecent || []).filter(x => !(x.t === rc.t && x.v === rc.v))].slice(0, 12);
  saveSettings();
}
function gsSearch(raw) {
  if (gsDirty) { gsIndex = gsBuildIndex(); gsDirty = false; }
  let q = String(raw).trim(), only = null;
  const pm = q.match(/^([afscwn]):\s*/i);
  if (pm) { only = { a: 'apps', f: 'files', s: 'settings', c: 'commands', w: 'windows', n: 'notifs' }[pm[1].toLowerCase()]; q = q.slice(pm[0].length); }
  const finish = groups => ({ q, terms: [], groups, flat: groups.flatMap(g => g.items) });
  if (!q) {
    const rec = (settings.gsRecent || []).map(gsResolveRecent).filter(Boolean);
    const seen = new Set(rec.map(r => r.key));
    const apps0 = Object.entries(apps).filter(([k, a]) => !a.hidden && !seen.has('app:' + k)).slice(0, 8).map(([k, a]) => ({ cat: 'apps', key: 'app:' + k, icon: iconOf(k), title: a.name, sub: a.user ? 'Aplicația ta' : 'Aplicație', run: () => a.open(), rec: { t: 'app', v: k } }));
    return finish([...(rec.length ? [{ cat: 'recent', label: GS_LABELS.recent, items: rec }] : []), ...(apps0.length ? [{ cat: 'apps', label: GS_LABELS.apps, items: apps0 }] : [])]);
  }
  const terms = normText(q).split(/\s+/).filter(Boolean);
  const rank = new Map((settings.gsRecent || []).map((r, i) => [r.t + ':' + r.v, i]));
  const boost = rc => rc && rank.has(rc.t + ':' + rc.v) ? 14 - Math.min(12, rank.get(rc.t + ':' + rc.v)) : 0;
  const res = [], allow = c => !only || only === c || (only === 'files' && c === 'content');
  const add = (cat, icon, title, sub, score, run, extra = {}) => res.push({ cat, icon, title, sub, score: score + boost(extra.rec) - title.length * 0.01, run, ...extra });

  if (!only) { const m = gsMath(q); if (m) add('calc', '🧮', '= ' + m.disp, 'Enter copiază rezultatul', 1000, () => { const t = String(m.v); if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(() => toast('Copiat: ' + t)).catch(() => toast('Rezultat: ' + t)); else toast('Rezultat: ' + t); }); }
  if (allow('apps')) for (const [k, a] of Object.entries(apps)) {
    if (a.hidden) continue;
    let s = gsScore(normText(a.name), terms);
    for (const [al, tk] of Object.entries(APP_ALIAS)) if (tk === k) s = Math.max(s, gsScore(al, terms) * 0.9);
    if (s) add('apps', iconOf(k), a.name, a.user ? 'Aplicația ta' : 'Aplicație', s + 10, () => a.open(), { rec: { t: 'app', v: k } });
  }
  if (allow('windows')) for (const x of allWins) {
    const s = Math.max(gsScore(normText(x.title), terms), gsScore(normText((apps[x.app] || {}).name || ''), terms) * 0.8);
    if (s) add('windows', iconOf(x.app), x.title, 'Fereastră deschisă' + (settings.vdesks.length > 1 ? ' · ' + deskName(x.desk) : ''), s + 8, () => x.focus());
  }
  if (allow('commands')) for (const c of gsCommands()) {
    const s = Math.max(gsScore(normText(c.title), terms), gsScore(normText(c.kw || ''), terms) * 0.8);
    if (s) add('commands', c.icon, c.title, 'Comandă', s, c.run, { rec: { t: 'cmd', v: c.id } });
  }
  if (allow('settings')) for (const st of GS_SETTINGS) {
    const s = Math.max(gsScore(normText(st.title), terms), gsScore(normText(st.kw), terms) * 0.8);
    if (s) add('settings', '⚙️', st.title, 'Setări', s, () => settingsApp(st.tab), { rec: { t: 'set', v: st.title } });
  }
  if (allow('files')) {
    const named = new Set();
    for (const e of gsIndex) {
      const s = gsScore(e.nname, terms);
      if (!s) continue;
      named.add(e.p);
      add('files', e.isDir ? '📁' : FILE_ICON[e.kind], e.label, e.p, s, () => openPath(e.p), { path: e.p, rec: { t: 'file', v: e.p } });
    }
    if (q.length >= 3) for (const e of gsIndex) {
      if (!e.nt || named.has(e.p) || !terms.every(t => e.nt.includes(t))) continue;
      add('content', FILE_ICON[e.kind], e.label, gsSnippet(e, terms[0]), 30, () => openPath(e.p), { path: e.p, rec: { t: 'file', v: e.p } });
    }
  }
  if (allow('notifs')) {
    for (const n of notifs) { const s = Math.max(gsScore(normText(n.title), terms), gsScore(normText(n.body), terms) * 0.8); if (s) add('notifs', nIcon(n), n.title || n.body, 'Notificare · ' + ago(n.at), s, toggleCenter); }
    for (const r of settings.reminders) { const s = gsScore(normText(r.text), terms); if (s) add('notifs', '⏰', r.text, 'Memento · în ' + fmtDur(Math.max(1, Math.round((r.at - Date.now()) / 1000))), s, toggleCenter); }
  }
  if (!only) {
    if (isUrl(q) && !node(norm(q, '/'))) add('web', '🌐', `Deschide ${q}`, 'În aplicația Browser', 70, () => browser(/^https?:\/\//i.test(q) ? q : 'https://' + q));
    add('web', '🔎', `Caută pe web: ${q}`, 'DuckDuckGo, în Browser', 1, () => browser('https://duckduckgo.com/?q=' + encodeURIComponent(q)));
  }
  const by = new Map();
  for (const r of res) { if (!by.has(r.cat)) by.set(r.cat, []); by.get(r.cat).push(r); }
  const groups = [...by].map(([cat, items]) => {
    items.sort((a, b) => b.score - a.score);
    return { cat, label: GS_LABELS[cat], items: items.slice(0, GS_LIMIT[cat] || 5), best: items[0].score };
  }).sort((a, b) => b.best - a.best);
  return { q, terms, groups, flat: groups.flatMap(g => g.items) };
}

/* --- interfața --- */
function gsHl(text, terms) {
  const nt = normText(text); if (nt.length !== text.length) return [text];
  const t = terms.find(x => nt.includes(x)); if (!t) return [text];
  const i = nt.indexOf(t);
  return [text.slice(0, i), el('mark', { text: text.slice(i, i + t.length) }), text.slice(i + t.length)];
}
const closeGS = () => { if (gs) { gs.el.remove(); gs = null; } };
const toggleGS = () => gs ? closeGS() : openGS();
function openGS(q = '') {
  if ($('#lock')) return;
  if (gs) { gs.input.value = q; gs.input.focus(); gsRender(); return; }
  closeCtx(); const mn = $('#menu'); if (mn) mn.classList.remove('open');
  const input = el('input', { type: 'text', placeholder: 'Caută aplicații, fișiere, setări, comenzi… sau scrie un calcul', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Căutare globală' });
  const list = el('div', { class: 'gs-list', role: 'listbox' });
  const back = el('div', { id: 'gs', role: 'dialog', 'aria-label': 'Căutare globală' },
    el('div', { class: 'gs-box' }, el('div', { class: 'gs-in' }, el('span', { class: 'gs-ic', text: '🔍' }), input), list,
      el('div', { class: 'gs-f', text: '↑↓ navighează · Enter deschide · Shift+Enter arată în folder · Esc închide · filtre: a: f: s: c: w: n:' })));
  back.addEventListener('pointerdown', e => { if (e.target === back) closeGS(); });
  document.body.append(back);
  gs = { el: back, input, list, flat: [], sel: 0, terms: [] };
  input.value = q;
  input.addEventListener('input', debounce(gsRender, 70));
  input.addEventListener('keydown', gsKey);
  gsRender(); input.focus();
}
function gsRender() {
  if (!gs) return;
  const r = gsSearch(gs.input.value);
  gs.flat = r.flat; gs.terms = r.terms; gs.sel = 0; gs.list.textContent = '';
  if (!r.flat.length) gs.list.append(el('p', { class: 'gs-empty', text: 'Nimic găsit.' }));
  let idx = 0;
  for (const g of r.groups) {
    gs.list.append(el('div', { class: 'gs-h', text: g.label }));
    for (const it of g.items) {
      const i = idx++;
      gs.list.append(el('div', { class: 'gs-i', role: 'option', 'data-i': String(i), onclick: () => gsRun(i, false), onmousemove: () => { if (gs && gs.sel !== i) { gs.sel = i; gsMark(false); } } },
        iconEl(it.icon),
        el('div', { class: 'gs-t' }, el('b', {}, ...gsHl(it.title, r.terms)), el('span', { class: 'gs-s', text: it.sub || '' })),
        el('span', { class: 'gs-tag', text: it.tag || GS_TAGS[it.cat] || '' })));
    }
  }
  gsMark(false);
}
function gsMark(scroll = true) {
  if (!gs) return;
  gs.list.querySelectorAll('.gs-i').forEach(x => { const on = +x.dataset.i === gs.sel; x.classList.toggle('on', on); if (on && scroll) x.scrollIntoView({ block: 'nearest' }); });
}
function gsRun(i, reveal) {
  const r = gs && gs.flat[i]; if (!r) return;
  closeGS();
  if (r.rec) gsRemember(r.rec);
  if (reveal && r.path) { const n = node(r.path); files(n && n.type === 'dir' ? r.path : norm('..', r.path)); return; }
  r.run();
}
function gsKey(e) {
  if (!gs) return;
  const n = gs.flat.length, move = d => { e.preventDefault(); if (n) { gs.sel = (gs.sel + d + n) % n; gsMark(); } };
  if (e.key === 'ArrowDown') move(1);
  else if (e.key === 'ArrowUp') move(-1);
  else if (e.key === 'PageDown') { e.preventDefault(); gs.sel = Math.min(n - 1, gs.sel + 6); gsMark(); }
  else if (e.key === 'PageUp') { e.preventDefault(); gs.sel = Math.max(0, gs.sel - 6); gsMark(); }
  else if (e.key === 'Enter') { e.preventDefault(); gsRun(gs.sel, e.shiftKey); }
  else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeGS(); }
  else if (e.key === 'Tab') move(e.shiftKey ? -1 : 1);
}

/* ---------- discuri montate: foldere reale din calculator (File System Access API) ---------- */
const MOUNT_ROOT = '/Mount';
const MOUNT_SKIP = new Set(['node_modules', '.git', '$RECYCLE.BIN', 'System Volume Information']);
const MOUNT_MAX = 5000, MOUNT_DEPTH = 10, MOUNT_COPY_MAX = 200 * 1048576;
const mountHandles = new Map();   // cale VFS -> FileSystemHandle
const mountState = new Map();     // id -> { online, count, cut }
const mountBusy = new Map();      // id -> coadă de scrieri (promisiune)
const mountPath = rec => MOUNT_ROOT + '/' + rec.name;
function mountOf(p) {
  for (const rec of ((settings && settings.mounts) || [])) { const b = mountPath(rec); if (p === b || p.startsWith(b + '/')) return rec; }
  return null;
}
const mountOnline = rec => !!(mountState.get(rec.id) || {}).online;
function mountGuard(rec) {
  if (rec.mode === 'read') return 'Disc montat doar pentru citire.';
  if (!mountOnline(rec)) return 'Discul este deconectat. Reconectează-l din Fișiere.';
  return null;
}
const hasLazy = n => n.type === 'dir' ? Object.values(n.children).some(hasLazy) : !!n.lazy;
function treeBytes(n) { return n.type === 'dir' ? Object.values(n.children).reduce((a, c) => a + treeBytes(c), 0) : (n.lazy ? (n.size || 0) : sizeOf(n)); }
function clearReal(n) { delete n.real; delete n.lazy; delete n.mountRoot; delete n.offline; if (n.type === 'dir') Object.values(n.children).forEach(clearReal); }
function markReal(n) { n.real = true; n.lazy = false; if (n.type === 'dir') Object.values(n.children).forEach(markReal); else n.size = sizeOf(n); }
// copia salvată în browser nu conține niciodată conținutul discurilor montate
function fsForSave() {
  const kids = {};
  for (const [k, v] of Object.entries(root.children)) if (k !== 'Mount') kids[k] = v;
  return { ...root, children: kids };
}

/* --- scrierea pe disc (coadă, în ordine) --- */
function mountQueue(rec, task) {
  const prev = mountBusy.get(rec.id) || Promise.resolve();
  const next = prev.then(task).catch(err => notify({ title: 'Eroare pe discul „' + rec.name + '”', body: String(err && err.message || err), icon: '⚠️', click: { type: 'path', path: mountPath(rec) } }));
  mountBusy.set(rec.id, next); return next;
}
const relOf = (rec, p) => p.slice(mountPath(rec).length).split('/').filter(Boolean);
async function mountDirHandle(rec, segs, create) {
  let h = mountHandles.get(mountPath(rec)); if (!h) throw new Error('Disc deconectat');
  let cur = mountPath(rec);
  for (const s of segs) { cur += '/' + s; h = await h.getDirectoryHandle(s, { create }); mountHandles.set(cur, h); }
  return h;
}
async function mountWriteFile(p, n) {
  const rec = mountOf(p), segs = relOf(rec, p), name = segs.pop();
  const dir = await mountDirHandle(rec, segs, true);
  const fh = await dir.getFileHandle(name, { create: true }); mountHandles.set(p, fh);
  const w = await fh.createWritable();
  try { await w.write(n.bin ? dataToBlob(n.content, n.mime) : n.content); } finally { await w.close(); }
}
async function mountEnsureDir(p) { const rec = mountOf(p); await mountDirHandle(rec, relOf(rec, p), true); }
async function mountRemove(p) {
  const rec = mountOf(p), segs = relOf(rec, p), name = segs.pop();
  const dir = await mountDirHandle(rec, segs, false);
  await dir.removeEntry(name, { recursive: true });
  for (const k of [...mountHandles.keys()]) if (k === p || k.startsWith(p + '/')) mountHandles.delete(k);
}
async function mountMoveFile(a, b, n) { await mountWriteFile(b, n); await mountRemove(a); }
async function mountWriteTree(p, n) {
  if (n.type === 'dir') { await mountEnsureDir(p); for (const [nm, c] of Object.entries(n.children)) await mountWriteTree(p + '/' + nm, c); }
  else await mountWriteFile(p, n);
}

/* --- conținut încărcat la cerere --- */
const isTextLike = (name, mime) => !mime.startsWith('image/') && !mime.startsWith('audio/') && !mime.startsWith('video/') && (mime.startsWith('text/') || TEXT_EXT.test(name));
async function ensureLoaded(p) {
  const n = node(p); if (!n || n.type !== 'file' || !n.lazy) return;
  const h = mountHandles.get(p); if (!h) throw new Error('Disc deconectat sau fișier lipsă');
  const f = await h.getFile();
  if (f.size > MAX_BYTES) throw new Error('Fișier prea mare (peste 20 MB)');
  const mime = f.type || MIME_EXT[ext(f.name)] || '';
  if (isTextLike(f.name, mime)) { n.content = await f.text(); delete n.bin; }
  else { n.content = await readDataURL(f); n.bin = true; n.mime = mime; }
  n.lazy = false; n.size = f.size; n.mtime = f.lastModified;
}
function loadThen(p, fn) {
  const n = node(p);
  if (!n || !n.lazy) return fn();
  ensureLoaded(p).then(fn).catch(e => notify({ title: 'Nu s-a putut citi fișierul', body: String(e && e.message || e), icon: '⚠️' }));
}
async function loadTree(p) {
  const n = node(p); if (!n) return;
  if (n.type === 'dir') { for (const nm of Object.keys(n.children)) await loadTree(p + '/' + nm); } else await ensureLoaded(p);
}

/* --- legarea de fs: scrierile în /Mount merg și pe discul real --- */
(function hookFs() {
  const raw = { put: fs.put, mkdir: fs.mkdir, rm: fs.rm, mv: fs.mv, cp: fs.cp, trash: fs.trash };
  const inContainer = p => norm('..', p) === MOUNT_ROOT;
  fs.put = (p, n) => {
    if (inContainer(p)) return 'Folderul Mount conține doar discuri montate.';
    const m = mountOf(p); if (!m) return raw.put(p, n);
    if (p === mountPath(m)) return 'Nu poți înlocui rădăcina discului.';
    const g = mountGuard(m); if (g) return g;
    const e = raw.put(p, n);
    if (!e) { n.real = true; n.lazy = false; n.size = sizeOf(n); mountQueue(m, () => mountWriteFile(p, n)); }
    return e;
  };
  fs.mkdir = p => {
    if (inContainer(p)) return 'Folderul Mount conține doar discuri montate.';
    const m = mountOf(p); if (!m) return raw.mkdir(p);
    if (p === mountPath(m)) return 'Există deja.';
    const g = mountGuard(m); if (g) return g;
    const e = raw.mkdir(p);
    if (!e) { node(p).real = true; mountQueue(m, () => mountEnsureDir(p)); }
    return e;
  };
  fs.rm = (p, recursive) => {
    if (p === MOUNT_ROOT) return 'Folderul Mount nu poate fi șters.';
    const m = mountOf(p); if (!m) return raw.rm(p, recursive);
    if (p === mountPath(m)) return 'Folosește „Elimină discul” ca să demontezi un disc.';
    const g = mountGuard(m); if (g) return g;
    const e = raw.rm(p, recursive);
    if (!e) mountQueue(m, () => mountRemove(p));
    return e;
  };
  fs.mv = (a, b) => {
    const nb = node(b), dest = nb && nb.type === 'dir' ? norm(base(a), b) : b, ma = mountOf(a), mb = mountOf(dest);
    if (a === MOUNT_ROOT || (ma && a === mountPath(ma))) return 'Discurile montate nu pot fi mutate sau redenumite.';
    if (!ma && !mb) return inContainer(dest) ? 'Folderul Mount conține doar discuri montate.' : raw.mv(a, b);
    if (ma !== mb) return 'Mutarea între discuri nu e suportată: copiază, apoi șterge originalul.';
    const src = node(a); if (!src) return 'Sursa nu există.';
    if (src.type !== 'file') return 'Mutarea sau redenumirea folderelor de pe disc nu e suportată (creează un folder nou și mută fișierele).';
    if (src.lazy) return 'Fișierul nu e încărcat încă. Deschide-l o dată și încearcă din nou.';
    const g = mountGuard(ma); if (g) return g;
    const e = raw.mv(a, b);
    if (!e && dest !== a) mountQueue(ma, () => mountMoveFile(a, dest, node(dest)));
    return e;
  };
  fs.cp = (a, b) => {
    const nb = node(b), dest = nb && nb.type === 'dir' ? norm(base(a), b) : b, src = node(a), mb = mountOf(dest);
    if (src && hasLazy(src)) return 'Fișierele de pe disc nu sunt încărcate încă (se încarcă automat la copierea din Fișiere).';
    if (inContainer(dest)) return 'Folderul Mount conține doar discuri montate.';
    if (mb) { const g = mountGuard(mb); if (g) return g; }
    const e = raw.cp(a, b);
    if (!e) { const n = node(dest); if (mb) { markReal(n); mountQueue(mb, () => mountWriteTree(dest, n)); } else clearReal(n); }
    return e;
  };
  fs.trash = p => mountOf(p) ? 'Fișierele de pe discuri montate nu merg în Coș; ștergerea de pe disc e definitivă.' : raw.trash(p);
})();

/* --- scanare, montare, reconectare --- */
function ensureMountRoots() {
  const list = (settings && settings.mounts) || [];
  if (!list.length && !root.children['Mount']) return;
  if (!root.children['Mount']) root.children['Mount'] = { type: 'dir', children: {}, real: true, mtime: Date.now() };
  const cont = root.children['Mount'];
  for (const rec of list) if (!cont.children[rec.name]) cont.children[rec.name] = { type: 'dir', children: {}, real: true, mountRoot: rec.id, offline: true, mtime: Date.now() };
  for (const nm of Object.keys(cont.children)) if (!list.some(r => r.name === nm)) delete cont.children[nm];
}
async function scanMount(rec) {
  const rootH = mountHandles.get(mountPath(rec)), rootNode = node(mountPath(rec));
  if (!rootH || !rootNode) throw new Error('Disc deconectat');
  rootNode.children = {};
  const budget = { n: 0, cut: false };
  async function walk(h, vnode, vpath, depth) {
    for await (const [name, eh] of h.entries()) {
      if (budget.n >= MOUNT_MAX) { budget.cut = true; return; }
      if (MOUNT_SKIP.has(name)) continue;
      budget.n++;
      const p = vpath + '/' + name; mountHandles.set(p, eh);
      if (eh.kind === 'directory') {
        const d = { type: 'dir', children: {}, real: true, mtime: 0 }; vnode.children[name] = d;
        if (depth < MOUNT_DEPTH) await walk(eh, d, p, depth + 1);
      } else {
        const f = await eh.getFile();
        vnode.children[name] = { type: 'file', content: '', real: true, lazy: true, size: f.size, mtime: f.lastModified, mime: f.type };
      }
    }
  }
  await walk(rootH, rootNode, mountPath(rec), 0);
  rootNode.offline = false; rootNode.mtime = Date.now();
  mountState.set(rec.id, { online: true, count: budget.n, cut: budget.cut });
  window.dispatchEvent(new Event('fs-change'));
  return budget;
}
async function mountAdd(h, mode) {
  const names = new Set(settings.mounts.map(r => r.name));
  const stem = (h.name || 'Disc').replace(/[\/\\]/g, '_'); let name = stem, i = 2;
  while (names.has(name)) name = `${stem} (${i++})`;
  const rec = { id: uaSlug(name) + '-' + randHex(3), name, mode: mode === 'read' ? 'read' : 'readwrite', at: Date.now() };
  settings.mounts.push(rec);
  try {
    await dbSet('mount:' + rec.id, h);
    ensureMountRoots(); mountHandles.set(mountPath(rec), h);
    const b = await scanMount(rec);
    saveSettings();
    notify({ title: 'Disc montat', body: `${rec.name} · ${b.n} elemente${b.cut ? ' (listă trunchiată la ' + MOUNT_MAX + ')' : ''}${rec.mode === 'read' ? ' · doar citire' : ''}`, icon: '💾', click: { type: 'path', path: mountPath(rec) } });
    return rec;
  } catch (e) {
    settings.mounts = settings.mounts.filter(r => r.id !== rec.id); ensureMountRoots(); mountHandles.delete(mountPath(rec));
    throw e;
  }
}
async function reconnectMount(id) {
  const rec = settings.mounts.find(r => r.id === id); if (!rec) return false;
  let h = null; try { h = await dbGet('mount:' + id); } catch {}
  if (!h) {
    if (confirm(`Accesul la „${rec.name}” s-a pierdut (de exemplu după o restaurare). Elimini discul din listă?`)) removeMount(id);
    return false;
  }
  const mode = rec.mode === 'read' ? 'read' : 'readwrite';
  try {
    let perm = await h.queryPermission({ mode });
    if (perm !== 'granted') perm = await h.requestPermission({ mode });
    if (perm !== 'granted') { notify({ title: 'Acces refuzat', body: `Browserul nu a permis accesul la „${rec.name}”.`, icon: '🔌' }); return false; }
    mountHandles.set(mountPath(rec), h);
    const b = await scanMount(rec);
    notify({ title: 'Disc reconectat', body: `${rec.name} · ${b.n} elemente`, icon: '💾', store: false });
    return true;
  } catch (e) { notify({ title: 'Nu s-a putut reconecta', body: String(e && e.message || e), icon: '⚠️' }); return false; }
}
function disconnectMount(id) {
  const rec = settings.mounts.find(r => r.id === id); if (!rec) return;
  const n = node(mountPath(rec)); if (n) { n.children = {}; n.offline = true; }
  for (const k of [...mountHandles.keys()]) if (k === mountPath(rec) || k.startsWith(mountPath(rec) + '/')) mountHandles.delete(k);
  mountState.set(id, { online: false });
  window.dispatchEvent(new Event('fs-change'));
}
async function removeMount(id) {
  const rec = settings.mounts.find(r => r.id === id); if (!rec) return;
  disconnectMount(id);
  settings.mounts = settings.mounts.filter(r => r.id !== id); mountState.delete(id);
  try { await dbDel('mount:' + id); } catch {}
  ensureMountRoots(); saveSettings();
  window.dispatchEvent(new Event('fs-change'));
}
function mountMenuItems(rec, go) {
  const on = mountOnline(rec);
  return [
    ...(on ? [{ label: 'Reîncarcă lista de fișiere', icon: '⟳', fn: () => reconnectMount(rec.id) }, { label: 'Deconectează', icon: '🔌', fn: () => disconnectMount(rec.id) }]
      : [{ label: 'Reconectează', icon: '💾', fn: async () => { if (await reconnectMount(rec.id) && go) go(mountPath(rec)); } }]),
    '-', { label: 'Elimină discul din listă', icon: '✕', fn: () => { if (confirm(`Elimini „${rec.name}” din listă? Fișierele de pe disc nu se șterg.`)) removeMount(rec.id); } }
  ];
}
function mountNavItems(go, cwd) {
  const out = [el('div', { class: 'nav-h', text: 'Discuri' })];
  for (const rec of settings.mounts) {
    const on = mountOnline(rec), p = mountPath(rec);
    out.push(el('button', {
      class: 'nav-i' + (cwd === p || cwd.startsWith(p + '/') ? ' on' : ''),
      title: on ? 'Disc montat' + (rec.mode === 'read' ? ' (doar citire)' : '') : 'Deconectat: click pentru reconectare',
      onclick: async () => { if (on || await reconnectMount(rec.id)) go(p); },
      oncontextmenu: e => { e.preventDefault(); ctxMenu(e.clientX, e.clientY, mountMenuItems(rec, go)); }
    }, el('span', { text: on ? '💾' : '🔌' }), el('span', { text: rec.name })));
  }
  out.push(el('button', { class: 'nav-i', onclick: mountDialog }, el('span', { text: '＋' }), el('span', { text: 'Montează folder…' })));
  return out;
}
function mountDialog() {
  const w = openWindow({ title: 'Montează un folder', app: 'files', w: 460, h: 330 });
  const pick = async mode => {
    if (!window.showDirectoryPicker) return alert('Browserul tău nu suportă montarea folderelor (File System Access API). Folosește un browser Chromium.');
    let h;
    try { h = await window.showDirectoryPicker({ mode: mode === 'read' ? 'read' : 'readwrite', id: 'heliumos-mount' }); } catch { return; }
    w.close();
    try { await mountAdd(h, mode); } catch (e) { alert('Nu s-a putut monta folderul: ' + (e && e.message || e)); }
  };
  w.body.append(el('div', { class: 'sett' },
    el('p', { class: 'lbl', text: 'Folder real din calculator' }),
    el('p', { class: 'hint', style: 'margin:0', text: 'Alege un folder de pe calculator. Apare în Fișiere sub /Mount, iar fișierele lui sunt cele reale: ce salvezi acolo se scrie pe disc, iar ce ștergi se șterge definitiv.' }),
    el('div', { class: 'row2' },
      btn('Montează (citire și scriere)', '', () => pick('readwrite'), 'primary'),
      btn('Montează doar pentru citire', 'Sigur: nimic nu poate fi modificat', () => pick('read'))),
    el('p', { class: 'hint', text: 'Browserul îți cere permisiunea. După repornire, discul apare „deconectat” până dai click pe el în Fișiere (permisiunea trebuie reconfirmată). Lista fișierelor se citește la montare; apasă „Reîncarcă” după modificări făcute din afară.' })));
}
// mută sau copiază între locații, ținând cont de discurile montate
async function moveEntry(src, dest) {
  const nd = node(dest), target = nd && nd.type === 'dir' ? norm(base(src), dest) : dest, ms = mountOf(src), md = mountOf(target);
  if (!ms && !md) { const er = fs.mv(src, dest); if (er) alert(er); return; }
  const sn = node(src); if (!sn) return;
  if (ms && ms === md && sn.type === 'file') {
    try { await ensureLoaded(src); } catch (e) { return alert('Nu s-a putut citi fișierul: ' + (e && e.message || e)); }
    const er = fs.mv(src, dest); if (er) alert(er); return;
  }
  if (treeBytes(sn) > MOUNT_COPY_MAX) return alert('Prea mult de copiat (peste 200 MB).');
  try { await loadTree(src); } catch (e) { return alert('Nu s-a putut citi: ' + (e && e.message || e)); }
  const er = fs.cp(src, dest); if (er) return alert(er);
  toast('Copiat. Mutarea între discuri nu e suportată, deci originalul a rămas pe loc.');
}

/* ---------- Seif criptat (AES-GCM 256, cheie derivată din parolă cu PBKDF2) ---------- */
const b64e = buf => { const u = new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
const b64d = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const VAULT_AAD = new TextEncoder().encode('heliumos-vault-v1');
const VAULT_ITER = 600000, VAULT_MAX_JSON = 30e6, VAULT_FILE_MAX = 7e6;

async function vaultDeriveKey(password, salt, iter) {
  const baseKey = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, baseKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function vaultSeal(data, key, salt, iter) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: VAULT_AAD }, key, new TextEncoder().encode(JSON.stringify(data)));
  return { v: 1, kdf: 'PBKDF2-SHA256', iter, salt: b64e(salt), iv: b64e(iv), ct: b64e(ct) };
}
async function vaultOpen(blob, password) {
  if (!blob || blob.v !== 1 || !blob.salt || !blob.iv || !blob.ct || !(blob.iter > 0)) throw new Error('Format de seif necunoscut');
  const salt = b64d(blob.salt), key = await vaultDeriveKey(password, salt, blob.iter);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64d(blob.iv), additionalData: VAULT_AAD }, key, b64d(blob.ct));
  return { key, salt, iter: blob.iter, data: JSON.parse(new TextDecoder().decode(pt)) };
}

let vault = null, vaultPending = null, vaultTimer = 0, vaultSaveQ = Promise.resolve();
const vaultExists = async () => !!(await dbGet('vault'));
async function vaultCreate(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16)), key = await vaultDeriveKey(password, salt, VAULT_ITER);
  const data = { v: 1, items: [] };
  await dbSet('vault', await vaultSeal(data, key, salt, VAULT_ITER));
  vault = { key, salt, iter: VAULT_ITER, data };
  vaultTouch();
}
async function vaultUnlock(password) {
  const blob = await dbGet('vault'); if (!blob) throw new Error('Nu există seif');
  const r = await vaultOpen(blob, password);
  vault = { key: r.key, salt: r.salt, iter: r.iter, data: r.data };
  vaultTouch();
}
function vaultLock() {
  if (!vault) return;
  vault = null; clearTimeout(vaultTimer);
  window.dispatchEvent(new Event('vault-lock'));
}
function vaultTouch() {
  clearTimeout(vaultTimer);
  const m = (settings.vault && settings.vault.autoLock) || 0;
  if (vault && m > 0) vaultTimer = setTimeout(() => { if (vault) { vaultLock(); toast('Seiful s-a blocat automat'); } }, m * 60000);
}
function vaultSaveNow() {
  vaultSaveQ = vaultSaveQ.then(async () => { if (vault) await dbSet('vault', await vaultSeal(vault.data, vault.key, vault.salt, vault.iter)); })
    .catch(e => notify({ title: 'Seiful nu s-a putut salva', body: String(e && e.message || e), icon: '⚠️' }));
  return vaultSaveQ;
}
async function vaultChangePassword(oldPw, newPw) {
  const blob = await dbGet('vault'); await vaultOpen(blob, oldPw);   // aruncă dacă parola veche e greșită
  const salt = crypto.getRandomValues(new Uint8Array(16)), key = await vaultDeriveKey(newPw, salt, VAULT_ITER);
  if (!vault) { const r = await vaultOpen(blob, oldPw); vault = { key: r.key, salt: r.salt, iter: r.iter, data: r.data }; }
  vault.key = key; vault.salt = salt; vault.iter = VAULT_ITER;
  await vaultSaveNow();
}
async function vaultDestroy(password) {
  await vaultOpen(await dbGet('vault'), password);
  await dbDel('vault'); vaultLock();
}

/* --- generator de parole și măsurarea puterii --- */
const GEN_SETS = { lower: 'abcdefghijkmnopqrstuvwxyz', upper: 'ABCDEFGHJKLMNPQRSTUVWXYZ', digits: '23456789', symbols: '!@#$%^&*()-_=+[]{};:,.?' };
function randInt(max) {
  const lim = Math.floor(0x100000000 / max) * max, a = new Uint32Array(1);
  do { crypto.getRandomValues(a); } while (a[0] >= lim);
  return a[0] % max;
}
function genPassword(len = 20, opts = { lower: true, upper: true, digits: true, symbols: true }) {
  let keys = Object.keys(GEN_SETS).filter(k => opts[k]); if (!keys.length) keys = ['lower'];
  len = Math.max(keys.length, Math.min(128, len | 0));
  const all = keys.map(k => GEN_SETS[k]).join('');
  const out = keys.map(k => GEN_SETS[k][randInt(GEN_SETS[k].length)]);
  while (out.length < len) out.push(all[randInt(all.length)]);
  for (let i = out.length - 1; i > 0; i--) { const j = randInt(i + 1); [out[i], out[j]] = [out[j], out[i]]; }
  return out.join('');
}
function strengthBits(pw) {
  if (!pw) return 0;
  let pool = 0;
  if (/[a-z]/.test(pw)) pool += 26; if (/[A-Z]/.test(pw)) pool += 26; if (/\d/.test(pw)) pool += 10; if (/[^A-Za-z0-9]/.test(pw)) pool += 32;
  return Math.round(Math.min(pw.length, new Set(pw).size * 2) * Math.log2(pool || 1));
}
const strengthLabel = b => b < 40 ? 'slabă' : b < 60 ? 'medie' : b < 80 ? 'bună' : 'foarte bună';

/* --- operații pe elemente --- */
const vaultNewId = () => Array.from(crypto.getRandomValues(new Uint32Array(2))).map(n => n.toString(36)).join('');
function vaultBytes() { return vault ? JSON.stringify(vault.data).length : 0; }
function vaultFileFromNode(p, n) {
  return n.bin ? { text: false, content: n.content, mime: n.mime || MIME_EXT[ext(p)] || 'application/octet-stream' } : { text: true, content: n.content, mime: 'text/plain' };
}
function vaultAddFileItem(name, f) {
  if (!vault) throw new Error('Seiful este blocat');
  if (f.content.length > VAULT_FILE_MAX) throw new Error('Fișier prea mare pentru seif (maxim ~5 MB)');
  if (vaultBytes() + f.content.length > VAULT_MAX_JSON) throw new Error('Seiful e plin (maxim ~30 MB)');
  const now = Date.now(), item = { id: vaultNewId(), type: 'file', title: name, name, mime: f.mime, text: !!f.text, size: f.text ? f.content.length : Math.round(f.content.length * 0.75), content: f.content, created: now, updated: now };
  vault.data.items.push(item); return item;
}
function vaultExportFile(item) {
  const nm = uniqueName('/Documents', stripExt(item.name || item.title), (item.name.match(/\.[^.]*$/) || [''])[0]), p = norm(nm, '/Documents');
  const err = item.text ? fs.write(p, item.content) : (() => { const e = fs.put(p, { ...mkFile(item.content), bin: true, mime: item.mime }); if (!e) changed(); return e; })();
  if (err) throw new Error(err);
  return p;
}
function vaultCopy(text, label) {
  if (!navigator.clipboard || !navigator.clipboard.writeText) return toast('Copierea nu e disponibilă în acest browser');
  navigator.clipboard.writeText(text).then(() => {
    const clr = settings.vault && settings.vault.clip;
    toast(label + ' copiat' + (clr ? ' (se șterge din clipboard în 20 s)' : ''));
    if (clr) setTimeout(() => { navigator.clipboard.writeText('').catch(() => {}); }, 20000);
  }).catch(() => toast('Nu s-a putut copia'));
}
function vaultAddFromPath(p) {
  vaultPending = p;
  const ex = (winsByApp.get('vault') || [])[0];
  if (ex) { ex.focus(); window.dispatchEvent(new Event('vault-pending')); } else vaultApp();
}

/* --- aplicația --- */
function vaultApp() {
  const ex = (winsByApp.get('vault') || [])[0]; if (ex) { ex.focus(); return; }
  const w = openWindow({ title: 'Seif', app: 'vault', w: 800, h: 560 });
  const rootEl = el('div', { class: 'vt' }); w.body.append(rootEl);
  let exists = null, sel = null, draft = null, dirty = false, query = '', view = 'item', fails = 0, until = 0;
  const gen = { len: 20, lower: true, upper: true, digits: true, symbols: true };
  const pwField = (ph, onEnter) => { const i = el('input', { class: 'path', type: 'password', placeholder: ph, autocomplete: 'off', 'aria-label': ph }); if (onEnter) i.addEventListener('keydown', e => { if (e.key === 'Enter') onEnter(); }); return i; };
  const meter = pw => { const b = strengthBits(pw), pct = Math.min(100, b), bar = el('div', { class: 'vt-bar' }, el('i', { style: `width:${pct}%;background:${b < 40 ? '#d9573c' : b < 60 ? '#e0a030' : b < 80 ? '#58a85a' : '#2a8f4f'}` })); return el('div', { class: 'vt-meter' }, bar, el('span', { text: pw ? 'Putere: ' + strengthLabel(b) : '' })); };

  /* blocat / creare */
  function viewLocked() {
    rootEl.textContent = '';
    const creating = !exists;
    let pw2 = null, meterBox = el('div');
    const msg = el('p', { class: 'vt-msg', role: 'alert' });
    const goBtn = btn(creating ? 'Creează seiful' : 'Deblochează', '', go, 'primary');
    const pw = pwField(creating ? 'Alege o parolă pentru seif' : 'Parola seifului', creating ? null : go);
    if (creating) { pw2 = pwField('Repetă parola', go); pw.addEventListener('input', () => { meterBox.replaceChildren(meter(pw.value)); }); }
    async function go() {
      if (Date.now() < until) { msg.textContent = `Așteaptă ${Math.ceil((until - Date.now()) / 1000)} s înainte de o nouă încercare.`; return; }
      if (creating) {
        if (pw.value.length < 8) { msg.textContent = 'Parola trebuie să aibă cel puțin 8 caractere.'; return; }
        if (pw.value !== pw2.value) { msg.textContent = 'Parolele nu coincid.'; return; }
      } else if (!pw.value) return;
      goBtn.disabled = true; msg.textContent = 'Se calculează cheia…';
      try {
        if (creating) { await vaultCreate(pw.value); exists = true; } else await vaultUnlock(pw.value);
        fails = 0; sel = null; draft = null; view = 'item'; render();
      } catch {
        fails++; until = Date.now() + Math.min(30000, 1000 * 2 ** fails);
        msg.textContent = 'Parolă incorectă.'; goBtn.disabled = false; pw.value = ''; pw.focus();
      }
    }
    rootEl.append(el('div', { class: 'vt-lock' },
      el('div', { class: 'vt-big', text: '🔐' }),
      el('h2', { text: creating ? 'Creează seiful tău' : 'Seiful este blocat' }),
      el('p', { class: 'vt-hint', text: creating ? 'Parole, notițe și fișiere criptate cu parola ta (AES-256). Parola nu se poate recupera: dacă o uiți, conținutul se pierde.' : 'Introdu parola ca să-l deschizi.' }),
      pw, ...(pw2 ? [pw2, meterBox] : []), goBtn, msg));
    pw.focus();
  }

  /* deblocat */
  function visibleItems() {
    const q = normText(query);
    return vault.data.items.filter(i => !q || normText([i.title, i.user, i.url, i.name].filter(Boolean).join(' ')).includes(q))
      .sort((a, b) => a.title.localeCompare(b.title, 'ro'));
  }
  const TYPE_ICON = { login: '🔑', note: '📝', file: '📎' };
  function confirmLeave() { return !dirty || confirm('Ai modificări nesalvate. Renunți la ele?'); }
  function pick(id) {
    if (!confirmLeave()) return;
    const it = vault.data.items.find(i => i.id === id);
    sel = id; draft = it ? JSON.parse(JSON.stringify(it)) : null; dirty = false; view = 'item'; renderOpen();
  }
  function newItem(type) {
    if (!confirmLeave()) return;
    draft = { id: vaultNewId(), type, title: '', isNew: true, user: '', password: '', url: '', notes: '', text: '' };
    sel = null; dirty = false; view = 'item'; renderOpen();
  }
  async function saveDraft() {
    const d = draft; if (!d) return;
    if (!d.title.trim()) return toast('Alege un titlu.');
    d.title = d.title.trim(); d.updated = Date.now();
    const copy = JSON.parse(JSON.stringify(d)); delete copy.isNew;
    const i = vault.data.items.findIndex(x => x.id === copy.id);
    if (i >= 0) vault.data.items[i] = copy; else { copy.created = Date.now(); vault.data.items.push(copy); }
    if (vaultBytes() > VAULT_MAX_JSON) { toast('Seiful e plin.'); return; }
    await vaultSaveNow(); delete d.isNew; dirty = false; sel = copy.id; draft = JSON.parse(JSON.stringify(copy)); renderOpen(); toast('Salvat în seif (criptat)');
  }
  async function deleteItem() {
    if (!draft || draft.isNew) { draft = null; dirty = false; return renderOpen(); }
    if (!confirm(`Ștergi „${draft.title}” din seif? Nu poate fi recuperat.`)) return;
    vault.data.items = vault.data.items.filter(x => x.id !== draft.id);
    await vaultSaveNow(); draft = null; sel = null; dirty = false; renderOpen();
  }
  async function processPending() {
    const p = vaultPending; if (!p || !vault) return; vaultPending = null;
    loadThen(p, async () => {
      const n = node(p); if (!n || n.type !== 'file') return;
      try {
        const it = vaultAddFileItem(base(p), vaultFileFromNode(p, n)); await vaultSaveNow();
        sel = it.id; draft = JSON.parse(JSON.stringify(it)); renderOpen();
        notify({ title: 'Fișier adăugat în seif', body: base(p), icon: '🔐', store: false });
        if (!mountOf(p) && confirm(`„${base(p)}” e acum criptat în seif. Ștergi originalul din ${norm('..', p)}?`)) fs.rm(p, true);
      } catch (e) { alert(e.message); }
    });
  }

  let listEl, paneEl;
  function renderList() {
    if (!listEl) return;
    listEl.textContent = '';
    const items = visibleItems();
    if (!items.length) listEl.append(el('p', { class: 'vt-hint', style: 'margin:16px', text: vault.data.items.length ? 'Nimic găsit.' : 'Seiful e gol. Adaugă prima parolă, notiță sau un fișier.' }));
    for (const it of items) listEl.append(el('button', { class: 'vt-i' + (it.id === sel ? ' on' : ''), onclick: () => pick(it.id) },
      el('span', { text: TYPE_ICON[it.type] || '•' }), el('span', { class: 'vt-it', text: it.title }), el('span', { class: 'vt-is', text: it.type === 'login' ? (it.user || '') : it.type === 'file' ? fmtSize(it.size || 0) : '' })));
  }
  function genOptions(onChange) {
    const row = el('div', { class: 'vt-row' });
    const len = el('input', { type: 'range', min: '8', max: '64', value: String(gen.len), 'aria-label': 'Lungime', oninput: e => { gen.len = +e.target.value; lbl.textContent = 'Lungime: ' + gen.len; onChange(); } });
    const lbl = el('span', { text: 'Lungime: ' + gen.len });
    row.append(lbl, len);
    for (const [k, t] of [['lower', 'a-z'], ['upper', 'A-Z'], ['digits', '0-9'], ['symbols', '!@#']]) {
      const c = el('input', { type: 'checkbox', onchange: e => { gen[k] = e.target.checked; onChange(); } }); c.checked = gen[k];
      row.append(el('label', { class: 'vt-ck' }, c, el('span', { text: t })));
    }
    return row;
  }
  function paneGen() {
    const out = el('input', { class: 'path', readonly: '', 'aria-label': 'Parolă generată', style: 'font-family:var(--mono)' });
    const m = el('div');
    const regen = () => { out.value = genPassword(gen.len, gen); m.replaceChildren(meter(out.value)); };
    paneEl.append(el('h3', { text: 'Generator de parole' }), genOptions(regen), out, m,
      el('div', { class: 'row2' }, btn('Generează alta', '', regen, 'primary'), btn('Copiază', '', () => vaultCopy(out.value, 'Parola'))));
    regen();
  }
  function paneOpts() {
    const cur = pwField('Parola actuală'), np = pwField('Parola nouă'), np2 = pwField('Repetă parola nouă'), msg = el('p', { class: 'vt-msg', role: 'status' });
    const auto = el('select', { class: 'path', 'aria-label': 'Blocare automată', style: 'width:auto', onchange: e => { settings.vault.autoLock = +e.target.value; saveSettings(); vaultTouch(); } },
      [[0, 'Niciodată'], [1, 'după 1 minut'], [5, 'după 5 minute'], [15, 'după 15 minute'], [30, 'după 30 de minute'], [60, 'după 1 oră']].map(([v, l]) => el('option', { value: String(v), text: l })));
    auto.value = String(settings.vault.autoLock);
    const clip = el('input', { type: 'checkbox', onchange: e => { settings.vault.clip = e.target.checked; saveSettings(); } }); clip.checked = !!settings.vault.clip;
    paneEl.append(el('h3', { text: 'Opțiuni' }),
      el('div', {}, el('p', { class: 'lbl', text: 'Schimbă parola seifului' }), cur, np, np2, msg,
        btn('Schimbă parola', '', async () => {
          if (np.value.length < 8) return void (msg.textContent = 'Parola nouă trebuie să aibă cel puțin 8 caractere.');
          if (np.value !== np2.value) return void (msg.textContent = 'Parolele noi nu coincid.');
          msg.textContent = 'Se recriptează…';
          try { await vaultChangePassword(cur.value, np.value); cur.value = np.value = np2.value = ''; msg.textContent = 'Parola a fost schimbată.'; toast('Parola seifului a fost schimbată'); } catch { msg.textContent = 'Parola actuală este greșită.'; }
        }, 'primary')),
      el('div', {}, el('p', { class: 'lbl', text: 'Blocare automată' }), auto, el('label', { class: 'vt-ck', style: 'margin-top:8px' }, clip, el('span', { text: 'Golește clipboardul la 20 s după copierea unei parole' }))),
      el('div', {}, el('p', { class: 'lbl', text: 'Copie de siguranță' }),
        el('div', { class: 'row2' },
          btn('Exportă seiful criptat', '', async () => { const b = await dbGet('vault'); const url = URL.createObjectURL(new Blob([JSON.stringify(b)], { type: 'application/json' })); const a = el('a', { href: url, download: 'heliumos-seif.vault' }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000); }),
          btn('Importă un seif…', '', () => pickFiles('.vault,application/json', async f => {
            try { const b = JSON.parse(await f[0].text()); if (b.v !== 1 || !b.salt || !b.iv || !b.ct) throw 0; if (!confirm('Înlocuiești seiful curent cu cel importat? Seiful curent se pierde.')) return; await dbSet('vault', b); vaultLock(); toast('Seif importat. Deblochează-l cu parola lui.'); } catch { alert('Fișierul nu e un seif valid.'); }
          }))),
        el('p', { class: 'vt-hint', text: 'Exportul conține doar date criptate: e sigur de păstrat, dar inutil fără parolă.' })),
      el('div', {}, el('p', { class: 'lbl', text: 'Zonă periculoasă' }),
        btn('Șterge seiful…', '', async () => { const p = prompt('Scrie parola seifului ca să-l ștergi definitiv:'); if (!p) return; try { await vaultDestroy(p); exists = false; toast('Seiful a fost șters'); } catch { alert('Parolă greșită.'); } })));
  }
  function panePlain() { paneEl.append(el('p', { class: 'vt-hint', style: 'margin:24px', text: 'Alege un element din listă sau adaugă unul nou. Tot ce vezi aici există necriptat doar cât timp seiful e deschis.' })); }
  function paneItem() {
    const d = draft, mark = () => { dirty = true; };
    const field = (label, input) => el('label', { class: 'vt-f' }, el('span', { text: label }), input);
    const txt = (key, ph, type = 'text') => el('input', { class: 'path', type, value: d[key] || '', placeholder: ph || '', autocomplete: 'off', oninput: e => { d[key] = e.target.value; mark(); } });
    const bar = [btn('Salvează', 'Ctrl+S', saveDraft, 'primary'), btn('Șterge', '', deleteItem)];
    paneEl.append(field('Titlu', txt('title', d.type === 'login' ? 'ex: Contul de e-mail' : 'Titlu')));
    if (d.type === 'login') {
      const pw = txt('password', '', 'password'), m = el('div', {}); m.append(meter(d.password));
      pw.addEventListener('input', () => m.replaceChildren(meter(pw.value)));
      const eye = btn('👁', 'Arată / ascunde', () => { pw.type = pw.type === 'password' ? 'text' : 'password'; });
      const dice = btn('🎲', 'Generează o parolă', () => { pw.value = d.password = genPassword(gen.len, gen); mark(); m.replaceChildren(meter(pw.value)); });
      paneEl.append(field('Utilizator', txt('user', 'nume sau e-mail')),
        el('div', { class: 'vt-f' }, el('span', { text: 'Parolă' }), el('div', { class: 'vt-row' }, pw, eye, dice, btn('📋', 'Copiază parola', () => vaultCopy(pw.value, 'Parola'))), m),
        field('Adresă web', el('div', { class: 'vt-row' }, txt('url', 'exemplu.ro'), btn('🌐', 'Deschide în Browser', () => { if (d.url) runCommand(d.url); }))),
        field('Notițe', el('textarea', { class: 'path', rows: '4', value: d.notes || '', oninput: e => { d.notes = e.target.value; mark(); } })),
        el('div', { class: 'vt-row' }, btn('Copiază utilizatorul', '', () => vaultCopy(d.user || '', 'Utilizatorul'))));
    } else if (d.type === 'note') {
      paneEl.append(field('Text', el('textarea', { class: 'path vt-ta', value: d.text || '', oninput: e => { d.text = e.target.value; mark(); } })));
    } else {
      paneEl.append(el('p', { class: 'vt-hint', text: `Fișier criptat: ${d.name} · ${fmtSize(d.size || 0)} · ${d.mime || ''}` }),
        el('div', { class: 'vt-row' },
          btn('Exportă în Fișiere', 'Salvează o copie necriptată în /Documents', () => { try { const p = vaultExportFile(d); toast('Exportat: ' + p); } catch (e) { alert(e.message); } }),
          btn('Descarcă', '', () => { const blob = d.text ? new Blob([d.content], { type: 'text/plain' }) : dataToBlob(d.content, d.mime); const url = URL.createObjectURL(blob); const a = el('a', { href: url, download: d.name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000); })));
    }
    paneEl.append(el('div', { class: 'vt-row', style: 'margin-top:10px' }, ...bar));
    if (!d.isNew && d.updated) paneEl.append(el('p', { class: 'vt-hint', text: 'Modificat: ' + new Date(d.updated).toLocaleString('ro-RO') }));
  }
  function renderPane() {
    paneEl.textContent = '';
    if (view === 'gen') return paneGen();
    if (view === 'opts') return paneOpts();
    return draft ? paneItem() : panePlain();
  }
  function renderOpen() {
    rootEl.textContent = '';
    const search = el('input', { class: 'path', type: 'search', placeholder: 'Caută în seif', value: query, 'aria-label': 'Caută în seif', style: 'max-width:200px', oninput: e => { query = e.target.value; renderList(); } });
    listEl = el('div', { class: 'vt-list' }); paneEl = el('div', { class: 'vt-pane' });
    rootEl.append(
      el('div', { class: 'tool vt-tool' }, btn('+ Parolă', '', () => newItem('login'), 'primary'), btn('+ Notiță', '', () => newItem('note')),
        btn('+ Fișier', '', () => pickFiles('', async fl => { try { let last; for (const f of fl) { const text = isTextLike(f.name, f.type || MIME_EXT[ext(f.name)] || ''); last = vaultAddFileItem(f.name, { text, mime: f.type || MIME_EXT[ext(f.name)] || 'application/octet-stream', content: text ? await f.text() : await readDataURL(f) }); } await vaultSaveNow(); sel = last.id; draft = JSON.parse(JSON.stringify(last)); view = 'item'; renderOpen(); } catch (e) { alert(e.message); } })),
        btn('🎲 Generator', '', () => { if (!confirmLeave()) return; dirty = false; draft = null; sel = null; view = 'gen'; renderOpen(); }),
        el('span', { class: 'spacer' }), search, btn('Opțiuni', '', () => { if (!confirmLeave()) return; dirty = false; draft = null; sel = null; view = 'opts'; renderOpen(); }), btn('🔒 Blochează', '', () => { if (confirmLeave()) vaultLock(); })),
      el('div', { class: 'vt-main' }, listEl, paneEl),
      el('div', { class: 'statusbar', text: `${vault.data.items.length} elemente · criptat cu AES-256-GCM · se blochează ${settings.vault.autoLock ? 'după ' + settings.vault.autoLock + ' min de inactivitate' : 'doar manual'}` }));
    renderList(); renderPane();
    if (vaultPending) processPending();
  }
  function render() {
    if (exists === null) { rootEl.textContent = 'Se încarcă…'; return; }
    if (!vault) { draft = null; sel = null; view = 'item'; dirty = false; return viewLocked(); }
    renderOpen();
  }
  const onLock = () => render(), onPending = () => { if (vault) processPending(); };
  window.addEventListener('vault-lock', onLock); window.addEventListener('vault-pending', onPending);
  for (const ev of ['pointerdown', 'keydown']) rootEl.addEventListener(ev, () => vaultTouch(), true);
  rootEl.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && vault && draft && view === 'item') { e.preventDefault(); saveDraft(); } });
  w.onClose = () => {
    if (dirty && !confirm('Ai modificări nesalvate în seif. Închizi oricum?')) return false;
    window.removeEventListener('vault-lock', onLock); window.removeEventListener('vault-pending', onPending); vaultLock(); return true;
  };
  vaultExists().then(v => { exists = v; render(); });
}

/* ---------- operații pe fișiere: clipboard, selecție multiplă, anulare / refacere ---------- */
const fileClip = { mode: null, paths: [] };
const fileUndo = [], fileRedo = [];
const plural = (n, a, b) => `${n} ${n === 1 ? a : b}`;
const fileOpsChanged = () => window.dispatchEvent(new Event('fs-change'));
const fileClipHas = () => fileClip.paths.some(p => node(p));

function fileClipSet(mode, paths) {
  paths = [...new Set(paths)].filter(p => node(p) && p !== '/' && p !== MOUNT_ROOT);
  if (!paths.length) return;
  fileClip.mode = mode; fileClip.paths = paths;
  toast(`${plural(paths.length, 'element', 'elemente')} ${mode === 'cut' ? 'tăiate' : 'copiate'}`);
  fileOpsChanged();
}
function pushUndo(entry) { fileUndo.push(entry); if (fileUndo.length > 50) fileUndo.shift(); fileRedo.length = 0; }
function undoFileOp() {
  const e = fileUndo.pop(); if (!e) { toast('Nimic de anulat'); return false; }
  const err = e.undo();
  if (err) { notify({ title: 'Nu s-a putut anula', body: `${e.label}: ${err}`, icon: '⚠️' }); fileOpsChanged(); return false; }
  fileRedo.push(e); toast('Anulat: ' + e.label); fileOpsChanged(); return true;
}
function redoFileOp() {
  const e = fileRedo.pop(); if (!e) { toast('Nimic de refăcut'); return false; }
  const err = e.redo();
  if (err) { notify({ title: 'Nu s-a putut reface', body: `${e.label}: ${err}`, icon: '⚠️' }); fileOpsChanged(); return false; }
  fileUndo.push(e); toast('Refăcut: ' + e.label); fileOpsChanged(); return true;
}

/* --- nume --- */
function splitExt(name) { const m = name.match(/^(.+?)(\.[^.]+)$/); return m ? [m[1], m[2]] : [name, '']; }
// primul nume liber într-un folder: „x - copie.txt”, „x - copie (2).txt” sau „x (2).txt”
function freeName(dir, name, style) {
  if (!node(norm(name, dir))) return name;
  const [stem, x] = splitExt(name); let i = 1, n;
  do { n = style === 'copy' ? (i === 1 ? `${stem} - copie${x}` : `${stem} - copie (${i})${x}`) : `${stem} (${i + 1})${x}`; i++; } while (node(norm(n, dir)));
  return n;
}
function dragPaths(e) {
  const raw = e.dataTransfer.getData(INTERNAL); if (!raw) return [];
  if (raw[0] === '[') { try { const a = JSON.parse(raw); return Array.isArray(a) ? a.filter(x => typeof x === 'string') : []; } catch { return []; } }
  return [raw];
}

/* --- copiere / mutare --- */
async function transferInto(paths, dest, mode) {
  const dn = node(dest);
  if (!dn || dn.type !== 'dir') return { done: [], errs: ['Destinația nu e un folder.'] };
  const done = [], errs = [];
  for (const src of paths) {
    const sn = node(src);
    if (!sn) { errs.push(`${base(src)}: nu mai există`); continue; }
    if (src === dest || dest.startsWith(src + '/')) { errs.push(`${base(src)}: nu poate fi pus în el însuși`); continue; }
    if (mode === 'cut' && norm('..', src) === dest) continue;   // mutare în același folder: nimic de făcut
    const ms = mountOf(src), md = mountOf(dest);
    const move = mode === 'cut' && ms === md;                    // mutare reală doar în aceeași „lume” (sistem sau același disc)
    const to = norm(freeName(dest, base(src), move ? 'num' : 'copy'), dest);
    let e = null;
    try {
      if (move) { if (ms) await ensureLoaded(src).catch(() => {}); e = fs.mv(src, to); }
      else {
        if (ms || hasLazy(sn)) {
          if (treeBytes(sn) > MOUNT_COPY_MAX) { errs.push(`${base(src)}: prea mult de copiat (peste 200 MB)`); continue; }
          await loadTree(src);
        }
        e = fs.cp(src, to);
      }
    } catch (x) { e = String(x && x.message || x); }
    if (e) errs.push(`${base(src)}: ${e}`); else done.push({ from: src, to, kind: move ? 'move' : 'copy', kept: mode === 'cut' && !move });
  }
  return { done, errs };
}
function recordTransfer(done, label) {
  if (!done.length) return;
  pushUndo({
    label, done,
    undo() { for (const r of [...this.done].reverse()) { const e = r.kind === 'move' ? fs.mv(r.to, r.from) : fs.rm(r.to, true); if (e) return `${base(r.to)}: ${e}`; } return null; },
    redo() { for (const r of this.done) { const e = r.kind === 'move' ? fs.mv(r.from, r.to) : fs.cp(r.from, r.to); if (e) return `${base(r.from)}: ${e}`; } return null; }
  });
}
function afterTransfer(done, errs, mode) {
  if (errs.length) notify({ title: 'Unele elemente nu s-au transferat', body: errs.slice(0, 3).join('; ') + (errs.length > 3 ? '…' : ''), icon: '⚠️' });
  if (done.length) {
    if (done.some(r => r.kept)) toast('Copiat. Mutarea între discuri nu e suportată, deci originalul a rămas pe loc.');
    const ev = new Event('files-select'); ev.paths = done.map(r => r.to); window.dispatchEvent(ev);
  }
  fileOpsChanged();
}
async function pasteInto(dest) {
  if (!fileClipHas()) { toast('Clipboardul de fișiere e gol'); return []; }
  const mode = fileClip.mode, { done, errs } = await transferInto(fileClip.paths.filter(p => node(p)), dest, mode);
  recordTransfer(done, `${mode === 'cut' ? 'Mutare' : 'Lipire'} (${plural(done.length, 'element', 'elemente')})`);
  if (mode === 'cut') {
    const moved = new Set(done.filter(r => r.kind === 'move').map(r => r.from));
    fileClip.paths = fileClip.paths.filter(p => !moved.has(p));
    if (!fileClip.paths.length) fileClip.mode = null;
  }
  afterTransfer(done, errs, mode);
  return done;
}
async function moveInto(paths, dest) {
  const { done, errs } = await transferInto(paths, dest, 'cut');
  recordTransfer(done, `Mutare (${plural(done.length, 'element', 'elemente')})`);
  afterTransfer(done, errs, 'cut');
  return done;
}

/* --- ștergere (Coș) --- */
function deleteMany(paths, quiet = false) {
  paths = [...new Set(paths)].filter(p => node(p) && p !== '/' && p !== MOUNT_ROOT);
  if (!paths.length) return;
  const inTrash = paths.filter(p => p.startsWith('/.Trash/')), mounted = paths.filter(p => mountOf(p));
  const plain = paths.filter(p => !inTrash.includes(p) && !mounted.includes(p));
  const nm = paths.length === 1 ? `„${base(paths[0])}”` : plural(paths.length, 'element', 'elemente');
  const perm = inTrash.length + mounted.length;
  if (perm) {
    const msg = plain.length ? `${plural(plain.length, 'element merge', 'elemente merg')} în Coșul de reciclare, iar ${plural(perm, 'element se șterge', 'elemente se șterg')} definitiv. Continui?`
      : mounted.length ? `Ștergi ${nm} de pe disc? Se șterge definitiv și nu poate fi recuperat din Coș.` : `Ștergi definitiv ${nm}? Nu se mai poate recupera.`;
    if (!confirm(msg)) return;
  } else if (!quiet && !confirm(`Muți ${nm} în Coșul de reciclare?`)) return;
  const errs = [], trashed = [];
  for (const p of plain) { const e = fs.trash(p); if (e) errs.push(`${base(p)}: ${e}`); else trashed.push({ orig: p, name: fs.lastTrash }); }
  for (const p of [...inTrash, ...mounted]) { const e = fs.rm(p, true); if (e) errs.push(`${base(p)}: ${e}`); }
  if (trashed.length) {
    pushUndo({
      label: `Mutare în Coș (${plural(trashed.length, 'element', 'elemente')})`, trashed,
      undo() { for (const r of [...this.trashed].reverse()) { const e = fs.restore(r.name); if (e) return `${base(r.orig)}: ${e}`; } return null; },
      redo() { for (const r of this.trashed) { const e = fs.trash(r.orig); if (e) return `${base(r.orig)}: ${e}`; r.name = fs.lastTrash; } return null; }
    });
    notify({ title: trashed.length === 1 ? 'Mutat în Coșul de reciclare' : `${trashed.length} elemente mutate în Coș`, body: trashed.length === 1 ? base(trashed[0].orig) : '', icon: 'app:trash', click: { type: 'app', app: 'trash' }, btn: { label: 'Anulează', type: 'undofile' } });
  } else if (perm && !errs.length) toast('Șters definitiv');
  if (errs.length) notify({ title: 'Unele elemente nu s-au șters', body: errs.slice(0, 3).join('; '), icon: '⚠️' });
}

/* --- creare / redenumire (anulabile) --- */
function recordCreate(p, isDir) {
  const n = node(p);
  pushUndo({
    label: `${isDir ? 'Creare folder' : 'Creare fișier'} „${base(p)}”`,
    undo: () => fs.rm(p, true),
    redo: () => { if (isDir) return fs.mkdir(p); const e = fs.put(p, n); if (!e) changed(); return e; }
  });
}
const recordRename = (from, to) => pushUndo({ label: `Redenumire „${base(from)}”`, undo: () => fs.mv(to, from), redo: () => fs.mv(from, to) });

/* --- scurtături de tastatură pe desktop (pictogramele selectate) --- */
function desktopKeys(e) {
  if (!(e.ctrlKey || e.metaKey || e.key === 'Delete') || e.altKey) return false;
  const t = e.target;
  if (t && t.closest && (t.closest('.win, #gs, #rundlg, #lock, #tv, #ncenter, #menu, #switcher') || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) return false;
  const picked = $$('.dicon.sel').map(x => x.dataset.key).filter(k => k && k.startsWith('f:')).map(k => '/Desktop/' + k.slice(2));
  const k = e.code;
  if (e.key === 'Delete') { if (!picked.length) return false; deleteMany(picked); return true; }
  if (k === 'KeyC' && picked.length) { fileClipSet('copy', picked); return true; }
  if (k === 'KeyX' && picked.length) { fileClipSet('cut', picked); return true; }
  if (k === 'KeyV' && fileClipHas()) { pasteInto('/Desktop'); return true; }
  if (k === 'KeyZ' && !e.shiftKey && fileUndo.length) { undoFileOp(); return true; }
  if ((k === 'KeyY' || (k === 'KeyZ' && e.shiftKey)) && fileRedo.length) { redoFileOp(); return true; }
  if (k === 'KeyA') { $$('.dicon').forEach(x => x.classList.add('sel')); return true; }
  return false;
}

/* ---------- aplicații, desktop, Start ---------- */
const apps = {
  computer: { name: 'Computer', icon: '🖥️', open: () => files('/') },
  files: { name: 'Fișiere', icon: '📁', open: () => files('/Documents') },
  browser: { name: 'Browser', icon: '🌐', open: browser },
  music: { name: 'Muzică', icon: '🎵', open: () => player() },
  images: { name: 'Imagini', icon: '🖼️', open: () => imageViewer() },
  paint: { name: 'Paint', icon: '🎨', open: () => paint() },
  solitaire: { name: 'Solitaire', icon: '🃏', open: () => solitaire() },
  code: { name: 'Cod', icon: '📜', open: () => codeEditor() },
  terminal: { name: 'Terminal', icon: '⌨️', open: terminal },
  notepad: { name: 'Notepad', icon: '📝', open: () => notepad() },
  calc: { name: 'Calculator', icon: '🧮', open: calculator },
  taskmgr: { name: 'Manager de activități', icon: '📊', open: taskManager },
  tmpapp: { name: 'Aplicație HTML', icon: '🧩', hidden: true, open: () => {} },
  vault: { name: 'Seif', icon: '🔐', open: vaultApp },
  trash: { name: 'Coș de reciclare', icon: '🗑️', open: recycleBin },
  settings: { name: 'Setări', icon: '⚙️', open: () => settingsApp() }
};

function appMenu(e, k) {
  ctxMenu(e.clientX, e.clientY, [
    { label: 'Deschide', icon: '▸', fn: () => apps[k].open() },
    { label: 'Schimbă pictograma…', icon: '🖼️', fn: () => changeIcon(k) },
    { label: 'Creează scurtătură pe desktop', icon: '🔗', fn: () => makeLink('/Desktop', apps[k].name, k) },
    { label: settings.desk.includes(k) ? 'Ascunde de pe desktop' : 'Arată pe desktop', icon: '🖥️', fn: () => { settings.desk = settings.desk.includes(k) ? settings.desk.filter(x => x !== k) : [...settings.desk, k]; saveSettings(); renderDesktop(); } },
    { label: settings.pinned.includes(k) ? 'Elimină din bara de activități' : 'Fixează în bara de activități', icon: '📌', fn: () => togglePin(k) },
    ...(apps[k].user ? ['-', ...userAppMenuItems(k)] : [])
  ]);
}

const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const GRID = { x0: 10, y0: 10, w: 96, h: 96 };
function gridSize() {
  return { cols: Math.max(1, Math.floor((desktop.clientWidth - GRID.x0) / GRID.w)), rows: Math.max(1, Math.floor((desktop.clientHeight - GRID.y0) / GRID.h)) };
}
const clearSel = () => $$('.dicon.sel').forEach(x => x.classList.remove('sel'));

function dicon(it) {
  const b = el('button', {
    class: 'dicon', 'data-key': it.key, ondblclick: it.open,
    onclick: e => { if (e.detail === 0) it.open(); },
    oncontextmenu: e => { e.preventDefault(); e.stopPropagation(); if (!b.classList.contains('sel')) { clearSel(); b.classList.add('sel'); } it.menu(e); }
  }, el('span', { class: 'g' }, iconEl(it.icon), ...(it.link ? [el('span', { class: 'lnk-arrow', text: '↗' })] : [])), el('span', { class: 'lbl', text: it.label }));
  return b;
}
function desktopItems() {
  const items = [];
  for (const k of settings.desk) if (apps[k]) items.push({ key: 'a:' + k, kind: 'app', id: k, icon: iconOf(k), label: apps[k].name, open: () => apps[k].open(), menu: e => appMenu(e, k) });
  for (const [nm, x] of fs.ls('/Desktop')) {
    const p = norm(nm, '/Desktop');
    const isLnk = x.type === 'file' && kindOf(x, p) === 'link';
    items.push({ key: 'f:' + nm, kind: 'file', id: p, dir: x.type === 'dir', link: isLnk, icon: x.type === 'dir' ? '📁' : isLnk ? linkIcon(x, p) : FILE_ICON[kindOf(x, p)], label: isLnk ? stripLnk(nm) : nm, open: () => openPath(p), menu: e => ctxMenu(e.clientX, e.clientY, fileMenuItems(p, x)) });
  }
  return items;
}
function renderDesktop() {
  const box = $('#icons'); if (!box) return;
  const selKeys = new Set($$('.dicon.sel').map(x => x.dataset.key));
  box.textContent = '';
  const items = desktopItems(), { cols, rows } = gridSize();
  const occ = new Set(), cell = new Map(), rest = [];
  for (const it of items) {
    const p = settings.iconPos[it.key];
    if (p) { const cx = Math.min(p.cx, cols - 1), cy = Math.min(p.cy, rows - 1), k = cx + ',' + cy; if (!occ.has(k)) { occ.add(k); cell.set(it, [cx, cy]); continue; } }
    rest.push(it);
  }
  let cx = 0, cy = 0;
  for (const it of rest) { while (occ.has(cx + ',' + cy)) { cy++; if (cy >= rows) { cy = 0; cx++; } } occ.add(cx + ',' + cy); cell.set(it, [cx, cy]); }
  for (const it of items) {
    const [x, y] = cell.get(it), d = dicon(it);
    d.dataset.cx = x; d.dataset.cy = y;
    d.style.left = GRID.x0 + x * GRID.w + 'px'; d.style.top = GRID.y0 + y * GRID.h + 'px';
    if (selKeys.has(it.key)) d.classList.add('sel');
    if (it.dir) d.dataset.dirpath = it.id;
    if (it.kind === 'app' && it.id === 'trash') {
      d.dataset.trash = '1';
      const n = fs.ls('/.Trash').length;
      if (n) d.append(el('span', { class: 'badge', text: String(n) }));
      d.addEventListener('dragover', e => { if ([...(e.dataTransfer?.types || [])].includes(INTERNAL)) { e.preventDefault(); e.stopPropagation(); } });
      d.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); const sp = dragPaths(e); if (sp.length) deleteMany(sp, true); });
    }
    box.append(d);
  }
}
function autoArrange(sorted) {
  const items = desktopItems(); if (sorted) items.sort((a, b) => a.label.localeCompare(b.label));
  const { rows } = gridSize(); settings.iconPos = {};
  if (sorted) items.forEach((it, i) => { settings.iconPos[it.key] = { cx: Math.floor(i / rows), cy: i % rows }; });
  saveSettings(); renderDesktop();
}
function snapIcons(group) {
  const { cols, rows } = gridSize();
  const clamp = (v, m) => Math.max(0, Math.min(m - 1, v));
  const want = group.map(x => [clamp(Math.round((x.offsetLeft - GRID.x0) / GRID.w), cols), clamp(Math.round((x.offsetTop - GRID.y0) / GRID.h), rows)]);
  const taken = new Set($$('.dicon').filter(x => !group.includes(x)).map(x => x.dataset.cx + ',' + x.dataset.cy));
  let cells;
  if (group.length === 1) {
    let [cx, cy] = want[0];
    if (taken.has(cx + ',' + cy)) {
      let best = null, bd = Infinity;
      for (let x = 0; x < cols; x++) for (let y = 0; y < rows; y++) if (!taken.has(x + ',' + y)) { const d = (x - cx) ** 2 + (y - cy) ** 2; if (d < bd) { bd = d; best = [x, y]; } }
      if (best) [cx, cy] = best;
    }
    cells = [[cx, cy]];
  } else {
    const ddx = want[0][0] - +group[0].dataset.cx, ddy = want[0][1] - +group[0].dataset.cy, seen = new Set();
    cells = group.map(x => [+x.dataset.cx + ddx, +x.dataset.cy + ddy]);
    const bad = cells.some(([x, y]) => { const k = x + ',' + y; const dup = seen.has(k); seen.add(k); return dup || x < 0 || y < 0 || x >= cols || y >= rows || taken.has(k); });
    if (bad) { renderDesktop(); return; }
  }
  group.forEach((x, i) => { settings.iconPos[x.dataset.key] = { cx: cells[i][0], cy: cells[i][1] }; });
  saveSettings(); renderDesktop();
}
function iconPointerDown(e) {
  const b = e.target.closest('.dicon');
  if (!b || e.button !== 0) return;
  if (e.ctrlKey || e.metaKey) { b.classList.toggle('sel'); return; }
  if (!b.classList.contains('sel')) { clearSel(); b.classList.add('sel'); }
  const group = $$('.dicon.sel'), sx = e.clientX, sy = e.clientY;
  const starts = group.map(x => [x, x.offsetLeft, x.offsetTop]);
  let moved = false;
  const mv = ev => {
    const dx = ev.clientX - sx, dy = ev.clientY - sy;
    if (!moved) { if (Math.abs(dx) + Math.abs(dy) < 6) return; moved = true; group.forEach(x => x.classList.add('dragging')); }
    starts.forEach(([x, l, t]) => { x.style.left = l + dx + 'px'; x.style.top = t + dy + 'px'; });
  };
  const up = ev => {
    window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
    if (!moved) { if (group.length > 1) { clearSel(); b.classList.add('sel'); } return; }
    group.forEach(x => x.classList.remove('dragging'));
    const under = document.elementFromPoint(ev.clientX, ev.clientY), tgt = under && under.closest('.dicon');
    if (tgt && !group.includes(tgt) && (tgt.dataset.trash || tgt.dataset.dirpath)) {
      const fl = group.filter(x => x.dataset.key.startsWith('f:'));
      if (fl.length) {
        const ps = fl.map(x => '/Desktop/' + x.dataset.key.slice(2));
        if (tgt.dataset.trash) deleteMany(ps, true); else moveInto(ps, tgt.dataset.dirpath);
        renderDesktop(); return;
      }
    }
    snapIcons(group);
  };
  window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
}
function rubberBand(e) {
  if (e.button !== 0 || !(e.target === desktop || e.target.id === 'icons')) return;
  if (!(e.ctrlKey || e.metaKey)) clearSel();
  const r0 = desktop.getBoundingClientRect(), sx = e.clientX - r0.left, sy = e.clientY - r0.top;
  const keep = new Set($$('.dicon.sel')), band = el('div', { class: 'rband' });
  desktop.append(band);
  const mv = ev => {
    const x = ev.clientX - r0.left, y = ev.clientY - r0.top;
    const l = Math.min(sx, x), t = Math.min(sy, y), w = Math.abs(x - sx), h = Math.abs(y - sy);
    Object.assign(band.style, { left: l + 'px', top: t + 'px', width: w + 'px', height: h + 'px' });
    $$('.dicon').forEach(d => {
      const dr = d.getBoundingClientRect();
      const hit = !(dr.right - r0.left < l || dr.left - r0.left > l + w || dr.bottom - r0.top < t || dr.top - r0.top > t + h);
      d.classList.toggle('sel', hit || keep.has(d));
    });
  };
  const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); band.remove(); };
  window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
}

function renderMenu() {
  const menu = $('#menu'); menu.textContent = '';
  const close = () => menu.classList.remove('open');
  const mb = (icon, label, fn, ctx) => {
    const props = { onclick: fn };
    if (ctx) props.oncontextmenu = e => { e.preventDefault(); ctx(e); };
    return el('button', props, iconEl(icon), el('span', { text: label }));
  };
  const appsBox = el('div', { class: 'm-apps' });
  const search = el('input', { class: 'm-search', type: 'search', placeholder: 'Caută programe și fișiere', spellcheck: 'false', 'aria-label': 'Caută' });
  const fillApps = () => { appsBox.textContent = ''; for (const [k, a] of Object.entries(apps)) if (!a.hidden) appsBox.append(mb(iconOf(k), a.name, () => { close(); a.open(); }, e => appMenu(e, k))); };
  const doSearch = () => {
    const q = search.value.trim().toLowerCase();
    if (!q) return fillApps();
    appsBox.textContent = '';
    const res = [];
    for (const [k, a] of Object.entries(apps)) if (!a.hidden && a.name.toLowerCase().includes(q)) res.push({ icon: iconOf(k), label: a.name, fn: () => a.open() });
    (function walk(d) { for (const [nm, x] of fs.ls(d)) { if (res.length >= 14) return; if (d === '/' && nm === '.Trash') continue; const p = norm(nm, d); if (nm.toLowerCase().includes(q)) res.push({ icon: x.type === 'dir' ? '📁' : FILE_ICON[kindOf(x, p)], label: nm + '   ' + p, fn: () => openPath(p) }); if (x.type === 'dir') walk(p); } })('/');
    if (!res.length) appsBox.append(el('p', { class: 'empty', text: 'Niciun rezultat.' }));
    for (const r of res) appsBox.append(mb(r.icon, r.label, () => { close(); r.fn(); }));
    appsBox.append(mb('🔍', `Căutare globală pentru „${search.value.trim()}”`, () => { close(); openGS(search.value.trim()); }));
  };
  search.addEventListener('input', doSearch);
  search.addEventListener('keydown', e => { if (e.key === 'Enter') { const f = appsBox.querySelector('button'); if (f) f.click(); } });
  fillApps();
  const place = (icon, label, fn) => mb(icon, label, () => { close(); fn(); });
  const arrow = el('button', { class: 'm-arrow', title: 'Mai multe opțiuni', text: '▸' });
  arrow.addEventListener('click', () => { const r = arrow.getBoundingClientRect(); ctxMenu(r.right, r.top, [{ label: 'Repornește', icon: '⟳', fn: () => location.reload() }]); });
  menu.append(
    el('div', { class: 'm-left' }, appsBox, search),
    el('div', { class: 'm-side' },
      el('div', { class: 'm-user' }, el('div', { class: 'm-avatar' }, avatarEl()), el('div', { class: 'm-name', text: settings.userName })),
      place('📄', 'Documente', () => files('/Documents')), place('🖼️', 'Imagini', () => files('/Pictures')), place('🎵', 'Muzică', () => files('/Music')),
      place(iconOf('computer'), 'Computer', () => files('/')), place('🔍', 'Căutare globală', () => openGS()), place('▶', 'Rulează…', runDialog), place(iconOf('settings'), 'Panou de control', () => settingsApp()),
      el('div', { class: 'spacer' }),
      el('div', { class: 'm-power' }, el('button', { class: 'm-off', text: 'Blochează', onclick: () => { close(); lock(); } }), arrow)));
  menu._reset = () => { search.value = ''; fillApps(); search.focus(); };
}
function refreshShell() { renderDesktop(); renderMenu(); renderTasks(); }

function buildShell() {
  const menu = $('#menu');
  $('#start').onclick = () => { menu.classList.toggle('open'); if (menu.classList.contains('open') && menu._reset) menu._reset(); };
  document.addEventListener('pointerdown', e => {
    if (!e.target.closest('.ctx')) closeCtx();
    if (!e.target.closest('#menu, #start')) menu.classList.remove('open');
    if (!e.target.closest('#cal, #clock-btn')) { const c = $('#cal'); if (c) c.remove(); }
    if (!e.target.closest('#ncenter, #notif-btn')) { const c = $('#ncenter'); if (c) c.remove(); }
  }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { menu.classList.remove('open'); closeCtx(); closeTaskView(); closeGS(); const c = $('#ncenter'); if (c) c.remove(); } });
  document.addEventListener('keydown', e => {
    const arrow = e.key === 'ArrowRight' || e.key === 'ArrowLeft';
    if (arrow && ((e.ctrlKey && e.altKey) || (e.altKey && e.shiftKey))) { e.preventDefault(); switchDesk(vd.cur + (e.key === 'ArrowRight' ? 1 : -1)); }
    else if (e.altKey && e.shiftKey && e.key === 'ArrowUp') { e.preventDefault(); toggleTaskView(); }
    else if ($('#tv') && /^[1-6]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey) { closeTaskView(); switchDesk(+e.key - 1); }
  });
  $('#gsbtn').onclick = toggleGS;
  installShortcuts();
  $('#clock-btn').onclick = toggleCal;
  $('#showdesk').onclick = showDesktop;
  $('#notif-btn').onclick = toggleCenter;
  $('#taskview').onclick = toggleTaskView;
  $('#taskbar').addEventListener('contextmenu', e => {
    if (e.target.closest('.task, #start, #clock-btn, #showdesk')) return;
    e.preventDefault();
    ctxMenu(e.clientX, e.clientY, [{ label: 'Căutare…', icon: '🔍', fn: () => openGS() }, { label: 'Rulează…', icon: '▶', fn: runDialog }, { label: 'Vizualizare activități', icon: '▦', fn: toggleTaskView }, { label: 'Desktop nou', icon: '＋', fn: () => addDesk(true) }, '-', { label: 'Pornește Managerul de activități', icon: '📊', fn: () => apps.taskmgr.open() }, '-', { label: 'Arată desktopul', icon: '🖥️', fn: showDesktop }]);
  });
  document.addEventListener('keydown', e => { if (e.ctrlKey && e.shiftKey && e.key === 'Escape') { e.preventDefault(); apps.taskmgr.open(); } });

  // desktop: click gol, meniu contextual, drag & drop din calculator
  $('#icons').addEventListener('pointerdown', iconPointerDown);
  desktop.addEventListener('pointerdown', rubberBand);
  window.addEventListener('resize', debounce(() => renderDesktop(), 150));
  desktop.addEventListener('contextmenu', e => {
    if (e.target.closest('.win') || e.target.closest('.dicon')) return;
    e.preventDefault();
    ctxMenu(e.clientX, e.clientY, [
      { label: 'Fișier text nou', icon: '📄', fn: () => { const n = prompt('Nume fișier:', uniqueName('/Desktop', 'Fișier nou', '.txt')); if (n) { const pp = norm(n, '/Desktop'), er = fs.write(pp, ''); if (er) alert(er); else recordCreate(pp, false); } } },
      { label: 'Folder nou', icon: '📁', fn: () => { const n = prompt('Nume folder:', uniqueName('/Desktop', 'Folder nou', '')); if (n) { const pp = norm(n, '/Desktop'), er = fs.mkdir(pp); if (er) alert(er); else recordCreate(pp, true); } } },
      { label: 'Lipește', icon: '📥', disabled: !fileClipHas(), fn: () => pasteInto('/Desktop') },
      { label: 'Scurtătură nouă…', icon: '🔗', fn: () => newLinkDialog('/Desktop') },
      '-', { label: 'Aranjează pictogramele automat', icon: '▦', fn: () => autoArrange(false) },
      { label: 'Sortează după nume', icon: '↕', fn: () => autoArrange(true) },
      { label: 'Reîmprospătează', icon: '⟳', fn: renderDesktop },
      '-', { label: 'Căutare…', icon: '🔍', fn: () => openGS() },
      { label: 'Personalizează', icon: '🎨', fn: () => settingsApp('personal') },
      { label: 'Pictograme…', icon: '🖼️', fn: () => settingsApp('icons') }
    ]);
  });
  desktop.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
  desktop.addEventListener('drop', e => { if (!hasFiles(e)) return; e.preventDefault(); importFiles([...e.dataTransfer.files], '/Desktop'); });
  window.addEventListener('dragover', e => e.preventDefault());
  window.addEventListener('drop', e => e.preventDefault());
  window.addEventListener('fs-change', renderDesktop);

  const tick = () => {
    const d = new Date();
    $('#c-t').textContent = d.toLocaleTimeString('ro-RO', { hour: '2-digit', minute: '2-digit' });
    $('#c-d').textContent = d.toLocaleDateString('ro-RO', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };
  tick(); setInterval(tick, 15000);
}

(async function boot() {
  let first = false;
  try { root = await dbGet('fs'); } catch { root = null; }
  if (!root) { root = seed(); first = true; }
  let fixed = false;
  for (const d of ['Desktop', 'Documents', 'Pictures', 'Music', '.Trash']) if (!root.children[d]) { root.children[d] = mkDir(); fixed = true; }
  if (first || fixed) { try { await dbSet('fs', root); } catch {} }
  let saved = null; try { saved = await dbGet('settings'); } catch {}
  settings = { ...DEFAULTS, ...saved };
  settings.icons = { ...(saved && saved.icons) };
  settings.pinned = [...settings.pinned]; settings.desk = [...settings.desk];
  settings.iconPos = { ...(saved && saved.iconPos) };
  if (saved && !saved.theme) { settings.accent = DEFAULTS.accent; settings.wall = 0; }
  if (saved && !saved.seenTrash && !settings.desk.includes('trash')) settings.desk.unshift('trash');
  settings.seenTrash = true;
  if (saved && !saved.seenPaint && !settings.desk.includes('paint')) settings.desk.push('paint');
  settings.seenPaint = true;
  if (saved && !saved.seenSol && !settings.desk.includes('solitaire')) settings.desk.push('solitaire');
  settings.seenSol = true;
  settings.vdesks = (settings.vdesks && settings.vdesks.length) ? [...settings.vdesks] : ['Desktop 1'];
  settings.runHistory = [...(settings.runHistory || [])];
  settings.gsRecent = [...(settings.gsRecent || [])];
  settings.mounts = (settings.mounts || []).map(r => ({ ...r }));
  settings.vault = { autoLock: 5, clip: true, ...(settings.vault || {}) };
  if (saved && !saved.seenVault && !settings.desk.includes('vault')) settings.desk.push('vault');
  settings.seenVault = true;
  settings.userApps = (settings.userApps || []).map(r => ({ ...r, perms: { ...defaultPerms(), ...r.perms } }));
  settings.vdWalls = settings.vdesks.map((_, i) => (saved && saved.vdWalls && saved.vdWalls[i]) || null);
  settings.solStats = { played: 0, won: 0, best: 0, ...(saved && saved.solStats) };
  dbSet('settings', settings).catch(() => {});

  settings.reminders = [...(settings.reminders || [])]; if (!settings.createdAt) settings.createdAt = Date.now();
  try { notifs = (await dbGet('notifs')) || []; } catch { notifs = []; }
  const booted = await sess.get('booted'), unlocked = await sess.get('unlocked');
  const showBoot = settings.bootAnim === 'always' || (settings.bootAnim === 'session' && !booted);
  const needLogin = !!settings.pw && (settings.pwMode === 'always' || !unlocked);
  ensureMountRoots(); syncUserApps(); applySettings(); buildShell(); refreshShell(); updateBadge(); updateTvBadge();
  setInterval(checkReminders, 5000);
  if (needLogin) lock({ startup: true });
  if (showBoot) await bootAnimation(); else hideBoot();
  sess.set('booted', true);
  if (first) seedExamples(false);
  if (first && !needLogin) { openPath('/Documents/Bun venit.txt'); notify({ title: 'Bun venit în HeliumOS', body: 'Click dreapta pe desktop pentru personalizare. Trage fișiere aici ca să le imporți.', icon: '👋', click: { type: 'settings', tab: 'personal' } }); }
  setTimeout(checkReminders, 800); setTimeout(startupChecks, 3500);
  if (saved && !saved.seenApps) setTimeout(() => notify({ title: 'Nou: aplicații proprii', body: 'Scrie o aplicație HTML și instaleaz-o în sistem.', icon: '🧩', click: { type: 'settings', tab: 'apps' }, btn: { label: 'Adaugă exemple', type: 'seedapps' } }), 4800);
  settings.seenApps = true;
})();
})();
