// Rulează în pagina „sandbox” a extensiei (origine izolată): poate folosi eval și scripturi inline.
const send = (type, text) => parent.postMessage({ type, text }, '*');
const fmt = a => a.map(x => { try { return typeof x === 'string' ? x : (JSON.stringify(x) ?? String(x)); } catch { return String(x); } }).join(' ');

// notify(titlu, mesaj) pentru consola din editorul de cod
globalThis.notify = (title, body = '') => send('notify', JSON.stringify({ title: String(title), body: String(body) }));

// --- puntea `helium` pentru aplicații proprii ---
// Toate cererile merg la sistemul gazdă, care verifică permisiunile aplicației.
const pending = new Map();
let rpcSeq = 0;
const rpc = (method, ...args) => new Promise((res, rej) => {
  const id = ++rpcSeq; pending.set(id, { res, rej });
  parent.postMessage({ type: 'rpc', id, method, args }, '*');
});
const makeHelium = meta => Object.freeze({
  app: meta || {},
  notify: (title, body = '') => rpc('notify', String(title), String(body)),
  storage: Object.freeze({
    get: k => rpc('storage.get', String(k)), set: (k, v) => rpc('storage.set', String(k), v),
    remove: k => rpc('storage.remove', String(k)), keys: () => rpc('storage.keys')
  }),
  files: Object.freeze({ read: p => rpc('files.read', p), write: (p, c) => rpc('files.write', p, c), list: p => rpc('files.list', p), remove: p => rpc('files.remove', p) }),
  fs: Object.freeze({ read: p => rpc('fs.read', p), write: (p, c) => rpc('fs.write', p, c), list: p => rpc('fs.list', p), remove: p => rpc('fs.remove', p) }),
  run: c => rpc('run', String(c)),
  system: () => rpc('system.info'),
  window: Object.freeze({
    setTitle: t => rpc('window.setTitle', String(t)), resize: (w, h) => rpc('window.resize', +w, +h),
    close: () => rpc('window.close'), focus: () => rpc('window.focus')
  })
});

addEventListener('message', async e => {
  const m = e.data || {};
  if (m.type === 'rpc-result') {
    const p = pending.get(m.id);
    if (p) { pending.delete(m.id); if (m.error) p.rej(new Error(m.error)); else p.res(m.result); }
    return;
  }
  if (m.type === 'app') {
    globalThis.helium = makeHelium(m.meta);
    document.open(); document.write(m.code); document.close();
  } else if (m.type === 'html') {
    document.open(); document.write(m.code); document.close();
  } else if (m.type === 'js') {
    for (const k of ['log', 'info', 'warn', 'error']) console[k] = (...a) => send(k === 'warn' ? 'warn' : k === 'error' ? 'error' : 'log', fmt(a));
    addEventListener('error', ev => send('error', ev.message));
    addEventListener('unhandledrejection', ev => send('error', String(ev.reason)));
    try {
      const AsyncFn = Object.getPrototypeOf(async function () {}).constructor;
      const r = await new AsyncFn(m.code)();
      if (r !== undefined) send('log', '⇒ ' + fmt([r]));
    } catch (err) { send('error', String(err)); }
    send('done', '');
  }
});
