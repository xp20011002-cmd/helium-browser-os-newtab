// Permite aplicației Browser din HeliumOS să afișeze site-uri în iframe.
// Regula se aplică DOAR cadrelor inițiate de această extensie.
chrome.runtime.onInstalled.addListener(async () => {
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1],
    addRules: [{
      id: 1,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        responseHeaders: [
          { header: 'x-frame-options', operation: 'remove' },
          { header: 'content-security-policy', operation: 'remove' }
        ]
      },
      condition: {
        resourceTypes: ['sub_frame'],
        initiatorDomains: [chrome.runtime.id]
      }
    }]
  });
});

// Notificări de sistem (permisiune opțională): un click deschide HeliumOS într-un tab nou.
function wireNotifications() {
  if (wireNotifications.done || !chrome.notifications) return;
  wireNotifications.done = true;
  chrome.notifications.onClicked.addListener(id => { chrome.notifications.clear(id); chrome.tabs.create({}); });
}
wireNotifications();
chrome.permissions.onAdded.addListener(wireNotifications);
